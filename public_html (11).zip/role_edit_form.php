<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

if (!can_manage_roles()) {
    die("Yetkiniz yok");
}

$roleId = (int)($_GET["role_id"] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM roles WHERE id = ?");
$stmt->execute([$roleId]);
$role = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$role) {
    die("Rol bulunamadı");
}

// Sadece super admin sistem rollerini düzenleyebilir
if ((int)$role['is_system'] === 1 && !is_super_admin()) {
    die("Sadece Super Admin sistem rollerini düzenleyebilir");
}

$stmt = $pdo->prepare("SELECT permission_key FROM role_permissions WHERE role_id = ?");
$stmt->execute([$roleId]);
$activePerms = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'permission_key');

$allPermissions = get_all_permissions();
?>

<input type="hidden" name="action" value="edit_role">
<input type="hidden" name="role_id" value="<?= (int)$role['id'] ?>">

<div class="mb-3">
    <label class="form-label fw-bold">Rol Adı</label>
    <input type="text" name="role_name" class="form-control" 
           value="<?= htmlspecialchars($role['role_name']) ?>" required>
    <small class="text-muted">Slug: <?= htmlspecialchars($role['role_slug']) ?></small>
</div>

<?php if ((int)$role['is_system'] === 1): ?>
<div class="alert alert-warning">
    <strong><i class="bi bi-shield-exclamation"></i> Sistem Rolü</strong><br>
    Bu bir sistem rolüdür. Dikkatli düzenleyin!
</div>
<?php endif; ?>

<div class="mb-3">
    <label class="form-label fw-bold">Yetkiler</label>
    <div style="max-height:400px; overflow-y:auto; border:1px solid #dee2e6; padding:10px; border-radius:4px;">
        <?php foreach ($allPermissions as $key => $label): ?>
            <?php if ($key === 'create_super_admin' && !is_super_admin()) continue; ?>
            <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" 
                       name="permissions[]" value="<?= htmlspecialchars($key) ?>" 
                       id="edit_perm_<?= htmlspecialchars($key) ?>"
                       <?= in_array($key, $activePerms) ? 'checked' : '' ?>>
                <label class="form-check-label" for="edit_perm_<?= htmlspecialchars($key) ?>">
                    <strong><?= htmlspecialchars($label) ?></strong><br>
                    <small class="text-muted"><?= htmlspecialchars($key) ?></small>
                </label>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="alert alert-info">
    <strong>Rol Bilgileri:</strong><br>
    Tip: <?= (int)$role['is_system'] ? '<span class="badge bg-primary">Sistem Rolü</span>' : '<span class="badge bg-secondary">Özel Rol</span>' ?><br>
    Oluşturulma: <?= date('d.m.Y H:i', strtotime($role['created_at'])) ?><br>
    Aktif Yetki: <?= count($activePerms) ?> / <?= count($allPermissions) ?>
</div>