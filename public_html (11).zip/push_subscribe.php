<?php
require "auth.php";
require "config/db.php";

$data = file_get_contents("php://input");

$stmt = $pdo->prepare("
    INSERT INTO push_subscriptions (user_id, subscription)
    VALUES (?,?)
");
$stmt->execute([$_SESSION["user"]["id"], $data]);
