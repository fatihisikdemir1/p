<?php
$title = 'Faturalar';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';

if (!acc_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);
$msg=null; $err=null;

if ($_SERVER['REQUEST_METHOD']==='POST' && acc_can_edit()) {
  try{
    $dir = $_POST['direction'] ?? 'sales';
    $no = trim((string)($_POST['invoice_no'] ?? ''));
    $dt = $_POST['invoice_date'] ?? date('Y-m-d');
    $cp = trim((string)($_POST['counterparty'] ?? ''));
    $subtotal = (float)($_POST['subtotal'] ?? 0);
    $vat_rate = (float)($_POST['vat_rate'] ?? 20);
    if($no===''||$cp==='') throw new Exception("Fatura no ve karşı taraf zorunlu.");
    if($subtotal<=0) throw new Exception("Ara toplam > 0 olmalı.");
    $vat_amount = round($subtotal * ($vat_rate/100), 2);
    $total = $subtotal + $vat_amount;

    $pdo->prepare("INSERT INTO acc_invoices (company_id,direction,invoice_no,invoice_date,counterparty,currency,subtotal,vat_rate,vat_amount,total,status,created_by,created_at)
                   VALUES (?,?,?,?,?,'TRY',?,?,?,?, 'issued', ?, NOW())")
        ->execute([$companyId,$dir,$no,$dt,$cp,$subtotal,$vat_rate,$vat_amount,$total,(int)($_SESSION['user']['id'] ?? 0)]);
    $msg="Fatura kaydedildi.";
  }catch(Exception $e){ $err=$e->getMessage(); }
}

$list=$pdo->prepare("SELECT * FROM acc_invoices WHERE company_id=? ORDER BY invoice_date DESC, id DESC LIMIT 200");
$list->execute([$companyId]);
$rows=$list->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="main">
  <div class="topbar">
    <div><h1>Faturalar</h1><small>Satış/Alış faturaları + KDV hesaplama (iskelet).</small></div>
    <div class="actions"><a class="btn secondary" href="vat.php">KDV</a></div>
  </div>

  <?php if($msg): ?><div class="alert ok"><?php echo e($msg); ?></div><?php endif; ?>
  <?php if($err): ?><div class="alert error"><?php echo e($err); ?></div><?php endif; ?>

  <div class="card">
    <h3>Yeni Fatura</h3>
    <form class="form" method="post">
      <div class="row">
        <div>
          <label>Tür</label>
          <select class="input" name="direction">
            <option value="sales">Satış</option>
            <option value="purchase">Alış</option>
          </select>
        </div>
        <div><label>Fatura No</label><input class="input" name="invoice_no" required></div>
        <div><label>Tarih</label><input class="input" type="date" name="invoice_date" value="<?php echo e(date('Y-m-d')); ?>"></div>
      </div>

      <div class="row">
        <div style="grid-column: span 2;"><label>Karşı Taraf</label><input class="input" name="counterparty" placeholder="Müşteri / Tedarikçi" required></div>
        <div><label>Ara Toplam</label><input class="input" name="subtotal" type="number" step="0.01" required></div>
      </div>

      <div class="row">
        <div><label>KDV Oranı (%)</label><input class="input" name="vat_rate" type="number" step="0.01" value="20"></div>
        <div></div><div></div>
      </div>

      <button class="btn" type="submit" <?php echo acc_can_edit()?'':'disabled'; ?>>Kaydet</button>
    </form>
  </div>

  <div class="card" style="margin-top:14px;">
    <h3>Fatura Listesi</h3>
    <table class="table">
      <thead><tr><th>Tarih</th><th>Tür</th><th>No</th><th>Karşı Taraf</th><th>KDV</th><th>Toplam</th></tr></thead>
      <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><?php echo e((string)$r['invoice_date']); ?></td>
          <td><?php echo $r['direction']==='sales' ? "<span class='badge green'>Satış</span>" : "<span class='badge orange'>Alış</span>"; ?></td>
          <td><strong><?php echo e((string)$r['invoice_no']); ?></strong></td>
          <td><?php echo e((string)$r['counterparty']); ?></td>
          <td><?php echo money_fmt($r['vat_amount'],'TRY'); ?> <small>(%<?php echo e((string)$r['vat_rate']); ?>)</small></td>
          <td><strong><?php echo money_fmt($r['total'],'TRY'); ?></strong></td>
        </tr>
      <?php endforeach; ?>
      <?php if(empty($rows)): ?><tr><td colspan="6"><small>Fatura yok.</small></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
