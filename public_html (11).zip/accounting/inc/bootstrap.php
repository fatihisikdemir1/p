<?php
// accounting/inc/bootstrap.php
declare(strict_types=1);

require_once __DIR__ . "/../../auth.php"; // root auth.php (session + $pdo + RBAC)

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function money_fmt($n, string $ccy='TRY'): string {
  $v = is_numeric($n) ? (float)$n : 0.0;
  return number_format($v, 2, ',', '.') . " " . $ccy;
}
function current_path(): string { return $_SERVER['PHP_SELF'] ?? ''; }
function is_active(string $needle): string { return (strpos(current_path(), $needle) !== false) ? 'active' : ''; }

// accounting permissions (you can map to your RBAC later)
function acc_can_view(): bool { return has_permission('accounting_view') || is_super_admin(); }
function acc_can_edit(): bool { return has_permission('accounting_edit') || is_super_admin(); }
