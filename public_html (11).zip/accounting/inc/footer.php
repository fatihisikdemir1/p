<?php // accounting/inc/footer.php ?>
</div>
</body>
</html>
