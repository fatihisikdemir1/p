<?php
require_once __DIR__ . "/bootstrap.php";
$uName = $_SESSION['user']['name'] ?? ($_SESSION['user']['full_name'] ?? 'Kullanıcı');
$role  = $_SESSION['user']['role'] ?? 'user';
$initial = mb_strtoupper(mb_substr((string)$uName, 0, 1, 'UTF-8'), 'UTF-8');
?>
<aside class="sidebar">
  <div class="brand">
    <h2>FinansConnect <span class="pill">Accounting</span></h2>
    <small>Muhasebe & Kayıt Merkezi</small>
  </div>

  <nav class="nav">
    <div class="section">Genel</div>
    <a class="<?php echo is_active('/accounting/dashboard.php'); ?>" href="dashboard.php">🏠 Dashboard</a>

    <div class="section">Kayıt</div>
    <a class="<?php echo is_active('/accounting/journals.php'); ?>" href="journals.php">🧾 Yevmiye Fişleri</a>
    <a class="<?php echo is_active('/accounting/coa.php'); ?>" href="coa.php">📚 Hesap Planı</a>

    <div class="section">Belgeler</div>
    <a class="<?php echo is_active('/accounting/invoices.php'); ?>" href="invoices.php">🧾 Faturalar</a>
    <a class="<?php echo is_active('/accounting/vat.php'); ?>" href="vat.php">🧮 KDV İzleme</a>

    <div class="section">Rapor</div>
    <a class="<?php echo is_active('/accounting/reports.php'); ?>" href="reports.php">📊 Raporlar</a>

    <div class="section">Sistem</div>
    <a class="<?php echo is_active('/accounting/settings.php'); ?>" href="settings.php">⚙️ Ayarlar</a>
    <a href="/modules.php">↩︎ Modül Seç</a>
  </nav>

  <div class="userbox">
    <div class="avatar"><?php echo e($initial); ?></div>
    <div>
      <div style="font-weight:900;"><?php echo e($uName); ?></div>
      <small><?php echo e($role); ?></small>
    </div>
  </div>
</aside>
