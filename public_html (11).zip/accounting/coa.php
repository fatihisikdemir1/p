<?php
$title = 'Hesap Planı';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';

if (!acc_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);
$msg=null; $err=null;

if (isset($_GET['seed']) && acc_can_edit()) {
  $seed = [
    ['100','Kasa','asset'],
    ['102','Banka','asset'],
    ['120','Alıcılar','asset'],
    ['320','Satıcılar','liability'],
    ['391','Hesaplanan KDV','liability'],
    ['191','İndirilecek KDV','asset'],
    ['600','Yurtiçi Satışlar','revenue'],
    ['740','Hizmet Üretim Maliyeti','expense'],
    ['770','Genel Yönetim Giderleri','expense'],
  ];
  $st = $pdo->prepare("INSERT IGNORE INTO acc_chart_of_accounts (company_id,code,name,type,is_active) VALUES (?,?,?,?,1)");
  foreach($seed as $s){ $st->execute([$companyId,$s[0],$s[1],$s[2]]); }
  $msg="Örnek hesap planı yüklendi.";
}

if ($_SERVER['REQUEST_METHOD']==='POST' && acc_can_edit()) {
  try{
    $code=trim((string)($_POST['code'] ?? ''));
    $name=trim((string)($_POST['name'] ?? ''));
    $type=$_POST['type'] ?? 'asset';
    if($code===''||$name==='') throw new Exception("Kod ve isim zorunlu.");
    $pdo->prepare("INSERT INTO acc_chart_of_accounts (company_id,code,name,type,is_active) VALUES (?,?,?,?,1)")
        ->execute([$companyId,$code,$name,$type]);
    $msg="Hesap eklendi.";
  }catch(Exception $e){ $err=$e->getMessage(); }
}

$list=$pdo->prepare("SELECT * FROM acc_chart_of_accounts WHERE company_id=? ORDER BY code");
$list->execute([$companyId]);
$rows=$list->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="main">
  <div class="topbar">
    <div><h1>Hesap Planı</h1><small>COA (Chart of Accounts) — fiş girişleri buradan beslenir.</small></div>
    <div class="actions">
      <a class="btn secondary" href="coa.php?seed=1">Örnek Hesap Planı</a>
      <a class="btn" href="journals.php">Yevmiye</a>
    </div>
  </div>

  <?php if($msg): ?><div class="alert ok"><?php echo e($msg); ?></div><?php endif; ?>
  <?php if($err): ?><div class="alert error"><?php echo e($err); ?></div><?php endif; ?>

  <div class="card">
    <h3>Yeni Hesap</h3>
    <form class="form" method="post">
      <div class="row">
        <div><label>Kod</label><input class="input" name="code" required></div>
        <div><label>İsim</label><input class="input" name="name" required></div>
        <div>
          <label>Tip</label>
          <select class="input" name="type">
            <option value="asset">Asset</option>
            <option value="liability">Liability</option>
            <option value="equity">Equity</option>
            <option value="revenue">Revenue</option>
            <option value="expense">Expense</option>
          </select>
        </div>
      </div>
      <button class="btn" type="submit" <?php echo acc_can_edit()?'':'disabled'; ?>>Kaydet</button>
    </form>
  </div>

  <div class="card" style="margin-top:14px;">
    <h3>Hesap Listesi</h3>
    <table class="table">
      <thead><tr><th>Kod</th><th>İsim</th><th>Tip</th><th>Aktif</th></tr></thead>
      <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><strong><?php echo e((string)$r['code']); ?></strong></td>
          <td><?php echo e((string)$r['name']); ?></td>
          <td><?php echo e((string)$r['type']); ?></td>
          <td><?php echo ((int)$r['is_active']===1) ? "<span class='badge green'>Aktif</span>" : "<span class='badge red'>Pasif</span>"; ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if(empty($rows)): ?><tr><td colspan="4"><small>Hesap yok.</small></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
