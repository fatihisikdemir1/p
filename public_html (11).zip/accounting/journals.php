<?php
$title = 'Yevmiye Fişleri';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';

if (!acc_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);
$msg=null; $err=null;

function next_journal_no(PDO $pdo, int $companyId): string {
  $last = $pdo->prepare("SELECT journal_no FROM acc_journals WHERE company_id=? ORDER BY id DESC LIMIT 1");
  $last->execute([$companyId]);
  $v = (string)($last->fetchColumn() ?: '');
  $next = 1;
  if (preg_match('/(\d+)$/', $v, $m)) { $next = ((int)$m[1])+1; }
  return sprintf("JV-%s%s-%05d", date('Y'), date('m'), $next);
}

if ($_SERVER['REQUEST_METHOD']==='POST' && acc_can_edit()) {
  try{
    $journal_no = trim((string)($_POST['journal_no'] ?? ''));
    $journal_date = $_POST['journal_date'] ?? date('Y-m-d');
    $desc = trim((string)($_POST['description'] ?? '')) ?: null;

    $acc1 = (int)($_POST['account_id_1'] ?? 0);
    $acc2 = (int)($_POST['account_id_2'] ?? 0);
    $debit = (float)($_POST['debit'] ?? 0);
    $credit = (float)($_POST['credit'] ?? 0);

    if ($journal_no==='') $journal_no = next_journal_no($pdo,$companyId);
    if ($acc1<=0 || $acc2<=0) throw new Exception("2 hesap seçmelisiniz.");
    if ($debit<=0 || $credit<=0) throw new Exception("Debit ve credit > 0 olmalı.");
    if (abs($debit-$credit) > 0.009) throw new Exception("Fiş dengede değil (debit != credit).");

    $pdo->beginTransaction();
    $st=$pdo->prepare("INSERT INTO acc_journals (company_id,journal_no,journal_date,description,status,created_by,created_at)
                       VALUES (?,?,?,?, 'draft', ?, NOW())");
    $st->execute([$companyId,$journal_no,$journal_date,$desc,(int)($_SESSION['user']['id'] ?? 0)]);
    $jid = (int)$pdo->lastInsertId();

    $e1=$pdo->prepare("INSERT INTO acc_entries (journal_id,line_no,account_id,debit,credit,currency,note) VALUES (?,?,?,?,?,'TRY',NULL)");
    $e1->execute([$jid,1,$acc1,$debit,0]);

    $e2=$pdo->prepare("INSERT INTO acc_entries (journal_id,line_no,account_id,debit,credit,currency,note) VALUES (?,?,?,?,?,'TRY',NULL)");
    $e2->execute([$jid,2,$acc2,0,$credit]);

    $pdo->commit();
    $msg="Yevmiye fişi oluşturuldu (draft).";
  }catch(Exception $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    $err=$e->getMessage();
  }
}

if (isset($_GET['post']) && acc_can_edit()) {
  $id = (int)($_GET['post'] ?? 0);
  if ($id>0) {
    $pdo->prepare("UPDATE acc_journals SET status='posted', posted_at=NOW() WHERE company_id=? AND id=?")->execute([$companyId,$id]);
    $msg="Fiş posted yapıldı.";
  }
}

$coa=$pdo->prepare("SELECT id, code, name FROM acc_chart_of_accounts WHERE company_id=? AND is_active=1 ORDER BY code");
$coa->execute([$companyId]);
$accounts=$coa->fetchAll(PDO::FETCH_ASSOC);

$list=$pdo->prepare("SELECT * FROM acc_journals WHERE company_id=? ORDER BY journal_date DESC, id DESC LIMIT 200");
$list->execute([$companyId]);
$rows=$list->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="main">
  <div class="topbar">
    <div><h1>Yevmiye Fişleri</h1><small>Basit, dengeli 2 satır fiş giriş iskeleti (genişletilebilir).</small></div>
    <div class="actions"><a class="btn secondary" href="coa.php">Hesap Planı</a></div>
  </div>

  <?php if($msg): ?><div class="alert ok"><?php echo e($msg); ?></div><?php endif; ?>
  <?php if($err): ?><div class="alert error"><?php echo e($err); ?></div><?php endif; ?>

  <div class="card">
    <h3>Yeni Fiş (2 satır)</h3>
    <form class="form" method="post">
      <div class="row">
        <div><label>Fiş No</label><input class="input" name="journal_no" placeholder="Boş bırakırsan otomatik"></div>
        <div><label>Tarih</label><input class="input" type="date" name="journal_date" value="<?php echo e(date('Y-m-d')); ?>"></div>
        <div><label>Açıklama</label><input class="input" name="description" placeholder="Kısa açıklama"></div>
      </div>

      <div class="row">
        <div>
          <label>Debit Hesap</label>
          <select class="input" name="account_id_1">
            <option value="">Seçiniz</option>
            <?php foreach($accounts as $a): ?>
              <option value="<?php echo (int)$a['id']; ?>"><?php echo e($a['code'].' - '.$a['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label>Credit Hesap</label>
          <select class="input" name="account_id_2">
            <option value="">Seçiniz</option>
            <?php foreach($accounts as $a): ?>
              <option value="<?php echo (int)$a['id']; ?>"><?php echo e($a['code'].' - '.$a['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label>Tutar</label>
          <input class="input" name="debit" type="number" step="0.01" placeholder="Debit" required>
          <input class="input" name="credit" type="number" step="0.01" placeholder="Credit (aynı)" required style="margin-top:8px;">
        </div>
      </div>

      <button class="btn" type="submit" <?php echo acc_can_edit()?'':'disabled'; ?>>Kaydet</button>
    </form>
  </div>

  <div class="card" style="margin-top:14px;">
    <h3>Fiş Listesi (200)</h3>
    <table class="table">
      <thead><tr><th>No</th><th>Tarih</th><th>Durum</th><th>Açıklama</th><th></th></tr></thead>
      <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><strong><?php echo e((string)$r['journal_no']); ?></strong></td>
          <td><?php echo e((string)$r['journal_date']); ?></td>
          <td><?php echo $r['status']==='posted' ? "<span class='badge green'>posted</span>" : "<span class='badge orange'>draft</span>"; ?></td>
          <td><?php echo e(mb_substr((string)($r['description'] ?? ''),0,80,'UTF-8')); ?></td>
          <td>
            <?php if($r['status']==='draft' && acc_can_edit()): ?>
              <a class="btn secondary" href="journals.php?post=<?php echo (int)$r['id']; ?>">Post Et</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if(empty($rows)): ?><tr><td colspan="5"><small>Fiş yok.</small></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
