<?php
$title = 'Muhasebe Dashboard';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';

if (!acc_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);

$posted = (int)$pdo->query("SELECT COALESCE(COUNT(*),0) FROM acc_journals WHERE company_id={$companyId} AND status='posted'")->fetchColumn();
$draft  = (int)$pdo->query("SELECT COALESCE(COUNT(*),0) FROM acc_journals WHERE company_id={$companyId} AND status='draft'")->fetchColumn();

$vat_sales = (float)$pdo->query("SELECT COALESCE(SUM(vat_amount),0) FROM acc_invoices WHERE company_id={$companyId} AND direction='sales' AND status<>'cancelled'")->fetchColumn();
$vat_pur   = (float)$pdo->query("SELECT COALESCE(SUM(vat_amount),0) FROM acc_invoices WHERE company_id={$companyId} AND direction='purchase' AND status<>'cancelled'")->fetchColumn();

$recent = $pdo->prepare("SELECT journal_no, journal_date, status, description FROM acc_journals WHERE company_id=? ORDER BY journal_date DESC, id DESC LIMIT 10");
$recent->execute([$companyId]);
$recentRows = $recent->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="main">
  <div class="topbar">
    <div>
      <h1>Muhasebe Dashboard</h1>
      <small>Yevmiye + KDV + Fatura kayıtlarının merkezi</small>
    </div>
    <div class="actions">
      <a class="btn secondary" href="journals.php">+ Yevmiye</a>
      <a class="btn secondary" href="invoices.php">+ Fatura</a>
      <a class="btn" href="reports.php">Raporlar</a>
    </div>
  </div>

  <div class="grid kpis">
    <div class="card kpi"><h3>Posted Fiş</h3><div class="value"><?php echo (int)$posted; ?></div><div class="hint">Kesinleşmiş</div></div>
    <div class="card kpi"><h3>Draft Fiş</h3><div class="value"><?php echo (int)$draft; ?></div><div class="hint">Kontrol bekliyor</div></div>
    <div class="card kpi"><h3>Satış KDV</h3><div class="value"><?php echo money_fmt($vat_sales,'TRY'); ?></div><div class="hint">Toplam</div></div>
    <div class="card kpi"><h3>Alış KDV</h3><div class="value"><?php echo money_fmt($vat_pur,'TRY'); ?></div><div class="hint">Toplam</div></div>
    <div class="card kpi"><h3>Net KDV</h3><div class="value"><?php echo money_fmt($vat_sales-$vat_pur,'TRY'); ?></div><div class="hint">Satış - Alış</div></div>
    <div class="card kpi"><h3>Kontrol</h3><div class="value"><span class="badge <?php echo (($draft>0)?'orange':'green'); ?>"><?php echo ($draft>0)?'Bekleyen':'Temiz'; ?></span></div><div class="hint">Draft fiş durumu</div></div>
  </div>

  <div class="card" style="margin-top:14px;">
    <h3>Son Yevmiye Fişleri</h3>
    <table class="table">
      <thead><tr><th>No</th><th>Tarih</th><th>Durum</th><th>Açıklama</th></tr></thead>
      <tbody>
        <?php foreach($recentRows as $r): ?>
          <tr>
            <td><strong><?php echo e((string)$r['journal_no']); ?></strong></td>
            <td><?php echo e((string)$r['journal_date']); ?></td>
            <td>
              <?php if($r['status']==='posted'): ?><span class="badge green">posted</span>
              <?php elseif($r['status']==='draft'): ?><span class="badge orange">draft</span>
              <?php else: ?><span class="badge red">cancelled</span><?php endif; ?>
            </td>
            <td><?php echo e(mb_substr((string)($r['description'] ?? ''),0,80,'UTF-8')); ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if(empty($recentRows)): ?><tr><td colspan="4"><small>Henüz fiş yok.</small></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
