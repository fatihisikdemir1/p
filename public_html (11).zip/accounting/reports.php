<?php
$title = 'Raporlar';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';

if (!acc_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


?>
<div class="main">
  <div class="topbar">
    <div><h1>Raporlar</h1><small>Rapor merkezi iskeleti (mizan, gelir tablosu, KDV vb.)</small></div>
  </div>

  <div class="grid" style="grid-template-columns:1fr 1fr;gap:14px;">
    <div class="card">
      <h3>Planlanan Raporlar</h3>
      <ul style="margin:0;padding-left:18px;color:var(--muted);">
        <li>Mizan (Trial Balance)</li>
        <li>Yevmiye Dökümü</li>
        <li>Gelir Tablosu</li>
        <li>KDV Dönem Raporu</li>
      </ul>
      <small>Sonraki adımda tarih aralığı filtreleri ve Excel/PDF çıktısı eklenir.</small>
    </div>
    <div class="card">
      <h3>Kontrol</h3>
      <ul style="margin:0;padding-left:18px;color:var(--muted);">
        <li>Fiş dengesi (debit=credit)</li>
        <li>Draft → Posted onay akışı</li>
        <li>Audit log entegrasyonu</li>
      </ul>
    </div>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
