<?php
$title = 'KDV İzleme';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';

if (!acc_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);

$sum = $pdo->prepare("
  SELECT direction,
         SUM(subtotal) subtotal,
         SUM(vat_amount) vat
  FROM acc_invoices
  WHERE company_id=? AND status<>'cancelled'
  GROUP BY direction
");
$sum->execute([$companyId]);
$rows=$sum->fetchAll(PDO::FETCH_ASSOC);

$salesVat=0; $purVat=0;
foreach($rows as $r){
  if($r['direction']==='sales') $salesVat=(float)$r['vat'];
  if($r['direction']==='purchase') $purVat=(float)$r['vat'];
}
?>
<div class="main">
  <div class="topbar">
    <div><h1>KDV İzleme</h1><small>Satış KDV - Alış KDV = Net KDV (basit özet)</small></div>
    <div class="actions"><a class="btn secondary" href="invoices.php">Faturalar</a></div>
  </div>

  <div class="grid" style="grid-template-columns: 1fr 1fr; gap:14px;">
    <div class="card">
      <h3>Özet</h3>
      <table class="table">
        <tbody>
          <tr><th>Satış KDV</th><td><?php echo money_fmt($salesVat,'TRY'); ?></td></tr>
          <tr><th>Alış KDV</th><td><?php echo money_fmt($purVat,'TRY'); ?></td></tr>
          <tr><th>Net KDV</th><td><span class="badge <?php echo (($salesVat-$purVat)>=0)?'orange':'green'; ?>"><?php echo money_fmt($salesVat-$purVat,'TRY'); ?></span></td></tr>
        </tbody>
      </table>
      <small>Not: Dönem filtresi sonraki adım (ay/yıl) olarak eklenecek.</small>
    </div>

    <div class="card">
      <h3>Kaynak</h3>
      <small>Bu sayfa, <strong>acc_invoices</strong> tablosundaki satış/alış faturalarını toplar.</small>
      <hr style="border:0;border-top:1px solid rgba(17,24,39,.08);margin:12px 0;">
      <small>İstersen bu modülü finans modülündeki hareketlerle (gelir/gider) otomatik bağlarız.</small>
    </div>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
