<?php
$title = 'Ayarlar';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';

if (!acc_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


?>
<div class="main">
  <div class="topbar">
    <div><h1>Ayarlar</h1><small>Muhasebe modülü ayar iskeleti (dönem, para birimi, entegrasyon).</small></div>
  </div>

  <div class="card">
    <h3>Not</h3>
    <small>Bu sayfa şimdilik placeholder. Entegrasyonda: dönem kilitleme, numara şablonları, logo/parasut/netsis export eklenir.</small>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
