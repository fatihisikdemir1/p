<?php
// chat_ajax.php - AJAX için mesaj çekme ve gönderme
require __DIR__ . "/auth.php";

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

// Mesaj gönder
if ($action === 'send' && $_SERVER["REQUEST_METHOD"] === "POST") {
    $toUserId = (int)($_POST['to_user_id'] ?? 0);
    $message = trim($_POST['message'] ?? "");
    
    if ($toUserId > 0 && !empty($message)) {
        $stmt = $pdo->prepare("
            INSERT INTO user_messages (from_user_id, to_user_id, message, is_read, created_at)
            VALUES (?, ?, ?, 0, NOW())
        ");
        $stmt->execute([$userId, $toUserId, $message]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Mesaj gönderildi'
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Geçersiz veri']);
    }
    exit;
}

// Mesajları çek
if ($action === 'fetch') {
    $otherUserId = (int)($_GET['user_id'] ?? 0);
    
    if ($otherUserId > 0) {
        $stmt = $pdo->prepare("
            SELECT m.*, u.name as from_user_name
            FROM user_messages m
            LEFT JOIN users u ON m.from_user_id = u.id
            WHERE (m.from_user_id = ? AND m.to_user_id = ?)
               OR (m.from_user_id = ? AND m.to_user_id = ?)
            ORDER BY m.created_at ASC
        ");
        $stmt->execute([$userId, $otherUserId, $otherUserId, $userId]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Okundu işaretle
        $stmt = $pdo->prepare("UPDATE user_messages SET is_read = 1 WHERE from_user_id = ? AND to_user_id = ?");
        $stmt->execute([$otherUserId, $userId]);
        
        echo json_encode([
            'success' => true,
            'messages' => $messages
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Geçersiz kullanıcı']);
    }
    exit;
}

// Okunmamış mesaj sayısı
if ($action === 'unread_count') {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM user_messages 
        WHERE to_user_id = ? AND is_read = 0
    ");
    $stmt->execute([$userId]);
    $count = $stmt->fetchColumn();
    
    echo json_encode([
        'success' => true,
        'count' => (int)$count
    ]);
    exit;
}

echo json_encode(['success' => false, 'error' => 'Geçersiz action']);