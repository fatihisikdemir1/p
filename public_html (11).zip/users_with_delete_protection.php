<?php
// users_complete.php dosyasindaki silme bolumunu guncelleyin

// KULLANICI SIL - SUPER ADMIN KORUMASI
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "delete_user") {
    $delUserId = (int)($_POST["user_id"] ?? 0);
    
    try {
        if ($delUserId === $userId) {
            throw new Exception("Kendi hesabınızı silemezsiniz!");
        }
        
        $stmt = $pdo->prepare("SELECT company_id, email FROM users WHERE id = ?");
        $stmt->execute([$delUserId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            throw new Exception("Kullanıcı bulunamadı");
        }
        
        // SUPER ADMIN KORUMASI
        if ($user['email'] === 'superadmin@finansconnect.com') {
            throw new Exception("Super Admin hesabı silinemez!");
        }
        
        if (!is_super_admin() && (int)$user['company_id'] !== $companyId) {
            throw new Exception("Bu kullanıcıyı silemezsiniz");
        }
        
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$delUserId]);
        
        $msg = "Kullanıcı silindi!";
        
    } catch (Exception $e) {
        $err = "Hata: " . $e->getMessage();
    }
}

// NOT: users_complete.php dosyasindaki ilgili bolumu bu kodla degistirin