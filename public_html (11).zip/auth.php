<?php
// auth.php - Basit versiyon
session_start();

// Giriş kontrolü
if (!isset($_SESSION['user']['id'])) {
    header("Location: login.php");
    exit;
}

// Kullanıcı bilgileri
$userId = (int)$_SESSION['user']['id'];
$userName = $_SESSION['user']['name'] ?? 'User';
$userRole = $_SESSION['user']['role'] ?? 'user';
$companyId = (int)($_SESSION['user']['company_id'] ?? 0);
$userEmail = $_SESSION['user']['email'] ?? '';

// Database bağlantısı
require __DIR__ . "/config/db.php";

// RBAC fonksiyonları
require __DIR__ . "/enhanced_rbac.php";