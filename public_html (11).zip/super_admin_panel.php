<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require __DIR__ . "/auth.php";

if (!is_super_admin()) {
    die("Bu sayfaya erişim yetkiniz yok.");
}

$page = $_GET['page'] ?? 'companies';
$msg = "";
$err = "";

// FİRMALAR - Oluşturma
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['create_company'])) {
    try {
        $name = trim($_POST['name'] ?? "");
        $email = trim($_POST['email'] ?? "");
        $phone = trim($_POST['phone'] ?? "");
        $address = trim($_POST['address'] ?? "");
        
        if (empty($name)) throw new Exception("Firma adı zorunludur");
        
        $stmt = $pdo->prepare("INSERT INTO companies (name, email, phone, address, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$name, $email, $phone, $address]);
        $msg = "✅ Firma oluşturuldu!";
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// FİRMALAR - Düzenleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['edit_company'])) {
    try {
        $companyId = (int)($_POST['company_id'] ?? 0);
        $name = trim($_POST['name'] ?? "");
        $email = trim($_POST['email'] ?? "");
        $phone = trim($_POST['phone'] ?? "");
        $address = trim($_POST['address'] ?? "");
        
        $stmt = $pdo->prepare("UPDATE companies SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?");
        $stmt->execute([$name, $email, $phone, $address, $companyId]);
        $msg = "✅ Firma güncellendi!";
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// FİRMALAR - Silme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete_company'])) {
    try {
        $companyId = (int)($_POST['company_id'] ?? 0);
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE company_id = ?");
        $stmt->execute([$companyId]);
        if ($stmt->fetchColumn() > 0) throw new Exception("Bu firmaya bağlı kullanıcılar var");
        
        $stmt = $pdo->prepare("DELETE FROM companies WHERE id = ?");
        $stmt->execute([$companyId]);
        $msg = "✅ Firma silindi!";
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// ROLLER - Oluşturma
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['create_role'])) {
    try {
        $roleName = trim($_POST['role_name'] ?? "");
        $roleSlug = trim($_POST['role_slug'] ?? "");
        $permissions = $_POST['permissions'] ?? [];
        
        if (empty($roleName) || empty($roleSlug)) throw new Exception("Rol adı ve slug zorunludur");
        
        $stmt = $pdo->prepare("INSERT INTO roles (role_name, role_slug, permissions, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$roleName, $roleSlug, json_encode($permissions)]);
        $msg = "✅ Rol oluşturuldu!";
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// KULLANICILAR - Oluşturma
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['create_user'])) {
    try {
        $name = trim($_POST['name'] ?? "");
        $email = trim($_POST['email'] ?? "");
        $password = trim($_POST['password'] ?? "");
        $roleId = (int)($_POST['role_id'] ?? 0);
        $companyId = (int)($_POST['company_id'] ?? 0);
        
        if (empty($name) || empty($email) || empty($password)) throw new Exception("Tüm alanlar zorunludur");
        
        // FIX 2: Super Admin rolü kontrolü
        $stmt = $pdo->prepare("SELECT role_slug FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        $roleSlug = $stmt->fetchColumn();
        
        if ($roleSlug === 'super_admin') {
            throw new Exception("Güvenlik: Super Admin rolü ile kullanıcı oluşturamazsınız!");
        }
        
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("INSERT INTO users (company_id, name, email, password, role_id, role, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$companyId > 0 ? $companyId : null, $name, $email, $hashedPassword, $roleId, $roleSlug]);
        $msg = "✅ Kullanıcı oluşturuldu!";
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Veri çekme
$companies = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM users WHERE company_id = c.id) as user_count FROM companies c ORDER BY c.name")->fetchAll(PDO::FETCH_ASSOC);
$roles = $pdo->query("SELECT r.*, (SELECT COUNT(*) FROM users WHERE role_id = r.id) as user_count FROM roles r ORDER BY r.role_name")->fetchAll(PDO::FETCH_ASSOC);
$users = $pdo->query("SELECT u.*, c.name as company_name, r.role_name FROM users u LEFT JOIN companies c ON u.company_id = c.id LEFT JOIN roles r ON u.role_id = r.id ORDER BY u.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

$allPermissions = [
    'manage_users' => 'Kullanıcı Yönetimi',
    'manage_roles' => 'Rol Yönetimi',
    'view_all_tasks' => 'Tüm Görevleri Görüntüle',
    'manage_projects' => 'Proje Yönetimi',
    'manage_companies' => 'Firma Yönetimi',
    'view_reports' => 'Raporları Görüntüle',
    'manage_settings' => 'Ayarları Yönet'
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Super Admin Panel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 30px; }
.container-custom { max-width: 1600px; margin: 0 auto; }
.header-card { background: white; border-radius: 15px; padding: 20px 30px; margin-bottom: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.content-card { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); margin-bottom: 20px; }
.nav-tabs .nav-link { color: #667eea; font-weight: 600; border-radius: 10px 10px 0 0; }
.nav-tabs .nav-link.active { background: linear-gradient(135deg, #667eea, #764ba2); color: white; }
.company-card, .role-card { background: white; border: 2px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 15px; transition: all 0.3s; }
.company-card:hover, .role-card:hover { border-color: #667eea; box-shadow: 0 5px 20px rgba(102, 126, 234, 0.2); }
</style>
</head>
<body>

<div class="container-custom">
    
    <div class="header-card">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h2 class="mb-0" style="color: #667eea;"><i class="bi bi-shield-lock-fill"></i> Super Admin Panel</h2>
            </div>
            <div class="col-md-4 text-center">
                <span class="badge bg-danger" style="font-size: 16px; padding: 10px 20px;">SUPER ADMIN</span>
            </div>
            <div class="col-md-4 text-end">
                <a href="dashboard.php" class="btn btn-primary">
                    <i class="bi bi-house"></i> Dashboard
                </a>
            </div>
        </div>
    </div>

    <?php if ($msg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $msg ?>
        </div>
    <?php endif; ?>
    
    <?php if ($err): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $err ?>
        </div>
    <?php endif; ?>

    <div class="content-card">
        
        <ul class="nav nav-tabs mb-4" role="tablist">
            <li class="nav-item">
                <a class="nav-link <?= $page === 'companies' ? 'active' : '' ?>" href="?page=companies">
                    <i class="bi bi-building"></i> Firmalar (<?= count($companies) ?>)
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $page === 'roles' ? 'active' : '' ?>" href="?page=roles">
                    <i class="bi bi-shield-lock"></i> Roller (<?= count($roles) ?>)
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $page === 'users' ? 'active' : '' ?>" href="?page=users">
                    <i class="bi bi-people"></i> Kullanıcılar (<?= count($users) ?>)
                </a>
            </li>
        </ul>

        <!-- FİRMALAR -->
        <?php if ($page === 'companies'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4><i class="bi bi-building-fill"></i> Firmalar</h4>
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createCompanyModal">
                    <i class="bi bi-plus-circle"></i> Yeni Firma
                </button>
            </div>

            <div class="row">
                <?php foreach ($companies as $company): ?>
                <div class="col-md-4">
                    <div class="company-card">
                        <h5 style="color: #667eea;"><i class="bi bi-building"></i> <?= htmlspecialchars($company['name']) ?></h5>
                        <?php if ($company['email']): ?>
                        <p class="mb-1 small"><i class="bi bi-envelope"></i> <?= htmlspecialchars($company['email']) ?></p>
                        <?php endif; ?>
                        <hr>
                        <div class="text-center mb-3">
                            <strong style="color: #667eea;"><?= (int)$company['user_count'] ?></strong> kullanıcı
                        </div>
                        <div class="d-flex gap-2">
                            <button class="btn btn-sm btn-warning flex-fill" onclick='editCompany(<?= json_encode($company) ?>)'>
                                <i class="bi bi-pencil"></i> Düzenle
                            </button>
                            <?php if ((int)$company['user_count'] === 0): ?>
                            <button class="btn btn-sm btn-danger" onclick="deleteCompany(<?= $company['id'] ?>, '<?= htmlspecialchars($company['name'], ENT_QUOTES) ?>')">
                                <i class="bi bi-trash"></i>
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- ROLLER -->
        <?php if ($page === 'roles'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4><i class="bi bi-shield-check"></i> Roller</h4>
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createRoleModal">
                    <i class="bi bi-plus-circle"></i> Yeni Rol
                </button>
            </div>

            <?php foreach ($roles as $role): ?>
            <div class="role-card">
                <div class="row align-items-center">
                    <div class="col-md-10">
                        <h5 style="color: #667eea;"><i class="bi bi-shield"></i> <?= htmlspecialchars($role['role_name']) ?></h5>
                        <small class="text-muted"><code><?= htmlspecialchars($role['role_slug']) ?></code></small>
                        <span class="badge bg-info ms-2"><?= (int)$role['user_count'] ?> kullanıcı</span>
                    </div>
                    <div class="col-md-2 text-end">
                        <button class="btn btn-sm btn-warning" disabled>
                            <i class="bi bi-pencil"></i>
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <!-- KULLANICILAR -->
        <?php if ($page === 'users'): ?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4><i class="bi bi-person-lines-fill"></i> Kullanıcılar</h4>
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createUserModal">
                    <i class="bi bi-person-plus"></i> Yeni Kullanıcı
                </button>
            </div>

            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Ad</th>
                            <th>Email</th>
                            <th>Firma</th>
                            <th>Rol</th>
                            <th>Tarih</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($user['name']) ?></strong></td>
                            <td><?= htmlspecialchars($user['email']) ?></td>
                            <td><?= $user['company_name'] ? htmlspecialchars($user['company_name']) : '-' ?></td>
                            <td><span class="badge bg-primary"><?= htmlspecialchars($user['role_name'] ?? $user['role']) ?></span></td>
                            <td><small><?= date('d.m.Y', strtotime($user['created_at'])) ?></small></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

    </div>

</div>

<!-- Firma Oluştur Modal -->
<div class="modal fade" id="createCompanyModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
                <h5 class="modal-title">Yeni Firma</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Firma Adı *</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Telefon</label>
                        <input type="text" name="phone" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Adres</label>
                        <textarea name="address" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="create_company" class="btn btn-success">Oluştur</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Firma Düzenle Modal -->
<div class="modal fade" id="editCompanyModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title">Firma Düzenle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="company_id" id="edit_company_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Firma Adı *</label>
                        <input type="text" name="name" id="edit_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" id="edit_email" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Telefon</label>
                        <input type="text" name="phone" id="edit_phone" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Adres</label>
                        <textarea name="address" id="edit_address" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="edit_company" class="btn btn-warning">Güncelle</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Rol Oluştur Modal -->
<div class="modal fade" id="createRoleModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
                <h5 class="modal-title">Yeni Rol</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Rol Adı *</label>
                            <input type="text" name="role_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Slug *</label>
                            <input type="text" name="role_slug" class="form-control" required>
                        </div>
                    </div>
                    <hr>
                    <label class="form-label fw-bold">Yetkiler</label>
                    <div class="row">
                        <?php foreach ($allPermissions as $slug => $name): ?>
                        <div class="col-md-6 mb-2">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="permissions[]" value="<?= $slug ?>" id="perm_<?= $slug ?>">
                                <label class="form-check-label" for="perm_<?= $slug ?>"><?= $name ?></label>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="create_role" class="btn btn-success">Oluştur</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Kullanıcı Oluştur Modal -->
<div class="modal fade" id="createUserModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
                <h5 class="modal-title">Yeni Kullanıcı</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Ad Soyad *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email *</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Şifre *</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Rol *</label>
                            <select name="role_id" class="form-select" required>
                                <option value="">Seçiniz...</option>
                                <?php foreach ($roles as $role): ?>
                                    <?php if ($role['role_slug'] !== 'super_admin'): ?>
                                        <option value="<?= $role['id'] ?>"><?= htmlspecialchars($role['role_name']) ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Firma</label>
                        <select name="company_id" class="form-select">
                            <option value="0">Firma Yok</option>
                            <?php foreach ($companies as $company): ?>
                                <option value="<?= $company['id'] ?>"><?= htmlspecialchars($company['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="create_user" class="btn btn-success">Oluştur</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function editCompany(company) {
    document.getElementById('edit_company_id').value = company.id;
    document.getElementById('edit_name').value = company.name;
    document.getElementById('edit_email').value = company.email || '';
    document.getElementById('edit_phone').value = company.phone || '';
    document.getElementById('edit_address').value = company.address || '';
    new bootstrap.Modal(document.getElementById('editCompanyModal')).show();
}

function deleteCompany(id, name) {
    if (confirm(name + ' firmasını silmek istediğinize emin misiniz?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = '<input type="hidden" name="company_id" value="' + id + '"><input type="hidden" name="delete_company" value="1">';
        document.body.appendChild(form);
        form.submit();
    }
}
</script>
</body>
</html>