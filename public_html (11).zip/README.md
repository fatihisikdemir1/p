# FINANSCONNECT EXECUTIVE OS — Billing/Entitlements Pack

This pack implements a **global SaaS-ready** subscription model:

- **Tenant** (customer group) → **Entities** (legal entities)
- **Plan** contains **entitlements/limits** (no pricing required yet)
- **Subscription** binds Tenant → Plan
- **Modules** are add-ons toggled per subscription
- **FeatureGate** provides fast checks for modules/features

## Contents

- `database/2026_03_04_saas_billing.sql` — database schema
- `app/Core/FeatureGate.php` — entitlement cache + checks
- `app/Middleware/RequireModule.php` — module gate middleware
- `app/Controllers/BillingAdminController.php` — minimal admin controller
- `app/Views/admin/billing.php` — minimal admin view
- `routes/example_routes.php` — example route registrations

## Quick integration checklist

1. Ensure you have `DB::pdo()` (PDO) in your project (matches your existing style).
2. In your login flow, set:
   - `$_SESSION['tenant_id']` (map from company_id if you already have it)
   - `$_SESSION['role']` with values: `super_admin`, `company_admin`, `user`
3. Protect each module entry controller:
   - `RequireModule::check('finance');` etc.
4. Add admin routes and a nav link for Super Admin only.

> Pricing fields are present but optional (nullable). You can add Stripe/etc later.
