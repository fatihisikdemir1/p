<?php
declare(strict_types=1);

session_start();
require __DIR__ . "/config/db.php";
require __DIR__ . "/config/rbac.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $email = trim((string)($_POST["email"] ?? ""));
  $password = (string)($_POST["password"] ?? "");

  $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
  $stmt->execute([$email]);
  $user = $stmt->fetch(PDO::FETCH_ASSOC);

  // users.password hashed olmalı
  if ($user && !empty($user["password"]) && password_verify($password, (string)$user["password"])) {
    $_SESSION["user"] = [
      "id"         => (int)$user["id"],
      "name"       => (string)($user["name"] ?? "Kullanıcı"),
      "role"       => normalize_role((string)($user["role"] ?? "user")),
      "company_id" => (int)($user["company_id"] ?? 0),
      "email"      => (string)($user["email"] ?? ""),
    ];
    header("Location: dashboard.php");
    exit;
  }

  $error = "E-posta veya şifre hatalı";
}
?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Workflow Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-3">
<div class="container" style="max-width:420px">
  <h3 class="mb-3">Giriş</h3>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="post" class="card p-3">
    <input class="form-control mb-2" type="email" name="email" placeholder="E-posta" required>
    <input class="form-control mb-3" type="password" name="password" placeholder="Şifre" required>
    <button class="btn btn-primary" type="submit">Giriş Yap</button>
  </form>
</div>
</body>
</html>
