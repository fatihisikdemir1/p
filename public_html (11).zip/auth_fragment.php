<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (!isset($_SESSION["user"])) {
    http_response_code(401);
    echo '<div class="p-3">';
    echo '<div class="alert alert-warning mb-0">';
    echo '<strong>Oturum kapalı.</strong> Lütfen tekrar giriş yap.';
    echo '</div>';
    echo '</div>';
    exit;
}
