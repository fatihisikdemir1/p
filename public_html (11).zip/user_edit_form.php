<?php
require __DIR__ . "/auth.php";

if (!has_permission('manage_users')) {
    die("Yetkiniz yok");
}

$userId_toEdit = (int)($_GET['user_id'] ?? 0);

// Kullanıcı bilgilerini çek
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId_toEdit]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("Kullanıcı bulunamadı");
}

// Yetki kontrolü - company admin sadece kendi şirketini düzenleyebilir
if (!is_super_admin() && (int)$user['company_id'] !== $companyId) {
    die("Bu kullanıcıyı düzenleyemezsiniz");
}

// Roller
if (is_super_admin()) {
    $roles = $pdo->query("SELECT * FROM roles ORDER BY role_name")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("SELECT * FROM roles WHERE company_id = ? OR company_id IS NULL ORDER BY role_name");
    $stmt->execute([$companyId]);
    $roles = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Şirketler (sadece super admin için)
$companies = [];
if (is_super_admin()) {
    $companies = $pdo->query("SELECT * FROM companies ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
}

// Güncelleme işlemi
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        $name = trim($_POST["name"] ?? "");
        $email = trim($_POST["email"] ?? "");
        $roleId = (int)($_POST["role_id"] ?? 0);
        $phone = trim($_POST["phone"] ?? "");
        $department = trim($_POST["department"] ?? "");
        $position = trim($_POST["position"] ?? "");
        $newPassword = trim($_POST["new_password"] ?? "");
        $userCompanyId = is_super_admin() ? ((int)($_POST["company_id"] ?? 0)) : $companyId;
        
        if (empty($name) || empty($email)) {
            throw new Exception("Ad ve email zorunludur");
        }
        
        // Email kontrolü
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $userId_toEdit]);
        if ($stmt->fetch()) {
            throw new Exception("Bu email başka bir kullanıcıya ait!");
        }
        
        // Rol kontrolü
        $stmt = $pdo->prepare("SELECT role_slug FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        $roleSlug = $stmt->fetchColumn();
        
        if (!$roleSlug) {
            throw new Exception("Geçersiz rol");
        }
        
        // Güncelle
        if (!empty($newPassword)) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("
                UPDATE users SET 
                    name = ?, email = ?, password = ?, role_id = ?, role = ?,
                    phone = ?, department = ?, position = ?, company_id = ?,
                    password_changed_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([
                $name, $email, $hashedPassword, $roleId, $roleSlug,
                $phone ?: null, $department ?: null, $position ?: null,
                $userCompanyId > 0 ? $userCompanyId : null,
                $userId_toEdit
            ]);
        } else {
            $stmt = $pdo->prepare("
                UPDATE users SET 
                    name = ?, email = ?, role_id = ?, role = ?,
                    phone = ?, department = ?, position = ?, company_id = ?
                WHERE id = ?
            ");
            $stmt->execute([
                $name, $email, $roleId, $roleSlug,
                $phone ?: null, $department ?: null, $position ?: null,
                $userCompanyId > 0 ? $userCompanyId : null,
                $userId_toEdit
            ]);
        }
        
        echo '<div class="alert alert-success">Kullanıcı güncellendi! Sayfa yenileniyor...</div>';
        echo '<script>setTimeout(() => window.location.reload(), 1500);</script>';
        exit;
        
    } catch (Exception $e) {
        echo '<div class="alert alert-danger">' . htmlspecialchars($e->getMessage()) . '</div>';
    }
}
?>

<form method="post">
    <div class="modal-body">
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Ad Soyad *</label>
                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Email *</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Telefon</label>
                <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="+90 555 123 4567">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Yeni Şifre</label>
                <input type="password" name="new_password" class="form-control" placeholder="Boş bırakın (değiştirmek istemiyorsanız)">
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Departman</label>
                <input type="text" name="department" class="form-control" value="<?= htmlspecialchars($user['department'] ?? '') ?>" placeholder="Muhasebe, İK, vb.">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Pozisyon</label>
                <input type="text" name="position" class="form-control" value="<?= htmlspecialchars($user['position'] ?? '') ?>" placeholder="Müdür, Uzman, vb.">
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Rol *</label>
                <select name="role_id" class="form-select" required>
                    <option value="">Seçiniz...</option>
                    <?php foreach ($roles as $role): ?>
                        <option value="<?= (int)$role['id'] ?>" <?= (int)$user['role_id'] === (int)$role['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($role['role_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <?php if (is_super_admin()): ?>
            <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Şirket</label>
                <select name="company_id" class="form-select">
                    <option value="0">Seçiniz...</option>
                    <?php foreach ($companies as $company): ?>
                        <option value="<?= (int)$company['id'] ?>" <?= (int)$user['company_id'] === (int)$company['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($company['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
        <button type="submit" class="btn btn-primary">
            <i class="bi bi-check-circle"></i> Güncelle
        </button>
    </div>
</form>