<?php
declare(strict_types=1);

/**
 * AUTH – SINGLE SESSION GUARD
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* DB */
require_once __DIR__ . "/config/db.php";

/* LOGIN KONTROL */
if (!isset($_SESSION["user"])) {
    // API çağrısı mı?
    if (str_contains($_SERVER["REQUEST_URI"], ".php") && $_SERVER["REQUEST_METHOD"] !== "GET") {
        http_response_code(401);
        echo json_encode([
            "ok" => false,
            "error" => "Oturum açılmamış"
        ]);
        exit;
    }

    // Normal sayfa ise
    header("Location: /login.php");
    exit;
}

/* USER CONTEXT */
$userId   = (int)$_SESSION["user"]["id"];
$userName = $_SESSION["user"]["name"] ?? "Kullanıcı";
$userRole = $_SESSION["user"]["role"] ?? "member";
