<?php
// menu.php - Shared Sidebar (Tasks + Finance + Procurement + Credit)
if (!function_exists('e')) {
  function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
}
$current_uri = $_SERVER['REQUEST_URI'] ?? '';
function active_item(string $needle): string {
  global $current_uri;
  return (strpos($current_uri, $needle) !== false) ? 'active' : '';
}
$uName = $_SESSION['user']['name'] ?? 'Kullanıcı';
$role  = $_SESSION['user']['role'] ?? 'user';
?>
<aside class="sidebar">
  <div class="brand">
    <div class="t"><i class="bi bi-grid-1x2"></i> FinansConnect</div>
    <div class="s"><?= e($uName) ?> • <?= e($role) ?></div>
  </div>

  <div class="sec">Çekirdek</div>
  <a class="item <?= active_item('/dashboard.php') ?>" href="/dashboard.php"><i class="bi bi-speedometer2"></i><span>Dashboard</span></a>
  <a class="item <?= active_item('/task.php') ?>" href="/task.php"><i class="bi bi-check2-square"></i><span>Görevler</span></a>
  <a class="item <?= active_item('/projects.php') ?>" href="/projects.php"><i class="bi bi-kanban"></i><span>Projeler</span></a>

  <div class="sec">Yönetim</div>
  <a class="item <?= active_item('/companies.php') ?>" href="/companies.php"><i class="bi bi-buildings"></i><span>Şirketler</span></a>
  <a class="item <?= active_item('/users.php') ?>" href="/users.php"><i class="bi bi-people"></i><span>Kullanıcılar</span></a>
  <a class="item <?= active_item('/roles_manage.php') ?>" href="/roles_manage.php"><i class="bi bi-shield-lock"></i><span>Roller & Yetkiler</span></a>
  <a class="item <?= active_item('/notifications.php') ?>" href="/notifications.php"><i class="bi bi-bell"></i><span>Bildirimler</span></a>
  <a class="item <?= active_item('/settings.php') ?>" href="/settings.php"><i class="bi bi-gear"></i><span>Ayarlar</span></a>

  <div class="sec">Modüller</div>
  <a class="item <?= active_item('/finance/') ?>" href="/finance/dashboard.php"><i class="bi bi-graph-up"></i><span>Finans</span></a>
  <a class="item <?= active_item('/procurement/') ?>" href="/procurement/views/dashboard.php"><i class="bi bi-bag-check"></i><span>Satınalma</span></a>
  <a class="item <?= active_item('/credit/') ?>" href="/credit/dashboard.php"><i class="bi bi-bank"></i><span>Kredi Takip</span></a>

  <div class="sec">Hızlı</div>
  <a class="item" href="/modules.php"><i class="bi bi-app-indicator"></i><span>Modül Seç</span></a>
  <a class="item" href="/logout.php"><i class="bi bi-box-arrow-right"></i><span>Çıkış</span></a>
</aside>
