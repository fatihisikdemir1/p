<?php
// shared/layout_head.php
// expects: $pageTitle (string), optional $current (string), optional $breadcrumbs (array), optional $topbarRight (callable)
if (!isset($pageTitle)) { $pageTitle = "FinansConnect"; }
if (!function_exists('e')) {
  function e($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}
$current = $current ?? ($_SERVER['REQUEST_URI'] ?? '');
$crumbs = $breadcrumbs ?? [];
?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle) ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="/shared/assets/fc-core.css?v=1">
  <style>
    /* Root app small additions */
    .content{flex:1;padding:18px 18px 26px}
    .topbar{display:flex;align-items:center;justify-content:space-between;gap:14px;background:rgba(255,255,255,.75);border:1px solid var(--line);border-radius:16px;padding:12px 14px;box-shadow:var(--shadow);backdrop-filter: blur(8px)}
    .crumbs{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
    .crumbs a{opacity:.75;text-decoration:none;font-weight:900}
    .crumbs .sep{opacity:.35}
    .search{display:flex;align-items:center;gap:10px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px 12px;min-width:min(520px, 55vw)}
    .search input{border:0;outline:0;width:100%;font-weight:800}
    .pill{display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;border:1px solid var(--line);background:#fff;font-weight:900}
    .grid{display:grid;gap:14px}
    .card{background:var(--card);border:1px solid var(--line);border-radius:16px;box-shadow:var(--shadow)}
    .card .hd{padding:14px 16px;border-bottom:1px solid var(--line);font-weight:950;display:flex;align-items:center;justify-content:space-between;gap:10px}
    .card .bd{padding:14px 16px}
    .btn{display:inline-flex;align-items:center;gap:10px;padding:10px 12px;border-radius:14px;border:1px solid var(--line);background:#fff;font-weight:950;text-decoration:none}
    .btn.primary{background:linear-gradient(180deg,var(--navy),var(--navy2));color:#fff;border-color:rgba(255,255,255,.12)}
    .btn.primary:hover{filter:brightness(1.04)}
    .btn:hover{transform:translateY(-1px)}
    @media (max-width: 980px){
      .sidebar{width:84px}
      .brand .s, .sec{display:none}
      .item{justify-content:center}
      .item span{display:none}
      .search{min-width:unset;width:100%}
      .topbar{flex-wrap:wrap}
    }
  </style>
  <?php if (!empty($extraHead)) { echo $extraHead; } ?>
</head>
<body>
<div class="layout">
