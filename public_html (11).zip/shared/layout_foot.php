<?php // shared/layout_foot.php ?>
</div>
<script>
  // minimal: remember sidebar collapsed on mobile
</script>
</body>
</html>
