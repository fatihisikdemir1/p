<?php
require __DIR__ . "/auth.php";

$projectId = (int)($_GET['id'] ?? 0);

// Proje bilgilerini çek
$stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
$stmt->execute([$projectId]);
$project = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$project) {
    die("Proje bulunamadı");
}

// Yetki kontrolü
if (!is_super_admin() && (int)$project['company_id'] !== $companyId) {
    die("Bu projeyi düzenleyemezsiniz");
}

$msg = "";
$err = "";

// Güncelleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update'])) {
    try {
        $name = trim($_POST["name"] ?? "");
        $description = trim($_POST["description"] ?? "");
        $projectCompanyId = is_super_admin() ? ((int)($_POST["company_id"] ?? 0)) : $companyId;
        
        if (empty($name)) {
            throw new Exception("Proje adı zorunludur");
        }
        
        $stmt = $pdo->prepare("
            UPDATE projects SET 
                name = ?, description = ?, company_id = ?
            WHERE id = ?
        ");
        $stmt->execute([$name, $description ?: null, $projectCompanyId > 0 ? $projectCompanyId : null, $projectId]);
        
        $msg = "Proje güncellendi!";
        
        // Güncel bilgiyi tekrar çek
        $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
        $stmt->execute([$projectId]);
        $project = $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        $err = $e->getMessage();
    }
}

// Silme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete'])) {
    try {
        // Projeye bağlı görevleri kontrol et
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE project_id = ?");
        $stmt->execute([$projectId]);
        $taskCount = $stmt->fetchColumn();
        
        if ($taskCount > 0) {
            throw new Exception("Bu projede $taskCount görev var. Önce görevleri silin veya başka projeye taşıyın.");
        }
        
        $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
        $stmt->execute([$projectId]);
        
        header("Location: projects.php?msg=deleted");
        exit;
        
    } catch (Exception $e) {
        $err = $e->getMessage();
    }
}

// Şirketler (sadece super admin için)
$companies = [];
if (is_super_admin()) {
    $companies = $pdo->query("SELECT * FROM companies ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Proje Düzenle</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); min-height: 100vh; padding: 30px; }
.container-card { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); max-width: 800px; margin: 0 auto; }
.btn-update { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color: white; border: none; }
.btn-update:hover { background: linear-gradient(135deg, #1e293b 0%, #1e3a8a 100%); color: white; }
</style>
</head>
<body>

<div class="container-card">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi bi-pencil-square"></i> Proje Düzenle</h2>
        <a href="projects.php" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Geri
        </a>
    </div>

    <?php if($msg): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= htmlspecialchars($msg) ?>
        </div>
    <?php endif; ?>
    
    <?php if($err): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= htmlspecialchars($err) ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label class="form-label fw-bold">Proje Adı *</label>
            <input type="text" name="name" class="form-control form-control-lg" value="<?= htmlspecialchars($project['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold">Açıklama</label>
            <textarea name="description" class="form-control" rows="5"><?= htmlspecialchars($project['description'] ?? '') ?></textarea>
        </div>

        <?php if (is_super_admin()): ?>
        <div class="mb-3">
            <label class="form-label fw-bold">Şirket</label>
            <select name="company_id" class="form-select form-select-lg">
                <option value="0">Seçiniz...</option>
                <?php foreach ($companies as $company): ?>
                    <option value="<?= (int)$company['id'] ?>" <?= (int)$project['company_id'] === (int)$company['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($company['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between mt-4">
            <div>
                <button type="submit" name="update" class="btn btn-update btn-lg">
                    <i class="bi bi-check-circle"></i> Güncelle
                </button>
                <a href="projects.php" class="btn btn-secondary btn-lg">İptal</a>
            </div>
            <button type="button" class="btn btn-danger btn-lg" onclick="confirmDelete()">
                <i class="bi bi-trash"></i> Projeyi Sil
            </button>
        </div>
    </form>
</div>

<!-- Silme Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Projeyi Sil</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p><strong><?= htmlspecialchars($project['name']) ?></strong> projesini silmek istediğinize emin misiniz?</p>
                <p class="text-danger mb-0"><i class="bi bi-exclamation-triangle"></i> Bu işlem geri alınamaz!</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                <form method="post" style="display:inline;">
                    <button type="submit" name="delete" class="btn btn-danger">
                        <i class="bi bi-trash"></i> Evet, Sil
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function confirmDelete() {
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    modal.show();
}
</script>
</body>
</html>