<?php
require __DIR__ . "/config/db.php";

$DAYS_BEFORE = 2;
$FROM_EMAIL  = "noreply@finansconnect.com";
$FROM_NAME   = "Workflow Sistemi";

$targetDate = date("Y-m-d", strtotime("+$DAYS_BEFORE days"));

$stmt = $pdo->prepare("
    SELECT
        t.id,
        t.title,
        t.due_date,
        t.assigned_to,
        u.email,
        u.name
    FROM tasks t
    JOIN users u ON u.id = t.assigned_to
    WHERE
        t.due_date = ?
        AND t.reminder_sent = 0
");
$stmt->execute([$targetDate]);

$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($tasks as $task) {

    // MAIL
    $to = $task["email"];
    $subject = "⏰ Görev Termin Hatırlatması";
    $message = "
Merhaba {$task['name']},

'{$task['title']}' adlı görevin termin tarihi {$task['due_date']}.

Lütfen zamanında tamamla.

Workflow Sistemi
";
    $headers  = "From: $FROM_NAME <$FROM_EMAIL>\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8";

    mail($to, $subject, $message, $headers);

    // EKRAN İÇİ BİLDİRİM
    $ins = $pdo->prepare("
        INSERT INTO notifications (user_id, task_id, message)
        VALUES (?,?,?)
    ");
    $ins->execute([
        $task["assigned_to"],
        $task["id"],
        "⏰ '{$task['title']}' görevinin termin tarihi yaklaşıyor!"
    ]);

    // Tekrar gönderilmesin
    $pdo->prepare("UPDATE tasks SET reminder_sent = 1 WHERE id = ?")
        ->execute([$task["id"]]);
}
