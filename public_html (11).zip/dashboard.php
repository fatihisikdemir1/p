<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require __DIR__ . "/auth.php";

// Mesaj gönderme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['send_message'])) {
    try {
        $toUserId = (int)($_POST['to_user_id'] ?? 0);
        $message = trim($_POST['message'] ?? "");
        
        if ($toUserId > 0 && !empty($message)) {
            $stmt = $pdo->prepare("INSERT INTO user_messages (from_user_id, to_user_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
            $stmt->execute([$userId, $toUserId, $message]);
        }
    } catch (Exception $e) {
        // Silent fail
    }
}

// Aktif sohbet
$activeChatUserId = (int)($_GET['chat'] ?? 0);

// Kullanıcılar
if (is_super_admin()) {
    $chatUsers = $pdo->query("SELECT id, name FROM users WHERE id != $userId ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE company_id = ? AND id != ? ORDER BY name");
    $stmt->execute([$companyId, $userId]);
    $chatUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Okunmamış sayıları
$unreadCounts = [];
$totalUnread = 0;
foreach ($chatUsers as $chatUser) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_messages WHERE from_user_id = ? AND to_user_id = ? AND is_read = 0");
        $stmt->execute([$chatUser['id'], $userId]);
        $count = (int)$stmt->fetchColumn();
        $unreadCounts[$chatUser['id']] = $count;
        $totalUnread += $count;
    } catch (Exception $e) {
        $unreadCounts[$chatUser['id']] = 0;
    }
}

// Aktif sohbet mesajları
$chatMessages = [];
$activeChatUserName = '';
if ($activeChatUserId > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT m.*, u.name as from_user_name
            FROM user_messages m
            LEFT JOIN users u ON m.from_user_id = u.id
            WHERE (m.from_user_id = ? AND m.to_user_id = ?)
               OR (m.from_user_id = ? AND m.to_user_id = ?)
            ORDER BY m.created_at ASC
            LIMIT 50
        ");
        $stmt->execute([$userId, $activeChatUserId, $activeChatUserId, $userId]);
        $chatMessages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $stmt = $pdo->prepare("UPDATE user_messages SET is_read = 1 WHERE from_user_id = ? AND to_user_id = ?");
        $stmt->execute([$activeChatUserId, $userId]);
        
        $stmt = $pdo->prepare("SELECT name FROM users WHERE id = ?");
        $stmt->execute([$activeChatUserId]);
        $activeChatUserName = $stmt->fetchColumn();
    } catch (Exception $e) {
        // Silent fail
    }
}

// Tag'ler
$userTags = [];
try {
    $stmt = $pdo->prepare("
        SELECT tt.*, t.title as task_title
        FROM task_tags tt
        INNER JOIN tasks t ON tt.task_id = t.id
        WHERE tt.user_id = ?
        ORDER BY tt.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$userId]);
    $userTags = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Tablo yoksa boş
}

// Projeler ve görevler
$projects = [];
try {
    if (is_super_admin()) {
        $stmt = $pdo->query("
            SELECT p.*, 
                   (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count
            FROM projects p
            ORDER BY p.created_at DESC
        ");
        $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($userRole === 'company_admin') {
        $stmt = $pdo->prepare("
            SELECT p.*, 
                   (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count
            FROM projects p
            WHERE p.company_id = ?
            ORDER BY p.created_at DESC
        ");
        $stmt->execute([$companyId]);
        $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $stmt = $pdo->prepare("
            SELECT p.*, 
                   (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count
            FROM projects p
            WHERE p.company_id = ? AND p.created_by = ?
            ORDER BY p.created_at DESC
        ");
        $stmt->execute([$companyId, $userId]);
        $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Her proje için görevleri çek
    foreach ($projects as &$project) {
        if ($userRole === 'user') {
            $stmt = $pdo->prepare("
                SELECT t.*, u.name as assigned_user_name
                FROM tasks t
                LEFT JOIN users u ON t.assigned_to = u.id
                WHERE t.project_id = ? AND (t.assigned_to = ? OR t.created_by = ?)
                ORDER BY t.created_at DESC
            ");
            $stmt->execute([$project['id'], $userId, $userId]);
        } else {
            $stmt = $pdo->prepare("
                SELECT t.*, u.name as assigned_user_name
                FROM tasks t
                LEFT JOIN users u ON t.assigned_to = u.id
                WHERE t.project_id = ?
                ORDER BY t.created_at DESC
            ");
            $stmt->execute([$project['id']]);
        }
        $project['tasks'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    // Hata olursa boş
}

// İstatistikler
if (is_super_admin()) {
    $userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $projectCount = $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
    $taskCount = $pdo->query("SELECT COUNT(*) FROM tasks")->fetchColumn();
    $completedCount = $pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'completed'")->fetchColumn();
} elseif ($userRole === 'company_admin') {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE company_id = ?");
    $stmt->execute([$companyId]);
    $userCount = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE company_id = ?");
    $stmt->execute([$companyId]);
    $projectCount = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks t LEFT JOIN projects p ON t.project_id = p.id WHERE p.company_id = ?");
    $stmt->execute([$companyId]);
    $taskCount = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks t LEFT JOIN projects p ON t.project_id = p.id WHERE p.company_id = ? AND t.status = 'completed'");
    $stmt->execute([$companyId]);
    $completedCount = $stmt->fetchColumn();
} else {
    $userCount = 1;
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE company_id = ? AND created_by = ?");
    $stmt->execute([$companyId, $userId]);
    $projectCount = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks t LEFT JOIN projects p ON t.project_id = p.id WHERE p.company_id = ? AND (t.assigned_to = ? OR t.created_by = ?)");
    $stmt->execute([$companyId, $userId, $userId]);
    $taskCount = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks t LEFT JOIN projects p ON t.project_id = p.id WHERE p.company_id = ? AND (t.assigned_to = ? OR t.created_by = ?) AND t.status = 'completed'");
    $stmt->execute([$companyId, $userId, $userId]);
    $completedCount = $stmt->fetchColumn();
}

// Firma adı
$companyName = "";
if (!is_super_admin()) {
    $stmt = $pdo->prepare("SELECT name FROM companies WHERE id = ?");
    $stmt->execute([$companyId]);
    $companyName = $stmt->fetchColumn();
}

// Mesaj gönderme için AJAX
if (isset($_GET['ajax']) && $_GET['ajax'] === 'send_message' && $_SERVER["REQUEST_METHOD"] === "POST") {
    header('Content-Type: application/json');
    try {
        $toUserId = (int)($_POST['to_user_id'] ?? 0);
        $message = trim($_POST['message'] ?? "");
        
        if ($toUserId > 0 && !empty($message)) {
            $stmt = $pdo->prepare("INSERT INTO user_messages (from_user_id, to_user_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
            $stmt->execute([$userId, $toUserId, $message]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid data']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}
?>
<?php
$pageTitle = 'FinansConnect • Dashboard';
$breadcrumbs = array(array('label' => 'FinansConnect', 'href' => '/dashboard.php'), array('label' => 'Dashboard', 'href' => null));
$extraHead = '<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { 
    font-family: \'Inter\', -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    overflow-x: hidden;
}

.dashboard-container { 
    display: grid; 
    grid-template-columns: 280px 1fr 380px;
    height: 100vh;
    gap: 0;
}

/* Left Sidebar */
.left-sidebar {
    background: rgba(255, 255, 255, 0.98);
    backdrop-filter: blur(20px);
    border-right: 1px solid rgba(102, 126, 234, 0.1);
    box-shadow: 4px 0 24px rgba(0, 0, 0, 0.06);
    display: flex;
    flex-direction: column;
}

.logo-area {
    padding: 20px 25px;
    border-bottom: 1px solid rgba(102, 126, 234, 0.1);
}

.logo {
    display: flex;
    align-items: center;
    gap: 12px;
}

.logo-icon {
    width: 38px;
    height: 38px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 20px;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.logo-text {
    font-size: 18px;
    font-weight: 700;
    background: linear-gradient(135deg, #667eea, #764ba2);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.nav-section {
    padding: 15px 15px;
    flex: 1;
    overflow-y: auto;
}

.nav-section-title {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #94a3b8;
    padding: 0 10px;
    margin-bottom: 8px;
}

.nav-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 15px;
    border-radius: 10px;
    color: #475569;
    text-decoration: none;
    margin-bottom: 4px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    font-size: 14px;
}

.nav-item::before {
    content: \'\';
    position: absolute;
    left: 0;
    top: 0;
    width: 4px;
    height: 100%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    transform: scaleY(0);
    transition: transform 0.3s;
}

.nav-item:hover {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.08), rgba(118, 75, 162, 0.08));
    color: #667eea;
    transform: translateX(4px);
}

.nav-item.active {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.15), rgba(118, 75, 162, 0.15));
    color: #667eea;
    font-weight: 600;
}

.nav-item.active::before {
    transform: scaleY(1);
}

.nav-icon {
    font-size: 18px;
    width: 20px;
    text-align: center;
}

.badge-notify {
    background: linear-gradient(135deg, #f43f5e, #e11d48);
    color: white;
    font-size: 10px;
    font-weight: 700;
    padding: 2px 7px;
    border-radius: 20px;
    margin-left: auto;
}

/* Main Content */
.main-content {
    padding: 25px 30px;
    overflow-y: auto;
    background: rgba(255, 255, 255, 0.03);
}

/* Compact Welcome Header */
.welcome-header {
    background: white;
    border-radius: 16px;
    padding: 20px 30px;
    margin-bottom: 20px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.8);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.greeting {
    font-size: 24px;
    font-weight: 700;
    background: linear-gradient(135deg, #667eea, #764ba2);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 2px;
}

.user-role {
    color: #64748b;
    font-size: 13px;
}

.logout-btn {
    background: linear-gradient(135deg, rgba(244, 63, 94, 0.1), rgba(225, 29, 72, 0.1));
    color: #f43f5e;
    border: 2px solid transparent;
    padding: 8px 20px;
    border-radius: 10px;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    transition: all 0.3s;
}

.logout-btn:hover {
    border-color: #f43f5e;
    background: white;
    color: #f43f5e;
}

/* Compact Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
    margin-bottom: 20px;
}

.stat-card {
    background: white;
    border-radius: 14px;
    padding: 20px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.8);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}

.stat-card::before {
    content: \'\';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 3px;
    background: linear-gradient(90deg, var(--stat-color-1), var(--stat-color-2));
}

.stat-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}

.stat-icon-wrapper {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 12px;
    background: linear-gradient(135deg, var(--stat-color-1), var(--stat-color-2));
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
}

.stat-icon {
    font-size: 22px;
    color: white;
}

.stat-value {
    font-size: 28px;
    font-weight: 800;
    background: linear-gradient(135deg, var(--stat-color-1), var(--stat-color-2));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 4px;
    line-height: 1;
}

.stat-label {
    font-size: 12px;
    color: #64748b;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* Section Title */
.section-title {
    font-size: 18px;
    font-weight: 700;
    color: white;
    margin-bottom: 15px;
    text-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

/* Quick Actions */
.quick-actions-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
    margin-bottom: 20px;
}

.action-card {
    background: white;
    border-radius: 12px;
    padding: 16px 20px;
    text-decoration: none;
    color: inherit;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
    border: 2px solid transparent;
    transition: all 0.3s;
    display: flex;
    align-items: center;
    gap: 14px;
}

.action-card:hover {
    border-color: #667eea;
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.2);
    color: inherit;
}

.action-icon {
    width: 44px;
    height: 44px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    flex-shrink: 0;
}

.action-title {
    font-weight: 600;
    font-size: 14px;
}

/* Projects Section */
.projects-section {
    background: white;
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}

.project-item {
    border: 2px solid #f1f5f9;
    border-radius: 12px;
    margin-bottom: 12px;
    transition: all 0.3s;
    overflow: hidden;
}

.project-header {
    padding: 16px 20px;
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.05), rgba(118, 75, 162, 0.05));
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: all 0.3s;
}

.project-header:hover {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
}

.project-info {
    display: flex;
    align-items: center;
    gap: 12px;
}

.project-icon {
    width: 40px;
    height: 40px;
    border-radius: 10px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

.project-name {
    font-weight: 600;
    font-size: 15px;
    color: #1e293b;
}

.project-stats {
    display: flex;
    gap: 15px;
    align-items: center;
}

.task-count {
    background: rgba(102, 126, 234, 0.1);
    color: #667eea;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.expand-icon {
    color: #94a3b8;
    font-size: 20px;
    transition: transform 0.3s;
}

.project-item.expanded .expand-icon {
    transform: rotate(180deg);
}

.tasks-list {
    padding: 12px 20px 16px 72px;
    background: white;
    display: none;
}

.project-item.expanded .tasks-list {
    display: block;
}

.task-item {
    padding: 12px 16px;
    border-left: 3px solid #e2e8f0;
    margin-bottom: 8px;
    border-radius: 0 8px 8px 0;
    background: #f8fafc;
    transition: all 0.3s;
    cursor: pointer;
}

.task-item:hover {
    border-left-color: #667eea;
    background: #eff6ff;
    transform: translateX(4px);
}

.task-title {
    font-weight: 600;
    font-size: 14px;
    color: #1e293b;
    margin-bottom: 4px;
}

.task-meta {
    display: flex;
    gap: 12px;
    font-size: 12px;
    color: #64748b;
}

.status-badge {
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
}

.status-pending { background: #fef3c7; color: #d97706; }
.status-in_progress { background: #dbeafe; color: #2563eb; }
.status-completed { background: #d1fae5; color: #059669; }

/* Right Sidebar */
.right-sidebar {
    background: white;
    border-left: 1px solid rgba(102, 126, 234, 0.1);
    display: flex;
    flex-direction: column;
    box-shadow: -4px 0 24px rgba(0, 0, 0, 0.06);
}

.chat-header {
    padding: 25px 25px;
    border-bottom: 1px solid rgba(102, 126, 234, 0.1);
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    position: relative;
}

.chat-title {
    font-size: 18px;
    font-weight: 700;
}

.notification-badge {
    position: absolute;
    top: 20px;
    right: 25px;
    background: #f43f5e;
    color: white;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 12px;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.08); }
}

.chat-users-list {
    flex: 1;
    overflow-y: auto;
    padding: 12px;
}

.chat-user {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s;
    margin-bottom: 6px;
    position: relative;
}

.chat-user:hover {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.06), rgba(118, 75, 162, 0.06));
}

.chat-user.active {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.12), rgba(118, 75, 162, 0.12));
    border-left: 3px solid #667eea;
}

.user-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 15px;
    flex-shrink: 0;
}

.user-info {
    flex: 1;
}

.user-name {
    font-weight: 600;
    font-size: 14px;
    color: #1e293b;
}

.user-status {
    font-size: 11px;
    color: #64748b;
}

.unread-count {
    background: linear-gradient(135deg, #f43f5e, #e11d48);
    color: white;
    min-width: 22px;
    height: 22px;
    border-radius: 11px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 10px;
    font-weight: 700;
    padding: 0 6px;
}

/* Chat Messages */
.chat-messages-area {
    padding: 15px;
    flex: 1;
    overflow-y: auto;
    background: #f8fafc;
    max-height: 400px;
    display: none;
}

.chat-messages-area.active {
    display: block;
}

.message {
    padding: 10px 14px;
    border-radius: 12px;
    margin-bottom: 10px;
    max-width: 75%;
    word-wrap: break-word;
}

.message.sent {
    background: #667eea;
    color: white;
    margin-left: auto;
    border-bottom-right-radius: 4px;
}

.message.received {
    background: white;
    border-bottom-left-radius: 4px;
}

.message-time {
    font-size: 10px;
    opacity: 0.7;
    margin-top: 4px;
}

.chat-input-area {
    padding: 15px;
    border-top: 1px solid #e2e8f0;
    display: none;
}

.chat-input-area.active {
    display: block;
}
</style>';
require __DIR__ . "/shared/layout_head.php";
require __DIR__ . "/menu.php";
?>
<main class="content">
  <div class="topbar">
    <div class="crumbs">
      <?php
        if (!empty($breadcrumbs)) {
          $last = count($breadcrumbs)-1;
          foreach($breadcrumbs as $i=>$c){
            $lab = $c['label'] ?? '';
            $href = $c['href'] ?? '';
            if ($href) {
              echo '<a href="'.e($href).'">'.e($lab).'</a>';
            } else {
              echo '<span style="font-weight:950">'.e($lab).'</span>';
            }
            if ($i !== $last) echo '<span class="sep">/</span>';
          }
        }
      ?>
    </div>
    <div style="display:flex;gap:10px;align-items:center;flex:1;justify-content:flex-end">
      <form class="search" method="get" action="/task.php" style="max-width:680px">
        <i class="bi bi-search"></i>
        <input name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Arama: görev, proje, kullanıcı…">
      </form>
      <span class="pill"><i class="bi bi-person-circle"></i> <?= e($_SESSION['user']['name'] ?? 'Kullanıcı') ?></span>
    </div>
  </div>

  <div style="height:14px"></div>

  <div class="dashboard-container">
    
    <!-- Left Sidebar -->
    <div class="left-sidebar">
        <div class="logo-area">
            <div class="logo">
                <div class="logo-icon">
                    <i class="bi bi-layers"></i>
                </div>
                <div class="logo-text">FinansConnect</div>
            </div>
        </div>

        <div class="nav-section">
            <div class="nav-section-title">Ana Menü</div>
            <a href="dashboard.php" class="nav-item active">
                <i class="bi bi-speedometer2 nav-icon"></i>
                <span>Dashboard</span>
            </a>
            <a href="tasks.php" class="nav-item">
                <i class="bi bi-check2-square nav-icon"></i>
                <span>Görevlerim</span>
                <?php if ((int)$taskCount > 0): ?>
                <span class="badge-notify"><?= $taskCount ?></span>
                <?php endif; ?>
            </a>
            <a href="projects.php" class="nav-item">
                <i class="bi bi-folder nav-icon"></i>
                <span>Projeler</span>
            </a>
            <?php if ($userRole !== 'user'): ?>
            <a href="users.php" class="nav-item">
                <i class="bi bi-people nav-icon"></i>
                <span>Ekip</span>
            </a>
            <?php endif; ?>

            <div class="nav-section-title" style="margin-top: 25px;">Modüller</div>

            <a href="/finance/dashboard.php" class="nav-item">
                <i class="bi bi-cash-stack nav-icon"></i>
                <span>Finans Yönetimi</span>
            </a>

            <a href="/procurement/views/dashboard.php" class="nav-item">
                <i class="bi bi-bag-check nav-icon"></i>
                <span>Satın Alma</span>
            </a>

            <a href="/credit/dashboard.php" class="nav-item">
                <i class="bi bi-bank nav-icon"></i>
                <span>Kredi Takip</span>
            </a>


            <a href="/accounting/dashboard.php" class="nav-item">
                <i class="bi bi-journal-text nav-icon"></i>
                <span>Muhasebe</span>
            </a>

            <a href="/cashflow/dashboard.php" class="nav-item">
                <i class="bi bi-arrow-left-right nav-icon"></i>
                <span>Nakit Akışı</span>
            </a>



            <?php if (is_super_admin()): ?>
            <div class="nav-section-title" style="margin-top: 25px;">Super Admin</div>
            <a href="super_companies.php" class="nav-item">
                <i class="bi bi-building nav-icon"></i>
                <span>Firmalar</span>
            </a>
            <a href="super_roles.php" class="nav-item">
                <i class="bi bi-shield-lock nav-icon"></i>
                <span>Roller</span>
            </a>
            <a href="super_users.php" class="nav-item">
                <i class="bi bi-people-fill nav-icon"></i>
                <span>Tüm Kullanıcılar</span>
            </a>
            <?php endif; ?>

            <div class="nav-section-title" style="margin-top: 25px;">Yönetim</div>
            <a href="reports.php" class="nav-item">
                <i class="bi bi-bar-chart nav-icon"></i>
                <span>Raporlar</span>
            </a>
            <a href="profile.php" class="nav-item">
                <i class="bi bi-gear nav-icon"></i>
                <span>Ayarlar</span>
            </a>
        </div>

        <div style="padding: 15px; border-top: 1px solid rgba(102, 126, 234, 0.1);">
            <a href="logout.php" class="nav-item" style="background: linear-gradient(135deg, rgba(244, 63, 94, 0.1), rgba(225, 29, 72, 0.1)); color: #f43f5e;">
                <i class="bi bi-box-arrow-right nav-icon"></i>
                <span>Çıkış</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        
        <!-- Welcome Header -->
        <div class="welcome-header">
            <div>
                <div class="greeting">
                    <?php
                    $hour = (int)date('H');
                    if ($hour < 12) echo "☀️ Günaydın";
                    elseif ($hour < 18) echo "🌤️ İyi Günler";
                    else echo "🌙 İyi Akşamlar";
                    ?>, <?= htmlspecialchars($userName) ?>
                </div>
                <div class="user-role">
                    <?= is_super_admin() ? "Super Admin" : htmlspecialchars($companyName) ?>
                    <?= $userRole === 'company_admin' ? ' • Firma Yöneticisi' : ($userRole === 'user' ? ' • Kullanıcı' : '') ?>
                </div>
            </div>
            <a href="logout.php" class="logout-btn">
                <i class="bi bi-box-arrow-right"></i> Çıkış
            </a>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card" style="--stat-color-1: #667eea; --stat-color-2: #764ba2;">
                <div class="stat-icon-wrapper">
                    <i class="bi bi-people-fill stat-icon"></i>
                </div>
                <div class="stat-value"><?= (int)$userCount ?></div>
                <div class="stat-label">Kullanıcılar</div>
            </div>

            <div class="stat-card" style="--stat-color-1: #f093fb; --stat-color-2: #f5576c;">
                <div class="stat-icon-wrapper">
                    <i class="bi bi-folder-fill stat-icon"></i>
                </div>
                <div class="stat-value"><?= (int)$projectCount ?></div>
                <div class="stat-label">Projeler</div>
            </div>

            <div class="stat-card" style="--stat-color-1: #4facfe; --stat-color-2: #00f2fe;">
                <div class="stat-icon-wrapper">
                    <i class="bi bi-check2-square stat-icon"></i>
                </div>
                <div class="stat-value"><?= (int)$taskCount ?></div>
                <div class="stat-label">Görevler</div>
            </div>

            <div class="stat-card" style="--stat-color-1: #43e97b; --stat-color-2: #38f9d7;">
                <div class="stat-icon-wrapper">
                    <i class="bi bi-check-circle-fill stat-icon"></i>
                </div>
                <div class="stat-value"><?= (int)$completedCount ?></div>
                <div class="stat-label">Tamamlandı</div>
            </div>
        </div>

        <!-- Quick Actions -->
        <h2 class="section-title">⚡ Hızlı İşlemler</h2>
        <div class="quick-actions-grid">
            <a href="task_create.php" class="action-card">
                <div class="action-icon" style="background: linear-gradient(135deg, #ffeaa7, #fdcb6e); color: #d63031;">
                    <i class="bi bi-plus-circle-fill"></i>
                </div>
                <div class="action-title">Yeni Görev</div>
            </a>

            <a href="project_create.php" class="action-card">
                <div class="action-icon" style="background: linear-gradient(135deg, #a8e6cf, #3eecac); color: #00b894;">
                    <i class="bi bi-folder-plus"></i>
                </div>
                <div class="action-title">Yeni Proje</div>
            </a>

            <?php if ($userRole !== 'user'): ?>
            <a href="users.php" class="action-card">
                <div class="action-icon" style="background: linear-gradient(135deg, #a29bfe, #6c5ce7); color: white;">
                    <i class="bi bi-person-plus-fill"></i>
                </div>
                <div class="action-title">Kullanıcı Ekle</div>
            </a>
            <?php else: ?>
            <a href="tasks.php" class="action-card">
                <div class="action-icon" style="background: linear-gradient(135deg, #a29bfe, #6c5ce7); color: white;">
                    <i class="bi bi-list-check"></i>
                </div>
                <div class="action-title">Tüm Görevler</div>
            </a>
            <?php endif; ?>
        </div>

        <!-- Projects Section -->
        <h2 class="section-title">📁 Projelerim & Görevler</h2>
        <div class="projects-section">
            <?php if (empty($projects)): ?>
                <p class="text-center text-muted py-4">
                    <i class="bi bi-folder-x" style="font-size: 48px;"></i><br>
                    Henüz proje yok
                </p>
            <?php else: ?>
                <?php 
                $projectColors = [
                    '#667eea, #764ba2',
                    '#f093fb, #f5576c',
                    '#4facfe, #00f2fe',
                    '#43e97b, #38f9d7',
                    '#fa709a, #fee140'
                ];
                $colorIndex = 0;
                ?>
                <?php foreach ($projects as $project): ?>
                <div class="project-item" id="project-<?= $project['id'] ?>">
                    <div class="project-header" onclick="toggleProject(<?= $project['id'] ?>)">
                        <div class="project-info">
                            <div class="project-icon" style="background: linear-gradient(135deg, <?= $projectColors[$colorIndex % count($projectColors)] ?>);">
                                <i class="bi bi-folder-fill"></i>
                            </div>
                            <div class="project-name"><?= htmlspecialchars($project['name']) ?></div>
                        </div>
                        <div class="project-stats">
                            <span class="task-count"><?= (int)$project['task_count'] ?> görev</span>
                            <i class="bi bi-chevron-down expand-icon"></i>
                        </div>
                    </div>
                    <div class="tasks-list">
                        <?php if (empty($project['tasks'])): ?>
                            <p class="text-muted small">Henüz görev yok</p>
                        <?php else: ?>
                            <?php foreach ($project['tasks'] as $task): ?>
                            <div class="task-item" onclick="window.location='task_detail.php?id=<?= $task['id'] ?>'">
                                <div class="task-title"><?= htmlspecialchars($task['title']) ?></div>
                                <div class="task-meta">
                                    <span class="status-badge status-<?= $task['status'] ?>">
                                        <?php
                                        $statusLabels = [
                                            'pending' => 'Bekliyor',
                                            'in_progress' => 'Devam Ediyor',
                                            'completed' => 'Tamamlandı'
                                        ];
                                        echo $statusLabels[$task['status']] ?? 'Bekliyor';
                                        ?>
                                    </span>
                                    <?php if ($task['due_date']): ?>
                                    <span><i class="bi bi-calendar"></i> <?= date('d M', strtotime($task['due_date'])) ?></span>
                                    <?php endif; ?>
                                    <?php if ($task['assigned_user_name']): ?>
                                    <span><i class="bi bi-person"></i> <?= htmlspecialchars($task['assigned_user_name']) ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php $colorIndex++; ?>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Sidebar - Chat -->
    <div class="right-sidebar">
        <div class="chat-header">
            <div class="chat-title">💬 Mesajlar</div>
            <div style="font-size: 12px; opacity: 0.9; margin-top: 2px;">Firma İçi İletişim</div>
            <?php if ($totalUnread > 0): ?>
            <div class="notification-badge"><?= $totalUnread ?></div>
            <?php endif; ?>
        </div>

        <div class="chat-users-list">
            <?php foreach ($chatUsers as $chatUser): ?>
            <div class="chat-user <?= $activeChatUserId === (int)$chatUser['id'] ? 'active' : '' ?>" 
                 onclick="window.location='dashboard.php?chat=<?= $chatUser['id'] ?>'">
                <div class="user-avatar">
                    <?= strtoupper(substr($chatUser['name'], 0, 1)) ?>
                </div>
                <div class="user-info">
                    <div class="user-name"><?= htmlspecialchars($chatUser['name']) ?></div>
                    <div class="user-status">Çevrimiçi</div>
                </div>
                <?php if ($unreadCounts[$chatUser['id']] > 0): ?>
                <div class="unread-count"><?= $unreadCounts[$chatUser['id']] ?></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>

            <?php if ($activeChatUserId > 0): ?>
            <!-- Chat Messages -->
            <div class="chat-messages-area active" id="chatMessages">
                <?php if (empty($chatMessages)): ?>
                    <p class="text-center text-muted py-3">Henüz mesaj yok</p>
                <?php else: ?>
                    <?php foreach ($chatMessages as $msg): ?>
                    <div class="message <?= (int)$msg['from_user_id'] === $userId ? 'sent' : 'received' ?>">
                        <?php if ((int)$msg['from_user_id'] !== $userId): ?>
                            <small><strong><?= htmlspecialchars($msg['from_user_name']) ?></strong></small><br>
                        <?php endif; ?>
                        <?= nl2br(htmlspecialchars($msg['message'])) ?>
                        <div class="message-time"><?= date('H:i', strtotime($msg['created_at'])) ?></div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Chat Input -->
            <div class="chat-input-area active">
                <form method="post">
                    <input type="hidden" name="to_user_id" value="<?= $activeChatUserId ?>">
                    <div class="input-group">
                        <input type="text" name="message" class="form-control" placeholder="Mesaj yazın..." required>
                        <button type="submit" name="send_message" class="btn btn-primary">
                            <i class="bi bi-send"></i>
                        </button>
                    </div>
                </form>
            </div>
            <?php endif; ?>

            <div style="padding: 20px; margin-top: 20px; border-top: 1px solid rgba(102, 126, 234, 0.1);">
                <div style="font-weight: 600; margin-bottom: 12px; color: #1e293b; font-size: 14px;">
                    🏷️ Etiketlerim
                </div>
                <?php if (empty($userTags)): ?>
                    <p class="text-muted small mb-0">Henüz etiket yok</p>
                <?php else: ?>
                    <div style="display: flex; flex-wrap: wrap; gap: 6px;">
                        <?php foreach ($userTags as $tag): ?>
                        <span onclick="window.location='task_detail.php?id=<?= $tag['task_id'] ?>'" 
                              style="background: linear-gradient(135deg, #667eea, #764ba2); color: white; padding: 5px 10px; border-radius: 16px; font-size: 11px; font-weight: 600; cursor: pointer;">
                            <?= htmlspecialchars($tag['tag_name']) ?>
                        </span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function toggleProject(projectId) {
    const project = document.getElementById('project-' + projectId);
    project.classList.toggle('expanded');
}

// Auto scroll chat to bottom
const chatMessages = document.getElementById('chatMessages');
if (chatMessages) {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}
</script>
</main>
<?php require __DIR__ . "/shared/layout_foot.php"; ?>

