<?php
require __DIR__ . "/auth.php";

$taskId = (int)($_GET['id'] ?? 0);

// Görev bilgilerini çek
$stmt = $pdo->prepare("
    SELECT t.*, p.company_id, p.name as project_name
    FROM tasks t
    LEFT JOIN projects p ON t.project_id = p.id
    WHERE t.id = ?
");
$stmt->execute([$taskId]);
$task = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$task) {
    die("Görev bulunamadı");
}

// Yetki kontrolü
if (!is_super_admin() && (int)$task['company_id'] !== $companyId) {
    die("Bu görevi düzenleyemezsiniz");
}

$msg = "";
$err = "";

// Güncelleme
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    try {
        $title = trim($_POST["title"] ?? "");
        $description = trim($_POST["description"] ?? "");
        $projectId = (int)($_POST["project_id"] ?? 0);
        $assignedTo = (int)($_POST["assigned_to"] ?? 0);
        $priority = $_POST["priority"] ?? "medium";
        $status = $_POST["status"] ?? "pending";
        $startDate = $_POST["start_date"] ?? "";
        $dueDate = $_POST["due_date"] ?? "";
        
        if (empty($title) || $projectId === 0) {
            throw new Exception("Görev adı ve proje seçimi zorunludur");
        }
        
        if (empty($startDate) || empty($dueDate)) {
            throw new Exception("Başlangıç ve bitiş tarihleri zorunludur");
        }
        
        if (strtotime($dueDate) < strtotime($startDate)) {
            throw new Exception("Bitiş tarihi başlangıç tarihinden önce olamaz");
        }
        
        $stmt = $pdo->prepare("
            UPDATE tasks SET 
                project_id = ?, title = ?, description = ?, assigned_to = ?,
                priority = ?, status = ?, start_date = ?, due_date = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $projectId,
            $title,
            $description ?: null,
            $assignedTo > 0 ? $assignedTo : null,
            $priority,
            $status,
            $startDate,
            $dueDate,
            $taskId
        ]);
        
        $msg = "Görev güncellendi!";
        
        // Güncel bilgiyi tekrar çek
        $stmt = $pdo->prepare("
            SELECT t.*, p.company_id, p.name as project_name
            FROM tasks t
            LEFT JOIN projects p ON t.project_id = p.id
            WHERE t.id = ?
        ");
        $stmt->execute([$taskId]);
        $task = $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        $err = $e->getMessage();
    }
}

// Projeler
if (is_super_admin()) {
    $projects = $pdo->query("SELECT id, name FROM projects ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("SELECT id, name FROM projects WHERE company_id = ? ORDER BY name ASC");
    $stmt->execute([$companyId]);
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Kullanıcılar
if (is_super_admin()) {
    $users = $pdo->query("SELECT id, name FROM users ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE company_id = ? ORDER BY name ASC");
    $stmt->execute([$companyId]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Görev Düzenle</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); min-height: 100vh; padding: 30px; }
.container-card { background: white; border-radius: 15px; padding: 30px; max-width: 900px; margin: 0 auto; }
.btn-update { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color: white; }
.btn-update:hover { background: linear-gradient(135deg, #1e293b 0%, #1e3a8a 100%); color: white; }
</style>
</head>
<body>

<div class="container-card">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi bi-pencil-square"></i> Görev Düzenle</h2>
        <div>
            <a href="task_detail.php?id=<?= $taskId ?>" class="btn btn-info">
                <i class="bi bi-eye"></i> Detay
            </a>
            <a href="tasks.php" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i> Geri
            </a>
        </div>
    </div>

    <?php if($msg): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= htmlspecialchars($msg) ?>
        </div>
    <?php endif; ?>
    
    <?php if($err): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= htmlspecialchars($err) ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label class="form-label fw-bold">Görev Adı *</label>
            <input type="text" name="title" class="form-control form-control-lg" value="<?= htmlspecialchars($task['title']) ?>" required>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Proje *</label>
                <select name="project_id" class="form-select form-select-lg" required>
                    <?php foreach ($projects as $project): ?>
                        <option value="<?= (int)$project['id'] ?>" <?= (int)$task['project_id'] === (int)$project['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($project['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label fw-bold">Atanan Kişi</label>
                <select name="assigned_to" class="form-select form-select-lg">
                    <option value="0">Atanmamış</option>
                    <?php foreach ($users as $user): ?>
                        <option value="<?= (int)$user['id'] ?>" <?= (int)$task['assigned_to'] === (int)$user['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($user['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold">Açıklama</label>
            <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($task['description'] ?? '') ?></textarea>
        </div>

        <div class="row">
            <div class="col-md-3 mb-3">
                <label class="form-label fw-bold">Başlangıç *</label>
                <input type="date" name="start_date" class="form-control form-control-lg" value="<?= $task['start_date'] ?>" required>
            </div>
            <div class="col-md-3 mb-3">
                <label class="form-label fw-bold">Bitiş *</label>
                <input type="date" name="due_date" class="form-control form-control-lg" value="<?= $task['due_date'] ?>" required>
            </div>
            <div class="col-md-3 mb-3">
                <label class="form-label fw-bold">Öncelik</label>
                <select name="priority" class="form-select form-select-lg">
                    <option value="low" <?= $task['priority'] === 'low' ? 'selected' : '' ?>>🟢 Düşük</option>
                    <option value="medium" <?= $task['priority'] === 'medium' ? 'selected' : '' ?>>🟡 Orta</option>
                    <option value="high" <?= $task['priority'] === 'high' ? 'selected' : '' ?>>🔴 Yüksek</option>
                </select>
            </div>
            <div class="col-md-3 mb-3">
                <label class="form-label fw-bold">Durum</label>
                <select name="status" class="form-select form-select-lg">
                    <option value="pending" <?= $task['status'] === 'pending' ? 'selected' : '' ?>>⏳ Bekliyor</option>
                    <option value="in_progress" <?= $task['status'] === 'in_progress' ? 'selected' : '' ?>>🔄 Devam Ediyor</option>
                    <option value="completed" <?= $task['status'] === 'completed' ? 'selected' : '' ?>>✅ Tamamlandı</option>
                </select>
            </div>
        </div>

        <div class="d-flex gap-2 mt-4">
            <button type="submit" class="btn btn-update btn-lg">
                <i class="bi bi-check-circle"></i> Güncelle
            </button>
            <a href="task_detail.php?id=<?= $taskId ?>" class="btn btn-secondary btn-lg">İptal</a>
        </div>
    </form>
</div>

</body>
</html>