<?php
/**
 * Database Class - Procurement
 *
 * Öncelik: Ana sistemin /config/db.php içindeki PDO bağlantısını kullanır.
 */

class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        // 1) Ana sistem PDO global varsa kullan
        if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) {
            $this->pdo = $GLOBALS['pdo'];
            return;
        }

        // 2) Ana sistem db.php dosyasını yükle
        $rootDb = (defined('BASE_PATH') ? BASE_PATH : realpath(__DIR__ . '/../../')) . '/config/db.php';
        if (file_exists($rootDb)) {
            require_once $rootDb; // $pdo üretilir
            if (isset($pdo) && $pdo instanceof PDO) {
                $GLOBALS['pdo'] = $pdo;
                $this->pdo = $pdo;
                return;
            }
        }

        // 3) Fallback: env ile bağlan (gerekirse)
        try {
            $host = getenv('DB_HOST') ?: 'localhost';
            $dbname = getenv('DB_NAME') ?: 'u336896947_workflow';
            $user = getenv('DB_USER') ?: 'u336896947_admin';
            $pass = getenv('DB_PASS') ?: '';

            $this->pdo = new PDO(
                "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
                $user,
                $pass,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            die('Veritabanı Bağlantı Hatası');
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->pdo;
    }

    public function select($sql, $params = []) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function selectOne($sql, $params = []) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }

    public function execute($sql, $params = []) {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    public function lastInsertId() {
        return $this->pdo->lastInsertId();
    }

    public function beginTransaction() {
        $this->pdo->beginTransaction();
    }

    public function commit() {
        $this->pdo->commit();
    }

    public function rollback() {
        $this->pdo->rollBack();
    }
}
?>
