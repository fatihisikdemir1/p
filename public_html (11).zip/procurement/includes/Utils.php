<?php
/**
 * Utils Class - Yardımcı Fonksiyonlar
 */

class Utils {

    public static function sanitize($data) {
        if (is_array($data)) {
            return array_map([self::class, 'sanitize'], $data);
        }
        return htmlspecialchars(trim((string)$data), ENT_QUOTES, 'UTF-8');
    }

    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function validatePhone($phone) {
        return preg_match('/^\+?90\s?[0-9]{3}\s?[0-9]{3}\s?[0-9]{2}\s?[0-9]{2}$/', str_replace(['-', '(', ')'], '', (string)$phone));
    }

    public static function formatCurrency($amount, $currency = 'TRY', $decimals = 2) {
        $symbols = [
            'TRY' => '₺',
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
        ];

        $symbol = $symbols[$currency] ?? $currency;
        return number_format((float)$amount, (int)$decimals, ',', '.') . ' ' . $symbol;
    }

    public static function formatDate($date, $format = 'd.m.Y') {
        if (!$date) return '-';
        try {
            $dt = new DateTime((string)$date);
            return $dt->format($format);
        } catch (Exception $e) {
            return (string)$date;
        }
    }

    public static function formatDateTime($datetime, $format = 'd.m.Y H:i') {
        if (!$datetime) return '-';
        try {
            $dt = new DateTime((string)$datetime);
            return $dt->format($format);
        } catch (Exception $e) {
            return (string)$datetime;
        }
    }

    public static function formatTimeDiff($datetime, $compareWith = null) {
        if (!$datetime) return '-';

        try {
            $dt  = new DateTime((string)$datetime);
            $now = $compareWith ? new DateTime((string)$compareWith) : new DateTime(); // ✅ FIX

            $diff = $now->diff($dt);

            if ($diff->y > 0) {
                return $diff->y . ' yıl ' . ($diff->m > 0 ? $diff->m . ' ay' : '');
            } elseif ($diff->m > 0) {
                return $diff->m . ' ay ' . ($diff->d > 0 ? $diff->d . ' gün' : '');
            } elseif ($diff->d > 0) {
                return $diff->d . ' gün ' . ($diff->h > 0 ? $diff->h . ' saat' : '');
            } elseif ($diff->h > 0) {
                return $diff->h . ' saat ' . ($diff->i > 0 ? $diff->i . ' dakika' : '');
            } else {
                return $diff->i . ' dakika önce';
            }
        } catch (Throwable $e) {
            return (string)$datetime;
        }
    }

    public static function getStatusClass($status) {
        $classes = [
            'draft' => 'badge-secondary',
            'submitted' => 'badge-info',
            'approved' => 'badge-success',
            'rejected' => 'badge-danger',
            'cancelled' => 'badge-dark',
            'pending' => 'badge-warning',
            'processing' => 'badge-info',
            'completed' => 'badge-success',
            'failed' => 'badge-danger',
        ];

        return $classes[$status] ?? 'badge-light';
    }

    public static function getStatusLabel($entity, $status) {
        $labels = [
            'purchase_request' => [
                'draft' => 'Taslak',
                'submitted' => 'Gönderildi',
                'approved' => 'Onaylandı',
                'rejected' => 'Reddedildi',
                'cancelled' => 'İptal Edildi',
            ],
            'rfq' => [
                'created' => 'Oluşturuldu',
                'sent' => 'Gönderildi',
                'quoted' => 'Teklifler Alındı',
                'selected' => 'Seçildi',
                'closed' => 'Kapalı',
                'cancelled' => 'İptal',
            ],
            'purchase_order' => [
                'created' => 'Oluşturuldu',
                'approved' => 'Onaylandı',
                'sent' => 'Gönderildi',
                'partially_received' => 'Kısmen Teslim Alındı',
                'received' => 'Teslim Alındı',
                'cancelled' => 'İptal',
                'closed' => 'Kapalı',
            ],
            'invoice' => [
                'entered' => 'Girildi',
                'matched' => 'Eşleşti',
                'exception' => 'İstisna',
                'approved' => 'Onaylandı',
                'paid' => 'Ödendi',
                'cancelled' => 'İptal',
            ],
        ];

        return $labels[$entity][$status] ?? (string)$status;
    }

    public static function generateNumber($prefix, $lastNumber = 0) {
        $nextNumber = (int)$lastNumber + 1;
        $year = date('Y');
        $month = date('m');
        return sprintf('%s-%s-%s-%05d', $prefix, $year, $month, $nextNumber);
    }

    public static function generateUUID() {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    public static function toJSON($data, $pretty = false) {
        $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
        if ($pretty) $flags |= JSON_PRETTY_PRINT;
        return json_encode($data, $flags);
    }

    public static function fromJSON($json) {
        return json_decode((string)$json, true);
    }

    public static function uploadFile($file, $uploadDir, $allowedTypes = []) {
        if (!isset($file['tmp_name']) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new Exception("Dosya yükleme hatası");
        }

        $fileName = basename((string)$file['name']);
        $fileType = mime_content_type($file['tmp_name']);

        if (!empty($allowedTypes) && !in_array($fileType, $allowedTypes, true)) {
            throw new Exception("Dosya türü izin verilmiyor");
        }

        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $uniqueName = time() . '_' . uniqid() . '_' . $fileName;
        $filePath = rtrim($uploadDir, '/') . '/' . $uniqueName;

        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            return [
                'name' => $fileName,
                'path' => $filePath,
                'unique_name' => $uniqueName,
                'type' => $fileType,
                'size' => (int)$file['size']
            ];
        }

        throw new Exception("Dosya kaydedilemedi");
    }

    public static function paginate($totalItems, $page = 1, $itemsPerPage = 20) {
    $page = max(1, (int)$page);
    $itemsPerPage = max(1, (int)$itemsPerPage);

    $totalPages = (int)ceil($totalItems / $itemsPerPage);
    $totalPages = max(1, $totalPages);

    $page = min($page, $totalPages);
    $offset = ($page - 1) * $itemsPerPage;

    return [
        'page' => $page,
        'itemsPerPage' => $itemsPerPage,
        'offset' => $offset,
        'totalItems' => (int)$totalItems,
        'totalPages' => $totalPages,
    ];
}


    public static function percentage($value, $total) {
        return $total > 0 ? round(((float)$value / (float)$total) * 100, 2) : 0;
    }

    public static function convertCurrency($amount, $fromCurrency, $toCurrency) {
        if ($fromCurrency === $toCurrency) return $amount;

        $rates = [
            'TRY' => 1.0,
            'USD' => 0.033,
            'EUR' => 0.030,
            'GBP' => 0.026,
        ];

        if (!isset($rates[$fromCurrency]) || !isset($rates[$toCurrency])) {
            return $amount;
        }

        $amountInTRY = (float)$amount / (float)$rates[$fromCurrency];
        return $amountInTRY * (float)$rates[$toCurrency];
    }

    public static function redirect($url, $statusCode = 302) {
        header("Location: {$url}", true, (int)$statusCode);
        exit;
    }

    public static function jsonResponse($data, $statusCode = 200) {
        http_response_code((int)$statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ===== Dashboard 500 fix helpers =====
    public static function tableExists(string $table): bool {
        try {
            $db = Database::getInstance()->getConnection();
            $stmt = $db->prepare("SHOW TABLES LIKE ?");
            $stmt->execute([$table]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }

    public static function safeCount(string $table, string $whereSql = "", array $params = []): int {
        if (!self::tableExists($table)) return 0;
        $sql = "SELECT COUNT(*) AS cnt FROM {$table} " . $whereSql;
        $row = Database::getInstance()->selectOne($sql, $params);
        return (int)($row['cnt'] ?? 0);
    }
}
?>
