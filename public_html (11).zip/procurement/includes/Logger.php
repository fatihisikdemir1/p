<?php
/**
 * Logger Class - Audit Logging
 */

class Logger {
    private static $instance = null;
    private $db;
    
    private function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Singleton pattern
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Audit log kaydet
     */
    public function log($entityType, $entityId, $action, $description = null, $oldValue = null, $newValue = null) {
        try {
            $auth = Auth::getInstance();
            $userId = null;
            
            if ($auth->isLoggedIn()) {
                $user = $auth->getCurrentUser();
                $userId = $user['id'];
            }
            
            $ipAddress = $this->getClientIp();
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            
            $sql = "INSERT INTO audit_logs 
                    (user_id, entity_type, entity_id, action, description, old_value, new_value, ip_address, user_agent)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $this->db->execute($sql, [
                $userId,
                $entityType,
                $entityId,
                $action,
                $description,
                $oldValue ? json_encode($oldValue) : null,
                $newValue ? json_encode($newValue) : null,
                $ipAddress,
                $userAgent
            ]);
            
            return true;
        } catch (Exception $e) {
            error_log("Logging hatası: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Durum değişimi logla
     */
    public function logStatusChange($entityType, $entityId, $oldStatus, $newStatus, $description = null) {
        $this->log(
            $entityType,
            $entityId,
            'STATUS_CHANGE',
            $description ?? "Durum değişimi: {$oldStatus} → {$newStatus}",
            ['status' => $oldStatus],
            ['status' => $newStatus]
        );
    }
    
    /**
     * Kaydı güncelle logla
     */
    public function logUpdate($entityType, $entityId, $fields, $description = null) {
        $this->log(
            $entityType,
            $entityId,
            'UPDATE',
            $description ?? ucfirst($entityType) . ' güncellendi',
            [],
            $fields
        );
    }
    
    /**
     * Kaydı sil logla
     */
    public function logDelete($entityType, $entityId, $description = null) {
        $this->log(
            $entityType,
            $entityId,
            'DELETE',
            $description ?? ucfirst($entityType) . ' silindi'
        );
    }
    
    /**
     * Onay logla
     */
    public function logApproval($entityType, $entityId, $status, $comment = null) {
        $message = "Onay: {$status}";
        if ($comment) {
            $message .= " - {$comment}";
        }
        
        $this->log(
            $entityType,
            $entityId,
            'APPROVAL',
            $message
        );
    }
    
    /**
     * Dosya yükleme logla
     */
    public function logFileUpload($entityType, $entityId, $fileName) {
        $this->log(
            $entityType,
            $entityId,
            'FILE_UPLOAD',
            "Dosya yüklendi: {$fileName}"
        );
    }
    
    /**
     * Audit logları al
     */
    public function getAuditLogs($entityType, $entityId, $limit = 100) {
        try {
            $sql = "SELECT al.*, u.full_name 
                    FROM audit_logs al
                    LEFT JOIN users u ON al.user_id = u.id
                    WHERE al.entity_type = ? AND al.entity_id = ?
                    ORDER BY al.created_at DESC
                    LIMIT ?";
            
            return $this->db->select($sql, [$entityType, $entityId, $limit]);
        } catch (Exception $e) {
            error_log("Audit log alma hatası: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Client IP adresini al
     */
    private function getClientIp() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        } else {
            $ip = '0.0.0.0';
        }
        
        return $ip;
    }
    
    /**
     * Kullanıcı aktivitelerini al
     */
    public function getUserActivityLog($userId, $limit = 50) {
        try {
            $sql = "SELECT * FROM audit_logs 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC
                    LIMIT ?";
            
            return $this->db->select($sql, [$userId, $limit]);
        } catch (Exception $e) {
            error_log("Kullanıcı aktivite hatası: " . $e->getMessage());
            return [];
        }
    }
}
?>
