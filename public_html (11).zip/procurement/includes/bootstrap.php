<?php
/**
 * Application Bootstrap - Başlangıç Dosyası
 * Procurement modülü ana sistem session'ı ile çalışır.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// FS paths
define('BASE_PATH', realpath(__DIR__ . '/../../'));      // public_html
define('PROCUREMENT_FS', realpath(__DIR__ . '/..'));     // public_html/procurement
define('UPLOADS_PATH', PROCUREMENT_FS . '/uploads');

// URL base
if (!defined('PROCUREMENT_URL')) {
    define('PROCUREMENT_URL', '/procurement');
}

// Backward compatibility:
// - Views use PROCUREMENT_PATH as URL base
// - Controllers should use PROCUREMENT_DIR for filesystem includes
if (!defined('PROCUREMENT_PATH')) {
    define('PROCUREMENT_PATH', PROCUREMENT_URL);
}
if (!defined('PROCUREMENT_DIR')) {
    define('PROCUREMENT_DIR', PROCUREMENT_FS);
}

// Logs
$logDir = PROCUREMENT_FS . '/logs';
if (!file_exists($logDir)) {
    @mkdir($logDir, 0755, true);
}
ini_set('error_log', $logDir . '/error.log');

// Basic headers
header('Content-Type: text/html; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');

// Autoload
spl_autoload_register(function($class) {
    $paths = [
        PROCUREMENT_FS . '/includes/' . $class . '.php',
        PROCUREMENT_FS . '/models/' . $class . '.php',
        PROCUREMENT_FS . '/services/' . $class . '.php',
        PROCUREMENT_FS . '/controllers/' . $class . '.php',
    ];
    foreach ($paths as $path) {
        if (file_exists($path)) {
            require_once $path;
            return;
        }
    }
});

// Core
require_once PROCUREMENT_FS . '/includes/Database.php';
require_once PROCUREMENT_FS . '/includes/Auth.php';
require_once PROCUREMENT_FS . '/includes/Logger.php';
require_once PROCUREMENT_FS . '/includes/Utils.php';

// Singletons
$db = Database::getInstance();
$auth = Auth::getInstance();
$logger = Logger::getInstance();

// Upload dirs
$uploadDirs = [
    UPLOADS_PATH,
    UPLOADS_PATH . '/pr',
    UPLOADS_PATH . '/po',
    UPLOADS_PATH . '/rfq',
    UPLOADS_PATH . '/invoice',
    UPLOADS_PATH . '/grn',
    UPLOADS_PATH . '/vendors',
];
foreach ($uploadDirs as $dir) {
    if (!file_exists($dir)) {
        @mkdir($dir, 0755, true);
    }
}

// Helpers
function get_auth() { return Auth::getInstance(); }
function get_db() { return Database::getInstance(); }
function get_logger() { return Logger::getInstance(); }
function current_user() { return Auth::getInstance()->getCurrentUser(); }
function is_logged_in() { return Auth::getInstance()->isLoggedIn(); }

function require_login() {
    if (!is_logged_in()) {
        Utils::redirect('/login.php');
    }
}

function require_permission($permission) {
    require_login();
    if (!get_auth()->hasPermission($permission)) {
        http_response_code(403);
        die('Yetkiniz yok');
    }
}
