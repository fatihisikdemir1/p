<?php
/**
 * Auth Class (Adapter)
 *
 * Procurement modülü ana sistemin session'ını kullanır:
 *   $_SESSION['user'] = ['id','name','role','department_id', ...]
 *
 * Bu modülde ayrı login yoktur.
 */

class Auth {
    private static $instance = null;

    private $permissions = [
        'admin'       => ['read','create_pr','edit_pr','delete_pr','submit_pr','approve','view_reports','manage_users','manage_vendors'],
        'requester'   => ['read','create_pr','edit_own_pr','submit_pr','view_own'],
        'approver'    => ['read','approve','reject','view_assigned','view_department'],
        'procurement' => ['read','create_pr','edit_pr','create_rfq','create_po','manage_vendors','view_reports'],
        'warehouse'   => ['read','create_grn','edit_grn','view_assigned'],
        'finance'     => ['read','create_invoice','approve_invoice','create_payment','view_reports'],
        'viewer'      => ['read'],
    ];

    private function __construct() {}

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function isLoggedIn(): bool {
        return isset($_SESSION['user']) && isset($_SESSION['user']['id']);
    }

    // Procurement içinde ayrı login yok
    public function login($username, $password): bool {
        return false;
    }

    public function logout(): void {
        session_destroy();
    }

    /**
     * Ana sistem rolünü procurement rolüne map et
     */
    public function getRole(): ?string {
        $role = $_SESSION['user']['role'] ?? null;
        if (!$role) return null;

        $role = strtolower((string)$role);

        if (in_array($role, ['super_admin','superadmin','root'], true)) return 'admin';
        if ($role === 'admin') return 'admin';

        if (in_array($role, ['manager','dept_manager','department_manager','approver'], true)) return 'approver';
        if (in_array($role, ['procurement','purchasing','buyer'], true)) return 'procurement';
        if (in_array($role, ['warehouse','store','stok'], true)) return 'warehouse';
        if (in_array($role, ['finance','accounting','muhasebe'], true)) return 'finance';
        if (in_array($role, ['viewer','read_only'], true)) return 'viewer';

        return 'requester';
    }

    public function getCurrentUser(): ?array {
        if (!$this->isLoggedIn()) return null;
        $u = $_SESSION['user'];
        $name = (string)($u['name'] ?? ($u['full_name'] ?? 'Kullanıcı'));
        return [
            'id'            => (int)($u['id'] ?? 0),
            'full_name'     => $name,
            'name'          => $name,
            'email'         => (string)($u['email'] ?? ''),
            'role'          => $this->getRole(),
            'department_id' => (int)($u['department_id'] ?? 0),
            'company_id'    => (int)($u['company_id'] ?? 0),
        ];
    }

    public function hasRole($role): bool {
        return $this->getRole() === $role;
    }

    public function hasAnyRole($roles): bool {
        return in_array($this->getRole(), (array)$roles, true);
    }

    public function hasPermission($permission): bool {
        if (!$this->isLoggedIn()) return false;
        $role = $this->getRole();
        $perms = $this->permissions[$role] ?? [];
        return in_array($permission, $perms, true);
    }

    public function hasAnyPermission($permissions): bool {
        foreach ((array)$permissions as $permission) {
            if ($this->hasPermission($permission)) return true;
        }
        return false;
    }

    // Basit: approver/admin onaylayabilir
    public function canApprove($amount): bool {
        return $this->hasAnyRole(['admin','approver']);
    }

    public function isDepartmentManager(): bool {
        return $this->hasRole('approver');
    }

    public function canViewDepartment($departmentId): bool {
        $user = $this->getCurrentUser();
        if (!$user) return false;
        if ($this->hasRole('admin')) return true;
        return (int)$user['department_id'] === (int)$departmentId;
    }

    public function canViewRecord($recordUserId, $recordDepartmentId = null): bool {
        $user = $this->getCurrentUser();
        if (!$user) return false;
        if ($this->hasRole('admin')) return true;
        if ((int)$user['id'] === (int)$recordUserId) return true;
        if ($this->isDepartmentManager() && $recordDepartmentId !== null && (int)$recordDepartmentId === (int)$user['department_id']) return true;
        return false;
    }
}
?>
