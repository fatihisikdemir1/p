<?php
class RfqService {
    private $db;
    private $logger;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->logger = Logger::getInstance();
    }

    public function listRfqs($filters = [], $limit = 50, $offset = 0) {
        $sql = "SELECT r.*, pr.pr_number, pr.title AS pr_title
                FROM rfqs r
                LEFT JOIN purchase_requests pr ON pr.id = r.pr_id
                WHERE 1=1";
        $params = [];

        if (!empty($filters['status'])) {
            $sql .= " AND r.status = ?";
            $params[] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $sql .= " AND (r.rfq_number LIKE ? OR pr.pr_number LIKE ? OR pr.title LIKE ?)";
            $s = '%' . $filters['search'] . '%';
            $params[] = $s; $params[] = $s; $params[] = $s;
        }

        $sql .= " ORDER BY r.created_at DESC LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;

        return $this->db->select($sql, $params);
    }

    public function getRfq($rfqId) {
        return $this->db->selectOne(
            "SELECT r.*, pr.pr_number, pr.title AS pr_title, pr.status AS pr_status
             FROM rfqs r
             LEFT JOIN purchase_requests pr ON pr.id = r.pr_id
             WHERE r.id = ?",
            [(int)$rfqId]
        );
    }

    public function getRfqVendors($rfqId) {
        return $this->db->select(
            "SELECT rv.*, v.name, v.code, v.email
             FROM rfq_vendors rv
             LEFT JOIN vendors v ON v.id = rv.vendor_id
             WHERE rv.rfq_id = ?
             ORDER BY v.name",
            [(int)$rfqId]
        );
    }

    public function getQuotes($rfqId) {
        return $this->db->select(
            "SELECT q.*, v.name AS vendor_name, v.code AS vendor_code
             FROM quotes q
             LEFT JOIN vendors v ON v.id = q.vendor_id
             WHERE q.rfq_id = ?
             ORDER BY q.created_at DESC",
            [(int)$rfqId]
        );
    }

    public function createFromApprovedPr($prId, $dueDate, array $vendorIds, $notes = null) {
        $pr = $this->db->selectOne("SELECT * FROM purchase_requests WHERE id = ?", [(int)$prId]);
        if (!$pr) throw new Exception("PR bulunamadı");
        if (($pr['status'] ?? '') !== 'approved') throw new Exception("Sadece onaylı PR için RFQ oluşturulur");

        $user = Auth::getInstance()->getCurrentUser();
        if (!$user) throw new Exception("Oturum bulunamadı");

        if (empty($vendorIds)) throw new Exception("En az 1 tedarikçi seçmelisin");

        $this->db->beginTransaction();
        try {
            $rfqNumber = $this->generateRfqNumber();

            $this->db->execute(
                "INSERT INTO rfqs (rfq_number, pr_id, created_by, status, due_date, notes, created_at)
                 VALUES (?, ?, ?, 'created', ?, ?, NOW())",
                [$rfqNumber, (int)$prId, (int)$user['id'], $dueDate ?: null, $notes]
            );
            $rfqId = (int)$this->db->lastInsertId();

            foreach ($vendorIds as $vid) {
                $this->db->execute(
                    "INSERT IGNORE INTO rfq_vendors (rfq_id, vendor_id, sent_via, status)
                     VALUES (?, ?, 'email', 'invited')",
                    [(int)$rfqId, (int)$vid]
                );
            }

            $this->db->commit();

            $this->logger->log('rfq', $rfqId, 'CREATE', "RFQ oluşturuldu: {$rfqNumber}");

            return $rfqId;
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    public function markSent($rfqId, $sentVia = 'email') {
        $rfq = $this->getRfq($rfqId);
        if (!$rfq) throw new Exception("RFQ bulunamadı");
        if (($rfq['status'] ?? '') !== 'created') throw new Exception("Sadece 'created' RFQ gönderilebilir");

        $this->db->beginTransaction();
        try {
            $this->db->execute(
                "UPDATE rfqs SET status='sent', updated_at=NOW() WHERE id=?",
                [(int)$rfqId]
            );
            $this->db->execute(
                "UPDATE rfq_vendors SET sent_via=?, sent_at=NOW() WHERE rfq_id=? AND status='invited'",
                [$sentVia, (int)$rfqId]
            );
            $this->db->commit();

            $this->logger->logStatusChange('rfq', $rfqId, 'created', 'sent');

            return true;
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    public function upsertQuote($rfqId, $vendorId, $header, $lines) {
        $rfq = $this->getRfq($rfqId);
        if (!$rfq) throw new Exception("RFQ bulunamadı");
        if (!in_array($rfq['status'], ['sent','quoted','created'], true)) {
            throw new Exception("Bu RFQ için teklif girişi yapılamaz (status: {$rfq['status']})");
        }

        $this->db->beginTransaction();
        try {
            // quote var mı?
            $q = $this->db->selectOne("SELECT * FROM quotes WHERE rfq_id=? AND vendor_id=?", [(int)$rfqId, (int)$vendorId]);

            if ($q) {
                $quoteId = (int)$q['id'];
                $this->db->execute(
                    "UPDATE quotes SET currency=?, payment_terms=?, delivery_terms=?, lead_time_days=?, status='submitted', submitted_at=NOW()
                     WHERE id=?",
                    [
                        $header['currency'] ?? 'TRY',
                        $header['payment_terms'] ?? null,
                        $header['delivery_terms'] ?? null,
                        (int)($header['lead_time_days'] ?? 0) ?: null,
                        $quoteId
                    ]
                );
                $this->db->execute("DELETE FROM quote_lines WHERE quote_id=?", [$quoteId]);
            } else {
                $this->db->execute(
                    "INSERT INTO quotes (rfq_id, vendor_id, currency, payment_terms, delivery_terms, lead_time_days, status, submitted_at, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, 'submitted', NOW(), NOW())",
                    [
                        (int)$rfqId, (int)$vendorId,
                        $header['currency'] ?? 'TRY',
                        $header['payment_terms'] ?? null,
                        $header['delivery_terms'] ?? null,
                        (int)($header['lead_time_days'] ?? 0) ?: null
                    ]
                );
                $quoteId = (int)$this->db->lastInsertId();
            }

            // lines insert + total
            $total = 0.0;
            $ln = 1;
            foreach ((array)$lines as $line) {
                $qty = (float)($line['qty'] ?? 0);
                $unit = (float)($line['unit_price'] ?? 0);
                $tax = (float)($line['tax_rate'] ?? 20);
                if ($qty <= 0) continue;

                $lineTotal = $qty * $unit * (1 + ($tax/100));
                $total += $lineTotal;

                $this->db->execute(
                    "INSERT INTO quote_lines (quote_id, line_number, description, qty, unit, unit_price, tax_rate, line_total, currency, notes)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [
                        $quoteId, $ln++,
                        $line['description'] ?? '-',
                        $qty,
                        $line['unit'] ?? null,
                        $unit,
                        $tax,
                        $lineTotal,
                        $header['currency'] ?? 'TRY',
                        $line['notes'] ?? null
                    ]
                );
            }

            $this->db->execute("UPDATE quotes SET total_amount=? WHERE id=?", [$total, $quoteId]);
            $this->db->execute("UPDATE rfq_vendors SET status='quoted' WHERE rfq_id=? AND vendor_id=?", [(int)$rfqId, (int)$vendorId]);

            // RFQ status update (en az 1 quote varsa)
            $cnt = $this->db->selectOne("SELECT COUNT(*) c FROM quotes WHERE rfq_id=? AND status='submitted'", [(int)$rfqId]);
            if ((int)($cnt['c'] ?? 0) > 0) {
                $this->db->execute("UPDATE rfqs SET status='quoted', updated_at=NOW() WHERE id=? AND status IN ('created','sent')", [(int)$rfqId]);
            }

            $this->db->commit();

            $this->logger->log('quote', $quoteId, 'SUBMIT', 'Teklif girildi/güncellendi');

            return $quoteId;
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    public function selectWinner($rfqId, $quoteId) {
        $rfq = $this->getRfq($rfqId);
        if (!$rfq) throw new Exception("RFQ bulunamadı");
        if (($rfq['status'] ?? '') !== 'quoted') throw new Exception("Kazanan sadece 'quoted' RFQ’da seçilir");

        $q = $this->db->selectOne("SELECT * FROM quotes WHERE id=? AND rfq_id=?", [(int)$quoteId, (int)$rfqId]);
        if (!$q) throw new Exception("Quote bulunamadı");

        $this->db->beginTransaction();
        try {
            $this->db->execute("UPDATE quotes SET status='rejected' WHERE rfq_id=? AND id<>?", [(int)$rfqId, (int)$quoteId]);
            $this->db->execute("UPDATE quotes SET status='selected' WHERE id=?", [(int)$quoteId]);
            $this->db->execute("UPDATE rfqs SET status='selected', updated_at=NOW() WHERE id=?", [(int)$rfqId]);

            $this->db->commit();

            $this->logger->logStatusChange('rfq', $rfqId, 'quoted', 'selected', 'Kazanan teklif seçildi');
            return true;
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    private function generateRfqNumber() {
        $last = $this->db->selectOne("SELECT rfq_number FROM rfqs ORDER BY id DESC LIMIT 1");
        $next = 1;
        if ($last && !empty($last['rfq_number'])) {
            if (preg_match('/(\d+)$/', $last['rfq_number'], $m)) {
                $next = ((int)$m[1]) + 1;
            }
        }
        return sprintf('RFQ-%s%s-%05d', date('Y'), date('m'), $next);
    }
}
