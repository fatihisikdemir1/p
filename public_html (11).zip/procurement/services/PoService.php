<?php
class PoService {
    private $db;
    private $logger;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->logger = Logger::getInstance();
    }

    public function listPOs($filters = [], $limit = 50, $offset = 0) {
        $sql = "SELECT po.*, v.name AS vendor_name, v.code AS vendor_code
                FROM purchase_orders po
                LEFT JOIN vendors v ON v.id = po.vendor_id
                WHERE 1=1";
        $params = [];

        if (!empty($filters['status'])) {
            $sql .= " AND po.status = ?";
            $params[] = $filters['status'];
        }
        if (!empty($filters['search'])) {
            $sql .= " AND (po.po_number LIKE ? OR v.name LIKE ? OR v.code LIKE ?)";
            $s = '%' . $filters['search'] . '%';
            $params[] = $s; $params[] = $s; $params[] = $s;
        }

        $sql .= " ORDER BY po.created_at DESC LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;

        return $this->db->select($sql, $params);
    }

    public function getPO($poId) {
        return $this->db->selectOne(
            "SELECT po.*, v.name AS vendor_name, v.code AS vendor_code, v.email AS vendor_email
             FROM purchase_orders po
             LEFT JOIN vendors v ON v.id = po.vendor_id
             WHERE po.id=?",
            [(int)$poId]
        );
    }

    public function getPOLines($poId) {
        return $this->db->select(
            "SELECT * FROM purchase_order_lines WHERE po_id=? ORDER BY line_number",
            [(int)$poId]
        );
    }

    public function createFromSelectedQuote($rfqId, $quoteId, $notes = null) {
        // RFQ status selected olmalı
        $rfq = $this->db->selectOne("SELECT * FROM rfqs WHERE id=?", [(int)$rfqId]);
        if (!$rfq) throw new Exception("RFQ bulunamadı");
        if (($rfq['status'] ?? '') !== 'selected') throw new Exception("PO sadece 'selected' RFQ'dan oluşturulur");

        // Quote selected olmalı
        $q = $this->db->selectOne("SELECT * FROM quotes WHERE id=? AND rfq_id=?", [(int)$quoteId, (int)$rfqId]);
        if (!$q) throw new Exception("Quote bulunamadı");
        if (($q['status'] ?? '') !== 'selected') throw new Exception("Bu quote 'selected' değil");

        // Aynı quote'dan daha önce PO açılmış mı?
        $exists = $this->db->selectOne("SELECT id FROM purchase_orders WHERE quote_id=? LIMIT 1", [(int)$quoteId]);
        if ($exists) return (int)$exists['id'];

        $user = Auth::getInstance()->getCurrentUser();
        if (!$user) throw new Exception("Oturum bulunamadı");

        $lines = $this->db->select("SELECT * FROM quote_lines WHERE quote_id=? ORDER BY line_number", [(int)$quoteId]);
        if (empty($lines)) throw new Exception("Quote satırı yok");

        $this->db->beginTransaction();
        try {
            $poNumber = $this->generatePoNumber();

            $this->db->execute(
                "INSERT INTO purchase_orders (po_number, rfq_id, pr_id, quote_id, vendor_id, created_by, currency, total_amount, status, notes, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'created', ?, NOW())",
                [
                    $poNumber,
                    (int)$rfqId,
                    (int)($rfq['pr_id'] ?? 0) ?: null,
                    (int)$quoteId,
                    (int)$q['vendor_id'],
                    (int)$user['id'],
                    $q['currency'] ?? 'TRY',
                    (float)($q['total_amount'] ?? 0),
                    $notes
                ]
            );
            $poId = (int)$this->db->lastInsertId();

            $ln = 1;
            foreach ($lines as $l) {
                $this->db->execute(
                    "INSERT INTO purchase_order_lines
                     (po_id, quote_line_id, line_number, description, qty, unit, unit_price, tax_rate, line_total, currency, received_qty, notes)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)",
                    [
                        $poId,
                        (int)$l['id'],
                        $ln++,
                        $l['description'],
                        (float)$l['qty'],
                        $l['unit'] ?? null,
                        (float)$l['unit_price'],
                        (float)$l['tax_rate'],
                        (float)$l['line_total'],
                        $l['currency'] ?? ($q['currency'] ?? 'TRY'),
                        $l['notes'] ?? null
                    ]
                );
            }

            $this->db->commit();
            $this->logger->log('po', $poId, 'CREATE', "PO oluşturuldu: {$poNumber}");

            return $poId;
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    public function markApproved($poId) {
        $po = $this->getPO($poId);
        if (!$po) throw new Exception("PO bulunamadı");
        if (($po['status'] ?? '') !== 'created') throw new Exception("Sadece 'created' PO onaylanabilir");

        $this->db->execute("UPDATE purchase_orders SET status='approved', updated_at=NOW() WHERE id=?", [(int)$poId]);
        $this->logger->logStatusChange('po', $poId, 'created', 'approved');
        return true;
    }

    public function markSent($poId) {
        $po = $this->getPO($poId);
        if (!$po) throw new Exception("PO bulunamadı");
        if (($po['status'] ?? '') !== 'approved') throw new Exception("Sadece 'approved' PO gönderilebilir");

        $this->db->execute("UPDATE purchase_orders SET status='sent', updated_at=NOW() WHERE id=?", [(int)$poId]);
        $this->logger->logStatusChange('po', $poId, 'approved', 'sent');
        return true;
    }

    private function generatePoNumber() {
        $last = $this->db->selectOne("SELECT po_number FROM purchase_orders ORDER BY id DESC LIMIT 1");
        $next = 1;
        if ($last && !empty($last['po_number'])) {
            if (preg_match('/(\d+)$/', $last['po_number'], $m)) {
                $next = ((int)$m[1]) + 1;
            }
        }
        return sprintf('PO-%s%s-%05d', date('Y'), date('m'), $next);
    }
}
