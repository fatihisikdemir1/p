<?php
class PurchaseRequestService {
    private $db;
    private $logger;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->logger = Logger::getInstance();
    }

    public function createPurchaseRequest($data) {
        try {
            $this->db->beginTransaction();

            $lastPr = $this->db->selectOne("SELECT pr_number FROM purchase_requests ORDER BY id DESC LIMIT 1");
            $prNumber = $this->generatePRNumber($lastPr ? $lastPr['pr_number'] : null);

            $requesterName = (string)($data['requester_name'] ?? (Auth::getInstance()->getCurrentUser()['full_name'] ?? 'Kullanıcı'));
            $departmentName = (string)($data['department_name'] ?? ($data['department_id'] ? ('Departman #' . (int)$data['department_id']) : ''));

            $sql = "INSERT INTO purchase_requests
                    (pr_number, requester_id, requester_name, department_id, department_name,
                     title, description, priority, required_date, budget_code, estimated_amount, currency, justification)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $this->db->execute($sql, [
                $prNumber,
                (int)$data['requester_id'],
                $requesterName,
                (int)($data['department_id'] ?? 0) ?: null,
                $departmentName,
                $data['title'],
                $data['description'] ?? null,
                $data['priority'] ?? 'medium',
                $data['required_date'] ?? null,
                $data['budget_code'] ?? null,
                (float)($data['estimated_amount'] ?? 0),
                $data['currency'] ?? 'TRY',
                $data['justification'] ?? null,
            ]);

            $prId = (int)$this->db->lastInsertId();

            if (!empty($data['lines']) && is_array($data['lines'])) {
                foreach ($data['lines'] as $line) {
                    $this->addPRLine($prId, $line);
                }
            }

            $this->db->commit();
            $this->logger->log('purchase_request', $prId, 'CREATE', 'Satın Alma İsteği oluşturuldu');

            return $prId;

        } catch (Exception $e) {
            $this->db->rollback();
            throw new Exception("PR oluşturma hatası: " . $e->getMessage());
        }
    }

    private function addPRLine($prId, $line) {
        $sql = "INSERT INTO purchase_request_lines
                (pr_id, line_number, item_id, description, quantity, unit_of_measure,
                 unit_price, tax_rate, line_total, currency, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $qty = (float)($line['quantity'] ?? 0);
        $unit = (float)($line['unit_price'] ?? 0);
        $tax = (float)($line['tax_rate'] ?? 20);
        $lineTotal = $qty * $unit * (1 + ($tax / 100));

        $this->db->execute($sql, [
            (int)$prId,
            (int)($line['line_number'] ?? 1),
            isset($line['item_id']) ? (int)$line['item_id'] : null,
            $line['description'] ?? null,
            $qty,
            $line['unit_of_measure'] ?? '-',
            $unit,
            $tax,
            $lineTotal,
            $line['currency'] ?? 'TRY',
            $line['notes'] ?? null,
        ]);
    }

    public function submitPurchaseRequest($prId, $comment = null) {
        $pr = $this->getPurchaseRequestById($prId);
        if (!$pr) throw new Exception("PR bulunamadı");
        if ($pr['status'] !== 'draft') throw new Exception("Sadece taslak PRler gönderilebilir");

        $lines = $this->getPRLines($prId);
        if (empty($lines)) throw new Exception("PR en az bir satır içermelidir");

        $this->db->beginTransaction();

        $this->db->execute(
            "UPDATE purchase_requests SET status='submitted', submitted_at=NOW(), updated_at=NOW() WHERE id=?",
            [(int)$prId]
        );

        $this->createApprovalSteps($prId, (float)($pr['estimated_amount'] ?? 0));

        $this->db->commit();
        $this->logger->logStatusChange('purchase_request', $prId, 'draft', 'submitted');

        return true;
    }

    private function createApprovalSteps($prId, $amount) {
        // Basit limit akışı:
        // <=5k: manager, <=25k: procurement, <=100k: finance, >100k: super_admin/admin
        $amount = (float)$amount;

        if ($amount <= 5000)       $role = 'manager';
        elseif ($amount <= 25000)  $role = 'procurement';
        elseif ($amount <= 100000) $role = 'finance';
        else                       $role = 'super_admin';

        $approverId = $this->findApproverUserId($role);
        if (!$approverId) $approverId = $this->findApproverUserId('admin');
        if (!$approverId) return; // hiç bulamazsa PR submitted kalır

        $this->db->execute(
            "INSERT INTO approvals (entity_type, entity_id, step, approver_id, status) VALUES ('purchase_request', ?, 1, ?, 'pending')",
            [(int)$prId, (int)$approverId]
        );
    }

    private function findApproverUserId(string $role): ?int {
        $role = strtolower($role);

        $candidates = [$role];
        if ($role === 'super_admin') $candidates = ['super_admin','admin'];
        if ($role === 'admin') $candidates = ['admin','super_admin'];
        if ($role === 'manager') $candidates = ['manager','department_manager','dept_manager','admin','super_admin'];
        if ($role === 'procurement') $candidates = ['procurement','purchasing','buyer','admin','super_admin'];
        if ($role === 'finance') $candidates = ['finance','accounting','muhasebe','admin','super_admin'];

        $ph = implode(',', array_fill(0, count($candidates), '?'));
        $row = $this->db->selectOne("SELECT id FROM users WHERE role IN ($ph) ORDER BY id ASC LIMIT 1", $candidates);
        return $row ? (int)$row['id'] : null;
    }

    public function approvePurchaseRequest($prId, $approverId, $comment = null) {
        $this->db->beginTransaction();

        $this->db->execute(
            "UPDATE approvals SET status='approved', comment=?, decided_at=NOW()
             WHERE entity_type='purchase_request' AND entity_id=? AND approver_id=? AND status='pending'",
            [$comment, (int)$prId, (int)$approverId]
        );

        $pending = $this->db->select(
            "SELECT id FROM approvals WHERE entity_type='purchase_request' AND entity_id=? AND status='pending'",
            [(int)$prId]
        );

        if (empty($pending)) {
            $this->db->execute(
                "UPDATE purchase_requests SET status='approved', approved_at=NOW(), updated_at=NOW() WHERE id=?",
                [(int)$prId]
            );
        }

        $this->db->commit();
        $this->logger->logApproval('purchase_request', $prId, 'approved', $comment);
        return true;
    }

    public function rejectPurchaseRequest($prId, $approverId, $comment = null) {
        $this->db->beginTransaction();

        $this->db->execute(
            "UPDATE approvals SET status='rejected', comment=?, decided_at=NOW()
             WHERE entity_type='purchase_request' AND entity_id=? AND approver_id=? AND status='pending'",
            [$comment, (int)$prId, (int)$approverId]
        );

        $this->db->execute(
            "UPDATE purchase_requests SET status='rejected', rejected_at=NOW(), updated_at=NOW() WHERE id=?",
            [(int)$prId]
        );

        $this->db->commit();
        $this->logger->logStatusChange('purchase_request', $prId, 'submitted', 'rejected', $comment);
        return true;
    }

    public function getPurchaseRequestById($prId) {
        return $this->db->selectOne("SELECT * FROM purchase_requests WHERE id = ?", [(int)$prId]);
    }

    public function listPurchaseRequests($filters = [], $limit = 50, $offset = 0) {
        $sql = "SELECT pr.* FROM purchase_requests pr WHERE 1=1";
        $params = [];

        if (isset($filters['status'])) {
            $sql .= " AND pr.status = ?";
            $params[] = $filters['status'];
        }

        if (isset($filters['requester_id'])) {
            $sql .= " AND pr.requester_id = ?";
            $params[] = (int)$filters['requester_id'];
        }

        if (isset($filters['search'])) {
            $sql .= " AND (pr.pr_number LIKE ? OR pr.title LIKE ?)";
            $search = '%' . $filters['search'] . '%';
            $params[] = $search;
            $params[] = $search;
        }

        $sql .= " ORDER BY pr.created_at DESC LIMIT ? OFFSET ?";
        $params[] = (int)$limit;
        $params[] = (int)$offset;

        return $this->db->select($sql, $params);
    }

    public function getPRLines($prId) {
        return $this->db->select(
            "SELECT * FROM purchase_request_lines WHERE pr_id = ? ORDER BY line_number",
            [(int)$prId]
        );
    }

    public function calculatePRTotal($prId) {
        $row = $this->db->selectOne(
            "SELECT SUM(line_total) AS total FROM purchase_request_lines WHERE pr_id = ?",
            [(int)$prId]
        );
        return (float)($row['total'] ?? 0);
    }

    private function generatePRNumber($lastNumber = null) {
        if ($lastNumber) {
            preg_match('/(\d+)$/', $lastNumber, $m);
            $next = (int)($m[1] ?? 0) + 1;
        } else {
            $next = 1;
        }
        return sprintf('PR-%s%s-%05d', date('Y'), date('m'), $next);
    }
}
