<?php
echo "OK - " . __FILE__;
