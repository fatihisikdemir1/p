<?php
require_once __DIR__ . '/../includes/bootstrap.php';

class PoController {
    private $service;

    public function __construct() {
        $this->service = new PoService();
    }

    public function list() {
        require_login();

        $page = (int)($_GET['page'] ?? 1);
        $status = $_GET['status'] ?? '';
        $search = $_GET['search'] ?? '';
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $pos = $this->service->listPOs(
            ['status' => $status ?: null, 'search' => $search ?: null],
            $limit,
            $offset
        );

        include PROCUREMENT_DIR . '/views/po_list.php';
    }

    public function view($id) {
        require_login();

        $po = $this->service->getPO($id);
        if (!$po) { http_response_code(404); die("PO bulunamadı"); }
        $lines = $this->service->getPOLines($id);

        include PROCUREMENT_DIR . '/views/po_detail.php';
    }

    public function createFromSelected() {
        require_permission('create_rfq'); // procurement/admin
        try {
            $rfqId = (int)($_POST['rfq_id'] ?? 0);
            $quoteId = (int)($_POST['quote_id'] ?? 0);
            $notes = $_POST['notes'] ?? null;
            if (!$rfqId || !$quoteId) throw new Exception("rfq_id ve quote_id gerekli");

            $poId = $this->service->createFromSelectedQuote($rfqId, $quoteId, $notes);
            Utils::redirect(PROCUREMENT_URL . "/controllers/PoController.php?action=view&id=" . (int)$poId);
        } catch (Exception $e) {
            http_response_code(400);
            die($e->getMessage());
        }
    }

    public function approve($id) {
        require_permission('approve');
        try {
            $this->service->markApproved($id);
            Utils::redirect(PROCUREMENT_URL . "/controllers/PoController.php?action=view&id=" . (int)$id);
        } catch (Exception $e) {
            http_response_code(400);
            die($e->getMessage());
        }
    }

    public function send($id) {
        require_permission('create_rfq');
        try {
            $this->service->markSent($id);
            Utils::redirect(PROCUREMENT_URL . "/controllers/PoController.php?action=view&id=" . (int)$id);
        } catch (Exception $e) {
            http_response_code(400);
            die($e->getMessage());
        }
    }
}

$action = $_GET['action'] ?? 'list';
$id = (int)($_GET['id'] ?? 0);

$c = new PoController();

switch ($action) {
    case 'view': if(!$id) die("id gerekli"); $c->view($id); break;
    case 'createFromSelected': $c->createFromSelected(); break;
    case 'approve': if(!$id) die("id gerekli"); $c->approve($id); break;
    case 'send': if(!$id) die("id gerekli"); $c->send($id); break;
    default: $c->list();
}
