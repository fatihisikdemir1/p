<?php
require_once __DIR__ . '/../includes/bootstrap.php';

class PurchaseRequestController {
    private $service;

    public function __construct() {
        $this->service = new PurchaseRequestService();
    }

    public function list() {
        require_login();

        $page = (int)($_GET['page'] ?? 1);
        $status = $_GET['status'] ?? null;
        $search = $_GET['search'] ?? null;
        $itemsPerPage = 20;

        $filters = [];
        $auth = Auth::getInstance();
        $user = $auth->getCurrentUser();

        // Basit scope:
        // requester: sadece kendi PR
        // diğer roller: hepsini görebilir (istersen departman scope ekleriz)
        if ($auth->hasRole('requester')) {
            $filters['requester_id'] = (int)$user['id'];
        }

        if ($status) $filters['status'] = $status;
        if ($search) $filters['search'] = $search;

        $prs = $this->service->listPurchaseRequests($filters, $itemsPerPage, ($page - 1) * $itemsPerPage);

        include PROCUREMENT_DIR . '/views/purchase_request_list.php';
    }

    public function view($prId) {
        require_login();

        $pr = $this->service->getPurchaseRequestById($prId);
        if (!$pr) {
            http_response_code(404);
            die("PR bulunamadı");
        }

        // Erişim: admin/procurement/finance/warehouse görebilir, requester sadece kendi
        $auth = Auth::getInstance();
        $u = $auth->getCurrentUser();
        $can = $auth->hasAnyRole(['admin','procurement','finance','warehouse','approver'])
            || ((int)$pr['requester_id'] === (int)($u['id'] ?? 0));

        if (!$can) {
            http_response_code(403);
            die("Yetkiniz yok");
        }

        $lines = $this->service->getPRLines($prId);
        $total = $this->service->calculatePRTotal($prId);
        $auditLogs = Logger::getInstance()->getAuditLogs('purchase_request', $prId);

        include PROCUREMENT_DIR . '/views/purchase_request_detail.php';
    }

    public function create() {
        require_permission('create_pr');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                $user = Auth::getInstance()->getCurrentUser();

                $data = [
                    'requester_id' => (int)$user['id'],
                    'requester_name' => (string)$user['full_name'],
                    'department_id' => (int)($user['department_id'] ?? 0),
                    'department_name' => (int)($user['department_id'] ?? 0) ? ('Departman #' . (int)$user['department_id']) : '',
                    'title' => $_POST['title'] ?? null,
                    'description' => $_POST['description'] ?? null,
                    'priority' => $_POST['priority'] ?? 'medium',
                    'required_date' => $_POST['required_date'] ?? null,
                    'budget_code' => $_POST['budget_code'] ?? null,
                    'estimated_amount' => (float)($_POST['estimated_amount'] ?? 0),
                    'justification' => $_POST['justification'] ?? null,
                    'lines' => $this->parseLines($_POST),
                ];

                if (!$data['title']) throw new Exception("Başlık gerekli");

                $prId = $this->service->createPurchaseRequest($data);
                Utils::redirect(PROCUREMENT_URL . '/controllers/PurchaseRequestController.php?action=view&id=' . (int)$prId);

            } catch (Exception $e) {
                $error = $e->getMessage();
                include PROCUREMENT_DIR . '/views/purchase_request_form.php';
            }
        } else {
            include PROCUREMENT_DIR . '/views/purchase_request_form.php';
        }
    }

    public function submit($prId) {
        require_login();
        try {
            $this->service->submitPurchaseRequest($prId);
            Utils::jsonResponse(['success' => true, 'message' => 'PR başarıyla gönderildi']);
        } catch (Exception $e) {
            http_response_code(400);
            Utils::jsonResponse(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    public function approve($prId) {
        require_permission('approve');
        try {
            $user = Auth::getInstance()->getCurrentUser();
            $comment = $_POST['comment'] ?? null;

            $this->service->approvePurchaseRequest($prId, (int)$user['id'], $comment);
            Utils::jsonResponse(['success' => true, 'message' => 'PR onaylandı']);
        } catch (Exception $e) {
            http_response_code(400);
            Utils::jsonResponse(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    public function reject($prId) {
        require_permission('approve');
        try {
            $user = Auth::getInstance()->getCurrentUser();
            $comment = $_POST['comment'] ?? null;

            $this->service->rejectPurchaseRequest($prId, (int)$user['id'], $comment);
            Utils::jsonResponse(['success' => true, 'message' => 'PR reddedildi']);
        } catch (Exception $e) {
            http_response_code(400);
            Utils::jsonResponse(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    private function parseLines($post) {
        $lines = [];

        $quantities = $post['line_quantity'] ?? [];
        $unitPrices = $post['line_unit_price'] ?? [];
        $descriptions = $post['line_description'] ?? [];

        foreach ($quantities as $index => $quantity) {
            if ((float)$quantity > 0) {
                $lines[] = [
                    'line_number' => $index + 1,
                    'description' => $descriptions[$index] ?? null,
                    'quantity' => (float)$quantity,
                    'unit_price' => (float)($unitPrices[$index] ?? 0),
                    'unit_of_measure' => 'Adet',
                ];
            }
        }
        return $lines;
    }
}

// Router
$action = $_GET['action'] ?? 'list';
$id = (int)($_GET['id'] ?? 0);

$controller = new PurchaseRequestController();

switch ($action) {
    case 'create': $controller->create(); break;
    case 'view': if (!$id) die("PR ID gerekli"); $controller->view($id); break;
    case 'submit': if (!$id) die("PR ID gerekli"); $controller->submit($id); break;
    case 'approve': if (!$id) die("PR ID gerekli"); $controller->approve($id); break;
    case 'reject': if (!$id) die("PR ID gerekli"); $controller->reject($id); break;
    default: $controller->list();
}
