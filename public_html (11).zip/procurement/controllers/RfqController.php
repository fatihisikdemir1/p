<?php
require_once __DIR__ . '/../includes/bootstrap.php';

class RfqController {
    private $service;

    public function __construct() {
        $this->service = new RfqService();
    }

    public function list() {
        require_login();

        $page = (int)($_GET['page'] ?? 1);
        $status = $_GET['status'] ?? '';
        $search = $_GET['search'] ?? '';
        $limit = 20;
        $offset = ($page - 1) * $limit;

        $rfqs = $this->service->listRfqs(
            ['status' => $status ?: null, 'search' => $search ?: null],
            $limit,
            $offset
        );

        include PROCUREMENT_DIR . '/views/rfq_list.php';
    }

    public function view($id) {
        require_login();

        $rfq = $this->service->getRfq($id);
        if (!$rfq) { http_response_code(404); die("RFQ bulunamadı"); }

        $vendors = $this->service->getRfqVendors($id);
        $quotes  = $this->service->getQuotes($id);

        include PROCUREMENT_DIR . '/views/rfq_detail.php';
    }

    public function create() {
        require_permission('create_rfq');

        $db = Database::getInstance();

        // sadece onaylı PR’ler
        $approvedPRs = $db->select("SELECT id, pr_number, title FROM purchase_requests WHERE status='approved' ORDER BY id DESC LIMIT 100");
        $vendorList  = $db->select("SELECT id, code, name FROM vendors WHERE is_active=1 ORDER BY name");

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                $prId = (int)($_POST['pr_id'] ?? 0);
                $due  = $_POST['due_date'] ?? null;
                $notes = $_POST['notes'] ?? null;
                $vendorIds = $_POST['vendor_ids'] ?? [];

                $rfqId = $this->service->createFromApprovedPr($prId, $due, array_map('intval', (array)$vendorIds), $notes);
                Utils::redirect(PROCUREMENT_URL . "/controllers/RfqController.php?action=view&id=" . (int)$rfqId);
            } catch (Exception $e) {
                $error = $e->getMessage();
                include PROCUREMENT_DIR . '/views/rfq_list.php';
                return;
            }
        }

        include PROCUREMENT_DIR . '/views/rfq_list.php';
    }

    public function send($id) {
        require_permission('create_rfq');
        try {
            $via = $_POST['sent_via'] ?? 'email';
            $this->service->markSent($id, $via);
            Utils::redirect(PROCUREMENT_URL . "/controllers/RfqController.php?action=view&id=" . (int)$id);
        } catch (Exception $e) {
            http_response_code(400);
            die($e->getMessage());
        }
    }

    public function submitQuote($id) {
        require_permission('create_rfq');

        try {
            $vendorId = (int)($_POST['vendor_id'] ?? 0);
            if (!$vendorId) throw new Exception("vendor_id gerekli");

            $header = [
                'currency' => $_POST['currency'] ?? 'TRY',
                'payment_terms' => $_POST['payment_terms'] ?? null,
                'delivery_terms' => $_POST['delivery_terms'] ?? null,
                'lead_time_days' => (int)($_POST['lead_time_days'] ?? 0),
            ];

            // satırlar
            $lines = [];
            $desc = $_POST['line_desc'] ?? [];
            $qty  = $_POST['line_qty'] ?? [];
            $price= $_POST['line_price'] ?? [];
            $tax  = $_POST['line_tax'] ?? [];

            for ($i=0; $i < count((array)$qty); $i++) {
                $q = (float)($qty[$i] ?? 0);
                if ($q <= 0) continue;
                $lines[] = [
                    'description' => $desc[$i] ?? '-',
                    'qty' => $q,
                    'unit_price' => (float)($price[$i] ?? 0),
                    'tax_rate' => (float)($tax[$i] ?? 20),
                    'unit' => null,
                ];
            }

            $this->service->upsertQuote($id, $vendorId, $header, $lines);
            Utils::redirect(PROCUREMENT_URL . "/controllers/RfqController.php?action=view&id=" . (int)$id);
        } catch (Exception $e) {
            http_response_code(400);
            die($e->getMessage());
        }
    }

    public function select($id) {
        require_permission('create_rfq');
        try {
            $quoteId = (int)($_POST['quote_id'] ?? 0);
            if (!$quoteId) throw new Exception("quote_id gerekli");

            $this->service->selectWinner($id, $quoteId);
            Utils::redirect(PROCUREMENT_URL . "/controllers/RfqController.php?action=view&id=" . (int)$id);
        } catch (Exception $e) {
            http_response_code(400);
            die($e->getMessage());
        }
    }
}

$action = $_GET['action'] ?? 'list';
$id = (int)($_GET['id'] ?? 0);

$c = new RfqController();

switch ($action) {
    case 'create': $c->create(); break;
    case 'view': if (!$id) die("id gerekli"); $c->view($id); break;
    case 'send': if (!$id) die("id gerekli"); $c->send($id); break;
    case 'submitQuote': if (!$id) die("id gerekli"); $c->submitQuote($id); break;
    case 'select': if (!$id) die("id gerekli"); $c->select($id); break;
    default: $c->list();
}
