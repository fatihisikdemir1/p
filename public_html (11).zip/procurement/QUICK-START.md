# 🚀 Hızlı Başlangıç Rehberi

Satın Alma Sistemini 5 dakika içinde başlatın!

## 0️⃣ Ön Koşullar

- PHP 7.4+
- MySQL 5.7+
- Web Sunucusu (Apache/Nginx) veya PHP built-in sunucusu

## 1️⃣ Veritabanı Kurulumu

### Terminal'den Çalıştır

```bash
cd kurumsal-web-sitesi

# MySQL'e bağlan ve veritabanı şemasını yükle
mysql -h localhost -u u336896947_admin -p147Fatih... u336896947_workflow < procurement_schema.sql
```

### veey phpMyAdmin'den

1. phpMyAdmin aç
2. `u336896947_workflow` veritabanını seç
3. "SQL" sekmesine git
4. `procurement_schema.sql` dosyasının içeriğini yapıştır
5. "Çalıştır" butonuna tıkla

## 2️⃣ Web Sunucusunu Başlat

### PHP Built-in Sunucu (En Kolay)
```bash
cd kurumsal-web-sitesi
php -S localhost:8000
```

### Apache/Nginx
Web sunucusunu `kurumsal-web-sitesi` klasörüne işaret ettirin.

## 3️⃣ Sisteme Giriş

**URL**: `http://localhost:8000/procurement/views/login.php`

**İlk Giriş Bilgileri:**
- 👤 **Kullanıcı Adı**: `admin`
- 🔑 **Şifre**: `admin123`

## 4️⃣ Dashboard

Giriş yaptıktan sonra ana dashboard'a yönlendirilirsiniz.

| Menü | Açıklama |
|------|----------|
| 📊 Dashboard | Ana gösterge paneli |
| 📋 Satın Alma İstekleri | PR yönetimi |
| 📮 RFQ / Teklifler | Teklif toplama |
| 📦 Siparişler (PO) | Satın alma siparişleri |
| ✓ Mal Kabul (GRN) | Teslim alma |
| 💰 Faturalar | Fatura yönetimi |
| 🤝 Tedarikçiler | Tedarikçi yönetimi |

## 5️⃣ İlk PR Oluştur

1. **"Yeni İstek Oluştur"** butonuna tıkla
2. **Başlık**: "Yazılım Lisansı Satın Al"
3. **Departman**: İstediğin departmanı seç
4. **Tahmini Tutar**: 5000 TRY
5. **Satır Ekle**: 
   - Açıklama: "Office 365 - 10 Lisans"
   - Miktar: 10
   - Birim Fiyat: 500
6. **Kaydet** ve **Gönder** butonlarına tıkla

## 📊 Temel Kullanım Akışı

```
1. PR Oluştur → 2. Gönder → 3. Onayla → 4. RFQ Oluştur → 
5. Teklif Al → 6. PO Oluştur → 7. GRN (Mal Kabul) → 
8. Fatura Gir → 9. Eşleştir → 10. Ödeme
```

### Adım 1: PR Oluştur
![PR Oluştur](https://via.placeholder.com/600x300?text=Step+1:+Create+PR)

```
📋 Satın Alma İstekleri > Yeni İstek Oluştur
- Başlık, Açıklama
- Departman, Bütçe Kodu
- Satırlar (ne satın alınacak)
- Kaydet
```

### Adım 2: Gönder & Onay
```
PR > Gönder Butonu
→ Sistem onaylayıcılara otomatik bildirim gönderir
→ Onay akışı başlar (limit bazlı)
```

### Adım 3: RFQ Oluştur
```
Onaylanan PR > RFQ Oluştur
- Tedarikçileri seç (1+)
- RFQ gönder (otomatik loglanır)
- Teklif almayı bekle
```

### Adım 4: PO (Sipariş) Oluştur
```
En iyi teklife RFQ > PO Oluştur
- İçerik tekliften auto-doldurulur
- PO numarası otomatik
- PDF çıktı al
- Satıcıya gönder
```

### Adım 5: Mal Kabul (GRN)
```
PO > Mal Kabul Et
- GRN numarası otomatik
- Teslim alınan miktarı gir
- İrsaliye belgesi ekle
- Stok güncellenir
```

### Adım 6: Fatura
```
Fatura > Yeni Fatura
- PO'ye bağla
- Fatura detaylarını gir
- 3-Way Match otomatik
```

### Adım 7: Ödeme
```
Fatura > Ödeme Talimatı
- Ödeme tutarı
- Yöntem (Banka, Çek, vb)
- Onay > Ödeme
```

## 🔧 Yönetim Paneli

Admin olarak sisteme girmişseniz, **⚙️ Ayarlar**'a erişebilirsiniz:

- 👥 **Kullanıcı Yönetimi**: Rol ve izinleri ayarla
- 🏢 **Departmanlar**: Departman ekle/düzenle
- 📦 **Ürün Kataloğu**: Ürün/hizmet ekle
- 🤝 **Tedarikçiler**: Tedarikçi kart
- ⚡ **Onay Kuralları**: Limit bazlı onay
- 📋 **Audit Logları**: Tüm işlem geçmişi

## 🔐 Rol Ayarı

Sistem 6 rolü destekler:

| Rol | İzinler |
|-----|---------|
| **Admin** | Tüm işlemler + Sistem yönetimi |
| **Requester** | Sadece PR oluşturma |
| **Approver** | PR onay/red |
| **Procurement** | RFQ, PO, tedarikçi |
| **Warehouse** | GRN, mal kabul |
| **Finance** | Fatura, ödeme, bütçe |

## 🐛 İlk Sorunlar

### 1. "Veritabanına bağlanamıyor"
```bash
# Veritabanı aktif mı kontrol et
mysql -h localhost -u u336896947_admin -p147Fatih... -e "SELECT 1"
```

### 2. "Login sayfası hata veriyor"
```bash
# PHP sürümü kontrol et
php -v

# Session klasörü iznileri kontrol et
chmod -R 755 /tmp
```

### 3. "Dosya yüklenemiyor"
```bash
# Upload klasörlerini oluştur
mkdir -p procurement/uploads/{pr,po,rfq,invoice,grn,vendors}
chmod -R 755 procurement/uploads
```

## 📞 Yardım & Destek

**Soruların varsa:**
1. README.md dosyasını oku
2. Audit loglarını kontrol et (Dashboard > Veriler > Loglar)
3. Browser console'unu kontrol et (F12)
4. PHP error log'unu kontrol et

## 🎓 Örnek Veriler

Sisteme örnek tedarikçi ve ürünler zaten yüklü:

**Tedarikçiler:**
- ABC Teknoloji Ltd. Şti.
- XYZ Hizmetleri A.Ş.
- Global Supplies Inc.

**Ürünler:**
- Yazılım Lisansı - Office 365
- Dizüstü Bilgisayar
- Danışmanlık Hizmetleri
- Sunucu Barındırma
- Yazıcı - LaserJet

## 🚀 Sonraki Adımlar

1. **Kullanıcı ekle**: Takım üyeleriniz için hesap oluştur
2. **Tedarikçileri güncelleştir**: Gerçek tedarikçileri ekle
3. **Ürün kataloğunu doldur**: İhtiyaç duyduğunuz ürünleri ekle
4. **Onay kurallarını ayarla**: Şirkete göre özelleştir
5. **Muhasebaya entegre et**: Logo/Parasut vb. sistemler

## 💡 İpuçları

✅ **Dashboard'ı her gün kontrol et** - Bekleyen işlemler hızlı görülür

✅ **Audit loglarını kullan** - Kim, ne yaptı, ne zaman = Tam takip

✅ **Şablon kullan** - Tekrar eden işlemler için otomasyondur

✅ **Rol ata doğru** - Güvenlik açısından kritik

✅ **Excel import çalışıyor** - Toplu PR/PO ekle

---

**Kurulum Tamamlandı! 🎉**

Sistemi kullanmaya başla ve feedbackını bize gönder!
