<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (Auth::getInstance()->isLoggedIn()) {
    Utils::redirect(PROCUREMENT_URL . '/views/dashboard.php');
} else {
    Utils::redirect('/login.php');
}
