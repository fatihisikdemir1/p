# 📦 Kurumsal Satın Alma Yönetim Sistemi

Profesyonel, tam otomatik ve açık kodlu satın alma (procurement) yönetim sistemi.

## 🎯 Özellikler

### ✅ Temel İşlemler
- **PR (Satın Alma İsteği)**: Yönetim, onay akışı, takip
- **RFQ (Teklif Toplama)**: Tedarikçilere RFQ gönderi, teklif yönetimi
- **PO (Sipariş)**: PO oluşturma, onay, PDF çıktı
- **GRN (Mal Kabul)**: Teslim alma, kısmi teslim, stok girişi
- **Fatura**: Fatura girişi, 3-way eşleştirme
- **Ödeme**: Ödeme talimatı, muhasebe entegrasyonu

### 👥 Roller & Yetkilendirme
- **Admin**: Tüm işlevler, sistem yönetimi
- **Requester**: Talep oluşturma, takip
- **Approver**: Onay/red işlemi
- **Procurement**: RFQ, PO, tedarikçi yönetimi
- **Warehouse**: Mal kabul, GRN
- **Finance**: Fatura, ödeme, bütçe kontrol

### 🔐 Güvenlik
- RBAC (Role-Based Access Control)
- Audit logging (tüm işlemlerin kaydı)
- Prepared statements (SQL injection koruması)
- Data isolation (departman bazlı)

### 📊 Dashboard & KPIs
- Gerçek zamanlı istatistikler
- Bekleyen onaylar
- Son işlemler
- Açık talepç raporu

## 🚀 Kurulum

### 1. Veritabanı Oluştur

```bash
mysql -h localhost -u u336896947_admin -p147Fatih... u336896947_workflow < procurement_schema.sql
```

**Veritabanı Bilgileri:**
- Host: `localhost`
- Veritabanı: `u336896947_workflow`
- Kullanıcı: `u336896947_admin`
- Şifre: `147Fatih...`

### 2. Dosyaları Yerleştir

Proje dosyaları `kurumsal-web-sitesi/procurement/` klasöründe bulunmaktadır.

### 3. Admin Kullanıcı Oluştur

Veritabanı şemasında otomatik olarak gelen admin kullanıcı:
- **Kullanıcı Adı**: `admin`
- **Şifre**: `admin123`

### 4. Web Sunucusunu Başlat

```bash
php -S localhost:8000
```

### 5. Sistem Erişimi

- **URL**: `http://localhost:8000/procurement/views/login.php`
- **İlk Giriş**: admin / admin123

## 📁 Proje Yapısı

```
procurement/
├── assets/                    # CSS, JavaScript, görseller
│   ├── style.css            # Kurumsal tasarım
│   └── script.js            # İstemci tarafı işlevler
├── controllers/             # HTTP İsteklerini işle
│   └── PurchaseRequestController.php
├── services/               # İş mantığı
│   └── PurchaseRequestService.php
├── models/                 # Veri modelleri (hazırda)
├── views/                  # Şablon dosyaları
│   ├── login.php
│   ├── dashboard.php
│   ├── purchase_request_list.php
│   ├── purchase_request_detail.php
│   └── purchase_request_form.php
├── includes/              # Temel sınıflar
│   ├── bootstrap.php      # Başlangıç dosyası
│   ├── Database.php       # PDO bağlantı
│   ├── Auth.php          # RBAC & Kimlik doğrulama
│   ├── Logger.php        # Audit logging
│   └── Utils.php         # Yardımcı fonksiyonlar
├── logs/                 # Sistem logları
└── uploads/              # Dosya yüklemeleri
    ├── pr/
    ├── po/
    ├── rfq/
    ├── invoice/
    ├── grn/
    └── vendors/
```

## 🔄 Satın Alma Süreci (Akış)

```
1. PR OLUŞTUR (Purchase Request)
   └─ Departman → Ürün/Hizmet → Miktar → Tarih → Bütçe
   
2. ONAY AKIŞI
   └─ Talep Sahibi → Departman M. → Satın Alma → Finans → GM/CFO
   
3. RFQ / TEKLİF TOPLAMA
   └─ RFQ Oluştur → Tedarikçilere Gönder → Teklifler Al → Karşılaştır
   
4. PO (SIPARIŞ)
   └─ PO Oluştur (seçili tekliften) → Onayla → Gönder → PDF
   
5. MAL KABUL (GRN)
   └─ Teslim Al → İrsaliye → Stok Girişi → Kısmi Teslim Desteği
   
6. FATURA & EŞLEŞTME
   └─ Fatura Gir → 3-Way Match (PO↔GRN↔Fatura) → Exception Yönetimi
   
7. ÖDEME
   └─ Ödeme Talimatı → Onay → Muhasebe → Banka (Opsiyonel)
```

## 🗄️ Veritabanı Şeması

### Ana Tablolar

**users** - Kullanıcılar
- id, username, email, password, full_name, role, department_id

**departments** - Departmanlar
- id, code, name, manager_id, budget_code

**vendors** - Tedarikçiler
- id, code, name, email, phone, bank_info, tax_id, performance_score

**items** - Ürün/Hizmet Kataloğu
- id, code, name, category, unit_of_measure, standard_price

**purchase_requests** - Satın Alma İstekleri
- id, pr_number, title, description, requester_id, department_id, estimated_amount, status, required_date

**purchase_order_lines** - PO Satırları
- id, po_id, item_id, quantity, unit_price, line_total

**goods_receipts** - Mal Kabul (GRN)
- id, grn_number, po_id, received_by, receipt_date, status

**invoices** - Faturalar
- id, invoice_number, po_id, vendor_id, invoice_amount, status, payment_status

**three_way_matches** - 3-Way Eşleştirme
- id, invoice_id, po_id, grn_id, match_status, approval_required

**audit_logs** - Düzetim Logları
- id, user_id, entity_type, entity_id, action, old_value, new_value, created_at

## 📋 Onay Kuralları

Varsayılan kurallar:

| Miktar | Onaylayan | Adım |
|--------|-----------|------|
| 0 - 5.000 TRY | Departman M. | 1 |
| 5.001 - 25.000 TRY | Satın Alma | 1 |
| 25.001 - 100.000 TRY | Finans | 2 |
| 100.000+ TRY | GM/CFO | 3 |

Admin panelden değiştirebilirsiniz.

## 🔐 Kimlik Doğrulama

### Giriş
```php
$auth = Auth::getInstance();
$auth->login($username, $password);
```

### İzin Kontrol
```php
// Rol kontrolü
if ($auth->hasRole('admin')) { ... }

// İzin kontrolü
if ($auth->hasPermission('create_pr')) { ... }

// Bütçe limitine göre
if ($auth->canApprove(50000)) { ... }
```

## 📝 API Kullanımı

### PR Oluştur
```php
$service = new PurchaseRequestService();
$prId = $service->createPurchaseRequest([
    'requester_id' => 1,
    'department_id' => 1,
    'title' => 'Yazılım Lisansı Satın Al',
    'estimated_amount' => 5000,
    'lines' => [
        [
            'description' => 'Office 365 Lisansı',
            'quantity' => 10,
            'unit_price' => 500
        ]
    ]
]);
```

### PR Gönder (Onay İçin)
```php
$service->submitPurchaseRequest($prId);
```

### PR Onayla
```php
$service->approvePurchaseRequest($prId, $approverId, 'Onaylıyorum');
```

## 🛠️ Genişletme

### Yeni Modül Oluştur

1. **Model oluştur**: `procurement/models/YourModel.php`
2. **Service yaz**: `procurement/services/YourService.php`
3. **Controller ekle**: `procurement/controllers/YourController.php`
4. **View oluştur**: `procurement/views/your_page.php`

### Muhasebe Entegrasyonu

```php
// Logo/Parasut/NetSis gibi sistemlere bağlan
$accounting = new AccountingService();
$accounting->createEntry(
    'purchase_order',
    $poId,
    'debit_account',
    'credit_account',
    $amount
);
```

## 📊 Raporlar (Hazırlanan)

- [ ] Tedarikçi Performans Raporu
- [ ] Aylık Satın Alma Raporu
- [ ] Bütçe Tüketim Raporu
- [ ] Exception Raporu
- [ ] Ödeme Analizi

## 🐛 Sık Sorulan Sorunlar

**S: "Veritabanına bağlanamıyor" hatası alıyorum**

C: Veritabanı kredilerini kontrol edin:
```php
// procurement/includes/Database.php
// 14-19. satırlarda kredileri düzenleyin
```

**S: Rol tabanlı erişim çalışmıyor**

C: Session'ın başlatılmasını kontrol edin:
```php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
```

**S: Dosya yüklemesi başarısız oluyor**

C: Upload klasörlerinin izinlerini kontrol edin:
```bash
chmod -R 755 procurement/uploads/
```

## 📞 Destek

Sorunlar için PR açabilir veya issue oluşturabilirsiniz.

## 📄 Lisans

MIT License - Açık kaynak. Özgürce kullanabilirsiniz.

---

**Geliştirme Tarihi**: Şubat 2026  
**Versiyon**: 1.0.0  
**Durum**: Aktif Geliştirme
