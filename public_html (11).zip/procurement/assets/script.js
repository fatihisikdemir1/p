/**
 * Satın Alma Sistemi - JavaScript
 */

// Modal İşlevleri
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
    }
}

// Modal dışına tıklandığında kapat
window.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('show');
    }
});

// Form Validasyonu
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;

    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;

    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('error');
            isValid = false;
        } else {
            field.classList.remove('error');
        }
    });

    return isValid;
}

// AJAX İsteği
function makeRequest(url, method = 'GET', data = null) {
    const options = {
        method: method,
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    };

    if (data && method !== 'GET') {
        options.body = JSON.stringify(data);
    }

    return fetch(url, options)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Sunucu hatası: ${response.status}`);
            }
            return response.json();
        })
        .catch(error => {
            console.error('Request hatası:', error);
            throw error;
        });
}

// PR Gönder
function submitPR(prId) {
    if (!confirm('Bu isteği göndermek istediğinize emin misiniz?')) {
        return;
    }

    const url = `./PurchaseRequestController.php?action=submit&id=${prId}`;
    makeRequest(url, 'POST')
        .then(response => {
            if (response.success) {
                alert('İstek başarıyla gönderildi!');
                location.reload();
            } else {
                alert('Hata: ' + response.error);
            }
        })
        .catch(error => alert('Hata: ' + error.message));
}

// PR Onayla
function approvePR(prId) {
    const comment = prompt('Onay yorumu (opsiyonel):');
    
    const url = `./PurchaseRequestController.php?action=approve&id=${prId}`;
    const data = { comment: comment };
    
    makeRequest(url, 'POST', data)
        .then(response => {
            if (response.success) {
                alert('İstek onaylandı!');
                location.reload();
            } else {
                alert('Hata: ' + response.error);
            }
        })
        .catch(error => alert('Hata: ' + error.message));
}

// PR Reddet
function rejectPR(prId) {
    const comment = prompt('Red nedeni:');
    if (!comment) return;
    
    const url = `./PurchaseRequestController.php?action=reject&id=${prId}`;
    const data = { comment: comment };
    
    makeRequest(url, 'POST', data)
        .then(response => {
            if (response.success) {
                alert('İstek reddedildi!');
                location.reload();
            } else {
                alert('Hata: ' + response.error);
            }
        })
        .catch(error => alert('Hata: ' + error.message));
}

// Satır Ekleme
let lineCount = 1;

function addLine() {
    lineCount++;
    const html = `
        <div id="line-${lineCount}" class="form-group" style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin-bottom: 15px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <h4>Satır ${lineCount}</h4>
                <button type="button" class="btn btn-danger btn-sm" onclick="removeLine(${lineCount})">🗑️ Sil</button>
            </div>
            <div class="input-group">
                <input type="text" name="line_description[]" placeholder="Açıklama" required>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 10px;">
                <input type="number" name="line_quantity[]" placeholder="Miktar" step="0.01" required>
                <input type="number" name="line_unit_price[]" placeholder="Birim Fiyat" step="0.01" required>
                <input type="text" name="line_unit_of_measure[]" placeholder="Birim" value="Adet">
            </div>
        </div>
    `;
    document.getElementById('lines-container').insertAdjacentHTML('beforeend', html);
}

function removeLine(lineId) {
    if (lineCount > 1) {
        document.getElementById(`line-${lineId}`).remove();
    }
}

// Para Formatı
function formatCurrency(value) {
    return new Intl.NumberFormat('tr-TR', {
        style: 'currency',
        currency: 'TRY'
    }).format(value);
}

// Tarih Formatı (TR)
function formatDate(dateString) {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('tr-TR').format(date);
}

// Tablo Filtreleme
function filterTable(inputId, tableId) {
    const input = document.getElementById(inputId);
    const table = document.getElementById(tableId);
    const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');

    input.addEventListener('keyup', function() {
        const filter = input.value.toLowerCase();

        for (let i = 0; i < rows.length; i++) {
            const text = rows[i].textContent.toLowerCase();
            rows[i].style.display = text.includes(filter) ? '' : 'none';
        }
    });
}

// Onay/Red Dialog
function showApprovalDialog(prId, type) {
    const modal = document.createElement('div');
    modal.className = 'modal show';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>${type === 'approve' ? 'Onay' : 'Red'} Yorum</h3>
                <button class="close-btn" onclick="this.closest('.modal').remove()">×</button>
            </div>
            <div class="modal-body">
                <textarea id="approval-comment" placeholder="Yorum..." style="width: 100%; height: 100px; padding: 10px; border: 1px solid #bdc3c7; border-radius: 6px;"></textarea>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="this.closest('.modal').remove()">İptal</button>
                <button class="btn btn-${type === 'approve' ? 'success' : 'danger'}" 
                    onclick="${type === 'approve' ? 'approvePR(' + prId + ')' : 'rejectPR(' + prId + ')'}">
                    ${type === 'approve' ? 'Onayla' : 'Reddet'}
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
}

// Sayfa Yükleme Göstergesi
function showLoadingSpinner() {
    const spinner = document.createElement('div');
    spinner.id = 'loading-spinner';
    spinner.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 40px;
        border-radius: 8px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        z-index: 10000;
        text-align: center;
    `;
    spinner.innerHTML = '<div class="loading"></div><p>Yükleniyor...</p>';
    document.body.appendChild(spinner);
}

function hideLoadingSpinner() {
    const spinner = document.getElementById('loading-spinner');
    if (spinner) spinner.remove();
}

// Sayfa Hazırlandığında
document.addEventListener('DOMContentLoaded', function() {
    // Hata mesajlarını otomatik kapat
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.5s';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });

    // Enter basıldığında form gönder
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && !this.hasAttribute('data-no-submit')) {
                    form.submit();
                }
            });
        });
    });
});

// Export to CSV
function exportTableToCSV(tableId, filename = 'export.csv') {
    const table = document.getElementById(tableId);
    const csv = [];
    const rows = table.querySelectorAll('tr');

    rows.forEach(row => {
        const cols = row.querySelectorAll('td, th');
        const csvRow = [];
        cols.forEach(col => {
            csvRow.push('"' + col.textContent + '"');
        });
        csv.push(csvRow.join(','));
    });

    downloadCSV(csv.join('\n'), filename);
}

function downloadCSV(csv, filename) {
    const csvFile = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(csvFile);
    link.download = filename;
    link.click();
}

// Print
function printElement(elementId) {
    const element = document.getElementById(elementId);
    if (!element) return;

    const printWindow = window.open('', '', 'height=400,width=800');
    printWindow.document.write('<pre>' + element.innerHTML + '</pre>');
    printWindow.document.close();
    printWindow.print();
}
