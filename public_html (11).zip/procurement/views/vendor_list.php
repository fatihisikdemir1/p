<?php
/**
 * Tedarikçi Yönetimi Sayfası
 */

require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

$db = Database::getInstance();
$auth = Auth::getInstance();
$user = $auth->getCurrentUser();

// Tedarikçiler listesini al
$vendors = $db->select(
    "SELECT * FROM vendors WHERE is_active = 1 ORDER BY name"
);

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tedarikçiler - Satın Alma Sistemi</title>
    <link rel="stylesheet" href="<?php echo PROCUREMENT_PATH; ?>/assets/style.css">
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar">
        <div class="navbar-brand">Satın Alma Sistemi</div>
        <div class="user-menu">
            <span style="color: white;">Hoş geldiniz, <?php echo htmlspecialchars($user['full_name']); ?></span>
            <div class="user-avatar"><?php echo strtoupper(substr($user['full_name'], 0, 1)); ?></div>
            <a href="<?php echo PROCUREMENT_PATH; ?>/views/logout.php" style="color: white; text-decoration: none;">Çıkış</a>
        </div>
    </nav>

    <div class="d-flex" style="min-height: calc(100vh - 70px);">
        <!-- SIDEBAR -->
        <div style="width: 250px;">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li class="sidebar-section-title">Temel İşlemler</li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/views/dashboard.php">📊 Dashboard</a></li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/controllers/PurchaseRequestController.php?action=list">📋 Satın Alma İstekleri</a></li>
                    
                    <li class="sidebar-section-title">Yönetim</li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/views/vendor_list.php" class="active">🤝 Tedarikçiler</a></li>
                </ul>
            </div>
        </div>

        <!-- MAIN CONTENT -->
        <main class="main-content" style="flex: 1;">
            <div class="page-header">
                <h1 class="page-title">🤝 Tedarikçi Yönetimi</h1>
                <div class="page-actions">
                    <?php if ($auth->hasPermission('manage_vendors')): ?>
                    <button class="btn btn-primary" onclick="openModal('vendor-form-modal')">➕ Yeni Tedarikçi</button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- TABLO -->
            <div class="card">
                <div class="card-body">
                    <?php if (empty($vendors)): ?>
                    <div class="alert alert-info">ℹ️ Tedarikçi bulunmamaktadır.</div>
                    <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Kod</th>
                                <th>Adı</th>
                                <th>Email</th>
                                <th>Telefon</th>
                                <th>Şehir</th>
                                <th>Performans</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($vendors as $vendor): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($vendor['code']); ?></strong></td>
                                <td><?php echo htmlspecialchars($vendor['name']); ?></td>
                                <td><?php echo htmlspecialchars($vendor['email'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($vendor['phone'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($vendor['city'] ?? '-'); ?></td>
                                <td>
                                    <span class="badge" style="background-color: #f39c12; color: white;">
                                        ⭐ <?php echo $vendor['performance_score']; ?>/10
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary" onclick="viewVendor(<?php echo $vendor['id']; ?>)">👁️</button>
                                    <button class="btn btn-sm btn-secondary" onclick="editVendor(<?php echo $vendor['id']; ?>)">✏️</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>

            <!-- TEDARIKÇI FORMU -->
            <div id="vendor-form-modal" class="modal">
                <div class="modal-content" style="max-width: 700px;">
                    <div class="modal-header">
                        <h3>Yeni Tedarikçi</h3>
                        <button class="close-btn" onclick="closeModal('vendor-form-modal')">×</button>
                    </div>
                    <form method="POST" style="display:none;">
                        <div class="modal-body">
                            <div class="form-group">
                                <label class="required">Tedarikçi Adı</label>
                                <input type="text" required>
                            </div>
                            <div class="form-group">
                                <label class="required">Kod</label>
                                <input type="text" required placeholder="VENDOR001">
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email">
                            </div>
                            <div class="form-group">
                                <label>Telefon</label>
                                <input type="tel">
                            </div>
                            <div class="form-group">
                                <label>Şehir</label>
                                <input type="text">
                            </div>
                            <div class="alert alert-info">
                                ℹ️ Daha fazla alan için direktifler: 
                                <a href="#" style="color: #2874a6; text-decoration: underline;">Detaylı Form</a>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" onclick="closeModal('vendor-form-modal')">İptal</button>
                            <button type="submit" class="btn btn-success">💾 Kaydet</button>
                        </div>
                    </form>
                    <div class="modal-body" style="text-align: center; padding: 40px;">
                        <strong>Tedarikçi ekleme modülü yakında aktif hale getirilecektir.</strong><br><br>
                        Şimdilik, database'de el ile tedarikçi ekleyebilirsiniz.
                    </div>
                </div>
            </div>

        </main>
    </div>

    <script src="<?php echo PROCUREMENT_PATH; ?>/assets/script.js"></script>
</body>
</html>
