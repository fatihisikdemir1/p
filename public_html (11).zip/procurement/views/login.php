<?php
require_once __DIR__ . '/../includes/bootstrap.php';

if (is_logged_in()) {
    Utils::redirect(PROCUREMENT_URL . '/views/dashboard.php');
}

// Procurement ayrı login kullanmaz.
Utils::redirect('/login.php');
?>
