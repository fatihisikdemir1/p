<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

$auth = Auth::getInstance();
$user = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RFQ Detay - <?php echo htmlspecialchars($rfq['rfq_number']); ?></title>
  <link rel="stylesheet" href="<?php echo PROCUREMENT_URL; ?>/assets/style.css">
</head>
<body>
<nav class="navbar">
  <div class="navbar-brand">Satın Alma Sistemi</div>
  <div class="user-menu">
    <span style="color:white;">Hoş geldiniz, <?php echo htmlspecialchars($user['full_name']); ?></span>
    <div class="user-avatar"><?php echo strtoupper(substr($user['full_name'],0,1)); ?></div>
    <a href="<?php echo PROCUREMENT_URL; ?>/views/logout.php" style="color:white;text-decoration:none;">Çıkış</a>
  </div>
</nav>

<div class="d-flex" style="min-height: calc(100vh - 70px);">
  <div style="width:250px;">
    <div class="sidebar">
      <ul class="sidebar-menu">
        <li class="sidebar-section-title">Temel</li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/views/dashboard.php">📊 Dashboard</a></li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/controllers/PurchaseRequestController.php?action=list">📋 PR</a></li>
        <li><a class="active" href="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=list">📮 RFQ</a></li>
      </ul>
    </div>
  </div>

  <main class="main-content" style="flex:1;">
    <div class="page-header">
      <h1 class="page-title">📮 <?php echo htmlspecialchars($rfq['rfq_number']); ?></h1>
      <div class="page-actions">
        <a class="btn btn-secondary" href="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=list">← Liste</a>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
        <div class="d-flex" style="justify-content:space-between;gap:12px;flex-wrap:wrap;">
          <div>
            <div class="text-muted">PR</div>
            <div><strong><?php echo htmlspecialchars($rfq['pr_number'] ?? '-'); ?></strong> — <?php echo htmlspecialchars($rfq['pr_title'] ?? '-'); ?></div>
          </div>
          <div>
            <div class="text-muted">Durum</div>
            <div><span class="badge <?php echo Utils::getStatusClass($rfq['status']); ?>"><?php echo htmlspecialchars($rfq['status']); ?></span></div>
          </div>
          <div>
            <div class="text-muted">Teklif Son Tarih</div>
            <div><?php echo htmlspecialchars($rfq['due_date'] ?? '-'); ?></div>
          </div>
        </div>

        <?php if ($auth->hasPermission('create_rfq') && $rfq['status'] === 'created'): ?>
          <hr class="my-3">
          <form method="POST" action="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=send&id=<?php echo (int)$rfq['id']; ?>">
            <div class="d-flex" style="gap:10px;align-items:center;flex-wrap:wrap;">
              <select class="form-control" name="sent_via" style="max-width:220px;">
                <option value="email">E-posta</option>
                <option value="portal">Portal</option>
                <option value="manual">Manuel</option>
              </select>
              <button class="btn btn-primary" type="submit">RFQ Gönderildi İşaretle</button>
              <div class="text-muted">Gönderim loglanır (sent_at).</div>
            </div>
          </form>
        <?php endif; ?>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-header">Tedarikçiler</div>
      <div class="card-body">
        <?php if (empty($vendors)): ?>
          <div class="alert alert-info">Tedarikçi yok.</div>
        <?php else: ?>
          <table class="table">
            <thead><tr><th>Kod</th><th>Ad</th><th>Durum</th><th>Gönderim</th></tr></thead>
            <tbody>
            <?php foreach ($vendors as $v): ?>
              <tr>
                <td><strong><?php echo htmlspecialchars($v['code']); ?></strong></td>
                <td><?php echo htmlspecialchars($v['name']); ?></td>
                <td><span class="badge"><?php echo htmlspecialchars($v['status']); ?></span></td>
                <td><?php echo htmlspecialchars($v['sent_at'] ?? '-'); ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-header">Teklifler</div>
      <div class="card-body">
        <?php if (empty($quotes)): ?>
          <div class="alert alert-info">Henüz teklif girilmedi.</div>
        <?php else: ?>
          <table class="table">
            <thead><tr><th>Tedarikçi</th><th>Toplam</th><th>Para</th><th>Vade</th><th>Teslim</th><th>Durum</th><th></th></tr></thead>
            <tbody>
              <?php foreach ($quotes as $q): ?>
                <tr>
                  <td><strong><?php echo htmlspecialchars($q['vendor_code']); ?></strong> — <?php echo htmlspecialchars($q['vendor_name']); ?></td>
                  <td><?php echo htmlspecialchars($q['total_amount']); ?></td>
                  <td><?php echo htmlspecialchars($q['currency']); ?></td>
                  <td><?php echo htmlspecialchars($q['payment_terms'] ?? '-'); ?></td>
                  <td><?php echo htmlspecialchars($q['delivery_terms'] ?? '-'); ?></td>
                  <td><span class="badge"><?php echo htmlspecialchars($q['status']); ?></span></td>
                  <td>
                    <?php if ($auth->hasPermission('create_rfq') && $rfq['status'] === 'quoted'): ?>
                      <form method="POST" action="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=select&id=<?php echo (int)$rfq['id']; ?>" style="display:inline;">
                        <input type="hidden" name="quote_id" value="<?php echo (int)$q['id']; ?>">
                        <button class="btn btn-sm btn-success" type="submit">Kazanan Seç</button>
                      </form>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>

    <?php if ($auth->hasPermission('create_rfq')): ?>
      <div class="card">
        <div class="card-header">Teklif Gir / Güncelle</div>
        <div class="card-body">
          <form method="POST" action="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=submitQuote&id=<?php echo (int)$rfq['id']; ?>">
            <div class="row" style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">
              <div class="form-group">
                <label class="required">Tedarikçi</label>
                <select class="form-control" name="vendor_id" required>
                  <option value="">Seçiniz</option>
                  <?php foreach ($vendors as $v): ?>
                    <option value="<?php echo (int)$v['vendor_id']; ?>"><?php echo htmlspecialchars($v['code'].' - '.$v['name']); ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="form-group">
                <label>Para Birimi</label>
                <select class="form-control" name="currency">
                  <option>TRY</option><option>USD</option><option>EUR</option>
                </select>
              </div>
              <div class="form-group">
                <label>Lead Time (gün)</label>
                <input class="form-control" name="lead_time_days" type="number" min="0">
              </div>
            </div>

            <div class="row" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
              <div class="form-group">
                <label>Ödeme Vadesi</label>
                <input class="form-control" name="payment_terms" placeholder="Örn: 30 gün">
              </div>
              <div class="form-group">
                <label>Teslim Şartı</label>
                <input class="form-control" name="delivery_terms" placeholder="Örn: 7 gün / EXW / CIF">
              </div>
            </div>

            <hr class="my-3">
            <div class="text-muted" style="margin-bottom:8px;">Satırlar (en az 1 satır qty>0 olmalı)</div>

            <?php for ($i=0;$i<5;$i++): ?>
              <div class="row" style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:10px;margin-bottom:8px;">
                <input class="form-control" name="line_desc[]" placeholder="Açıklama">
                <input class="form-control" name="line_qty[]" type="number" step="0.01" placeholder="Qty">
                <input class="form-control" name="line_price[]" type="number" step="0.01" placeholder="Birim Fiyat">
                <input class="form-control" name="line_tax[]" type="number" step="0.01" placeholder="KDV %" value="20">
              </div>
            <?php endfor; ?>

            <button class="btn btn-primary" type="submit">Teklifi Kaydet</button>
            <div class="text-muted" style="margin-top:8px;">Kaydedince RFQ status otomatik “quoted” olur (en az 1 teklif varsa).</div>
          </form>
        </div>
      </div>
    <?php endif; ?>

  </main>
</div>
</body>
</html>
