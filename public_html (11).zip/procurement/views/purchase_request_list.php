<?php
/**
 * Satın Alma İstekleri Liste Sayfası
 */

require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

$service = new PurchaseRequestService();
$auth = Auth::getInstance();
$user = $auth->getCurrentUser();

// Filtreleme ve sayfalama
$page = intval($_GET['page'] ?? 1);
$status = $_GET['status'] ?? null;
$search = $_GET['search'] ?? null;
$itemsPerPage = 20;

$filters = [];

// Rol'e göre filtrele
if ($auth->hasRole('requester')) {
    $filters['requester_id'] = $user['id'];
} elseif ($auth->hasRole('approver')) {
    $filters['department_id'] = $user['department_id'];
}

if ($status) $filters['status'] = $status;
if ($search) $filters['search'] = $search;

$prs = $service->listPurchaseRequests($filters, $itemsPerPage, ($page - 1) * $itemsPerPage);

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Satın Alma İstekleri - Satın Alma Sistemi</title>
    <link rel="stylesheet" href="<?php echo PROCUREMENT_PATH; ?>/assets/style.css">
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar">
        <div class="navbar-brand">Satın Alma Sistemi</div>
        <div class="user-menu">
            <span style="color: white;">Hoş geldiniz, <?php echo htmlspecialchars($user['full_name']); ?></span>
            <div class="user-avatar"><?php echo strtoupper(substr($user['full_name'], 0, 1)); ?></div>
            <a href="<?php echo PROCUREMENT_PATH; ?>/views/logout.php" style="color: white; text-decoration: none;">Çıkış</a>
        </div>
    </nav>

    <div class="d-flex" style="min-height: calc(100vh - 70px);">
        <!-- SIDEBAR -->
        <div style="width: 250px;">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li class="sidebar-section-title">Temel İşlemler</li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/views/dashboard.php">📊 Dashboard</a></li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/controllers/PurchaseRequestController.php?action=list" class="active">📋 Satın Alma İstekleri</a></li>
                </ul>
            </div>
        </div>

        <!-- MAIN CONTENT -->
        <main class="main-content" style="flex: 1;">
            <div class="page-header">
                <h1 class="page-title">📋 Satın Alma İstekleri</h1>
                <div class="page-actions">
                    <?php if ($auth->hasPermission('create_pr')): ?>
                    <a href="<?php echo PROCUREMENT_PATH; ?>/controllers/PurchaseRequestController.php?action=create" class="btn btn-primary">➕ Yeni İstek</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- FILTRELEME -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="d-flex gap-2" style="gap: 10px;">
                        <input type="hidden" name="action" value="list">
                        <input type="text" name="search" placeholder="PR Numarası veya başlık ara..." value="<?php echo htmlspecialchars($search); ?>">
                        <select name="status">
                            <option value="">Tüm Durumlar</option>
                            <option value="draft" <?php echo $status === 'draft' ? 'selected' : ''; ?>>Taslak</option>
                            <option value="submitted" <?php echo $status === 'submitted' ? 'selected' : ''; ?>>Gönderildi</option>
                            <option value="approved" <?php echo $status === 'approved' ? 'selected' : ''; ?>>Onaylandı</option>
                            <option value="rejected" <?php echo $status === 'rejected' ? 'selected' : ''; ?>>Reddedildi</option>
                            <option value="cancelled" <?php echo $status === 'cancelled' ? 'selected' : ''; ?>>İptal</option>
                        </select>
                        <button type="submit" class="btn btn-primary">🔍 Filtrele</button>
                    </form>
                </div>
            </div>

            <!-- TABLO -->
            <div class="card">
                <div class="card-body">
                    <?php if (empty($prs)): ?>
                    <div class="alert alert-info" style="background-color: #d6eaf8; border-color: #3498db; color: #2874a6;">
                        ℹ️ İçsel göstermek için satın alma bulunmamaktadır.
                    </div>
                    <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>PR Numarası</th>
                                <th>Başlık</th>
                                <th>İstek Sahibi</th>
                                <th>Departman</th>
                                <th>Oncelik</th>
                                <th>Durum</th>
                                <th>Tarih</th>
                                <th>İşlem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($prs as $pr): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($pr['pr_number']); ?></strong></td>
                                <td><?php echo htmlspecialchars($pr['title']); ?></td>
                                <td><?php echo htmlspecialchars($pr['requester_name'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($pr['department_name'] ?? '-'); ?></td>
                                <td>
                                    <?php 
                                    $priorityLabels = [
                                        'low' => 'Düşük',
                                        'medium' => 'Orta',
                                        'high' => 'Yüksek',
                                        'urgent' => 'Acil'
                                    ];
                                    $priorityClasses = [
                                        'low' => 'badge-secondary',
                                        'medium' => 'badge-info',
                                        'high' => 'badge-warning',
                                        'urgent' => 'badge-danger'
                                    ];
                                    ?>
                                    <span class="badge <?php echo $priorityClasses[$pr['priority']] ?? 'badge-light'; ?>">
                                        <?php echo $priorityLabels[$pr['priority']] ?? '-'; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge <?php echo Utils::getStatusClass($pr['status']); ?>">
                                        <?php echo Utils::getStatusLabel('purchase_request', $pr['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo Utils::formatDate($pr['created_at']); ?></td>
                                <td>
                                    <a href="<?php echo PROCUREMENT_PATH; ?>/controllers/PurchaseRequestController.php?action=view&id=<?php echo $pr['id']; ?>" class="btn btn-sm btn-primary">👁️ İncele</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>

        </main>
    </div>

    <script src="<?php echo PROCUREMENT_PATH; ?>/assets/script.js"></script>
</body>
</html>
