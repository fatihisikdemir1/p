<?php require_once __DIR__ . '/../includes/bootstrap.php'; require_login(); $user = Auth::getInstance()->getCurrentUser(); ?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayarlar - Satın Alma Sistemi</title>
    <link rel="stylesheet" href="<?php echo PROCUREMENT_PATH; ?>/assets/style.css">
</head>
<body>
    <nav class="navbar"><div class="navbar-brand">Satın Alma Sistemi</div><div class="user-menu"><span style="color: white;">Hoş geldiniz, <?php echo htmlspecialchars($user['full_name']); ?></span><a href="<?php echo PROCUREMENT_PATH; ?>/views/logout.php" style="color: white; text-decoration: none;">Çıkış</a></div></nav>
    <div class="d-flex" style="min-height: calc(100vh - 70px);"><div style="width: 250px;"><div class="sidebar"><ul class="sidebar-menu"><li class="sidebar-section-title">Admin</li><li><a href="<?php echo PROCUREMENT_PATH; ?>/views/settings.php" class="active">⚙️ Ayarlar</a></li></ul></div></div><main class="main-content" style="flex: 1;"><div style="text-align: center; padding: 60px 20px;"><div style="font-size: 80px; margin-bottom: 20px;">⚙️</div><h1 style="color: #2c3e50;">Sistem Ayarları</h1><p style="color: #7f8c8d; font-size: 16px; margin-bottom: 30px;">Admin paneli yakında aktif hale getirilecektir!</p><a href="<?php echo PROCUREMENT_PATH; ?>/views/dashboard.php" class="btn btn-primary">← Geri Dön</a></div></main></div>
    <script src="<?php echo PROCUREMENT_PATH; ?>/assets/script.js"></script>
</body>
</html>
