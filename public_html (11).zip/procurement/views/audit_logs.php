<?php require_once __DIR__ . '/../includes/bootstrap.php'; require_login(); require_role('admin'); $user = Auth::getInstance()->getCurrentUser(); $db = Database::getInstance(); $logs = $db->select("SELECT al.*, u.full_name FROM audit_logs al LEFT JOIN users u ON al.user_id = u.id ORDER BY al.created_at DESC LIMIT 100"); ?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Logları - Satın Alma Sistemi</title>
    <link rel="stylesheet" href="<?php echo PROCUREMENT_PATH; ?>/assets/style.css">
</head>
<body>
    <nav class="navbar"><div class="navbar-brand">Satın Alma Sistemi</div><div class="user-menu"><span style="color: white;">Hoş geldiniz, <?php echo htmlspecialchars($user['full_name']); ?></span><a href="<?php echo PROCUREMENT_PATH; ?>/views/logout.php" style="color: white; text-decoration: none;">Çıkış</a></div></nav>
    <div class="d-flex" style="min-height: calc(100vh - 70px);"><div style="width: 250px;"><div class="sidebar"><ul class="sidebar-menu"><li class="sidebar-section-title">Admin</li><li><a href="<?php echo PROCUREMENT_PATH; ?>/views/audit_logs.php" class="active">📋 Audit Logları</a></li></ul></div></div><main class="main-content" style="flex: 1;"><div class="page-header"><h1 class="page-title">📋 Sistem Audit Logları</h1></div><div class="card"><div class="card-body"><table class="table"><thead><tr><th>Tarih/Saat</th><th>Kullanıcı</th><th>İşlem</th><th>Varlık</th><th>Açıklama</th><th>IP</th></tr></thead><tbody><?php foreach ($logs as $log): ?><tr><td><?php echo Utils::formatDateTime($log['created_at']); ?></td><td><?php echo htmlspecialchars($log['full_name'] ?? 'Sistem'); ?></td><td><span class="badge badge-info" style="background-color: #3498db;"><?php echo htmlspecialchars($log['action']); ?></span></td><td><?php echo htmlspecialchars($log['entity_type']); ?> #<?php echo htmlspecialchars($log['entity_id']); ?></td><td><?php echo htmlspecialchars($log['description'] ?? '-'); ?></td><td style="font-size: 12px;"><?php echo htmlspecialchars($log['ip_address'] ?? '-'); ?></td></tr><?php endforeach; ?></tbody></table></div></div></main></div>
    <script src="<?php echo PROCUREMENT_PATH; ?>/assets/script.js"></script>
</body>
</html>
