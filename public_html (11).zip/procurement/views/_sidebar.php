<?php
require_once __DIR__ . '/../includes/bootstrap.php';

$auth = Auth::getInstance();
$path = $_SERVER['REQUEST_URI'] ?? '';

function activeMenu($needle, $path){
    return (strpos($path, $needle) !== false) ? 'active' : '';
}
?>
<div class="sidebar">
  <ul class="sidebar-menu">
    <li class="sidebar-section-title">Modüller</li>
<li><a href="/dashboard.php">🧩 Uygulama (Görev/Proje)</a></li>
<li><a href="/finance/dashboard.php">📈 Finans</a></li>
<li><a href="/credit/dashboard.php">🏦 Kredi Takip</a></li>
<li class="sidebar-section-title">Satınalma</li>

    <li>
      <a class="<?php echo activeMenu('/views/dashboard.php', $path); ?>"
         href="<?php echo PROCUREMENT_URL; ?>/views/dashboard.php">📊 Dashboard</a>
    </li>

    <li>
      <a class="<?php echo activeMenu('PurchaseRequestController.php', $path); ?>"
         href="<?php echo PROCUREMENT_URL; ?>/controllers/PurchaseRequestController.php?action=list">📋 PR (Talepler)</a>
    </li>

    <li>
      <a class="<?php echo activeMenu('RfqController.php', $path); ?>"
         href="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=list">📮 RFQ / Teklif</a>
    </li>

    <li>
      <a class="<?php echo activeMenu('PoController.php', $path); ?>"
         href="<?php echo PROCUREMENT_URL; ?>/controllers/PoController.php?action=list">📦 PO (Sipariş)</a>
    </li>

    <li>
      <a class="<?php echo activeMenu('GrnController.php', $path); ?>"
         href="<?php echo PROCUREMENT_URL; ?>/controllers/GrnController.php?action=list">✅ GRN (Mal Kabul)</a>
    </li>

    <li>
      <a class="<?php echo activeMenu('InvoiceController.php', $path); ?>"
         href="<?php echo PROCUREMENT_URL; ?>/controllers/InvoiceController.php?action=list">💰 Fatura & 3-Way</a>
    </li>

    <li class="sidebar-section-title">Yönetim</li>
    <li><a href="<?php echo PROCUREMENT_URL; ?>/views/vendor_list.php">🤝 Tedarikçiler</a></li>
    <li><a href="<?php echo PROCUREMENT_URL; ?>/views/items_list.php">📦 Ürün/Hizmet Kataloğu</a></li>

    <?php if ($auth->hasRole('admin')): ?>
      <li class="sidebar-section-title">Admin</li>
      <li><a href="<?php echo PROCUREMENT_URL; ?>/views/settings.php">⚙️ Ayarlar</a></li>
      <li><a href="<?php echo PROCUREMENT_URL; ?>/views/users.php">👥 Kullanıcılar</a></li>
      <li><a href="<?php echo PROCUREMENT_URL; ?>/views/audit_logs.php">📋 Audit Logları</a></li>
    <?php endif; ?>
  </ul>
</div>
