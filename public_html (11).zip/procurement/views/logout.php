<?php
/**
 * Çıkış Sayfası
 */

require_once __DIR__ . '/../includes/bootstrap.php';

if ($auth->isLoggedIn()) {
    $auth->logout();
}

/**
 *  ◀ Geri dön
 */
header("Location: " . PROCUREMENT_PATH . "/views/login.php");
exit;
?>
