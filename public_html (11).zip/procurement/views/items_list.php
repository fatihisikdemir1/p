<?php
/**
 * Ürün/Hizmet Kataloğu Sayfası
 */

require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

$db = Database::getInstance();
$auth = Auth::getInstance();
$user = $auth->getCurrentUser();

// Ürünleri al
$items = $db->select(
    "SELECT * FROM items WHERE is_active = 1 ORDER BY category, name"
);

// Kategorileri grupla
$categorized = [];
foreach ($items as $item) {
    $cat = $item['category'] ?? 'Diğer';
    if (!isset($categorized[$cat])) {
        $categorized[$cat] = [];
    }
    $categorized[$cat][] = $item;
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ürün Kataloğu - Satın Alma Sistemi</title>
    <link rel="stylesheet" href="<?php echo PROCUREMENT_PATH; ?>/assets/style.css">
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar">
        <div class="navbar-brand">Satın Alma Sistemi</div>
        <div class="user-menu">
            <span style="color: white;">Hoş geldiniz, <?php echo htmlspecialchars($user['full_name']); ?></span>
            <div class="user-avatar"><?php echo strtoupper(substr($user['full_name'], 0, 1)); ?></div>
            <a href="<?php echo PROCUREMENT_PATH; ?>/views/logout.php" style="color: white; text-decoration: none;">Çıkış</a>
        </div>
    </nav>

    <div class="d-flex" style="min-height: calc(100vh - 70px);">
        <!-- SIDEBAR -->
        <div style="width: 250px;">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li class="sidebar-section-title">Temel İşlemler</li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/views/dashboard.php">📊 Dashboard</a></li>
                    
                    <li class="sidebar-section-title">Yönetim</li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/views/items_list.php" class="active">📦 Ürün Kataloğu</a></li>
                </ul>
            </div>
        </div>

        <!-- MAIN CONTENT -->
        <main class="main-content" style="flex: 1;">
            <div class="page-header">
                <h1 class="page-title">📦 Ürün ve Hizmet Kataloğu</h1>
            </div>

            <!-- KATEGORİLER -->
            <?php foreach ($categorized as $category => $items): ?>
            <div class="card mb-4">
                <div class="card-header">
                    📂 <?php echo htmlspecialchars($category); ?> (<?php echo count($items); ?> ürün)
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Kod</th>
                                <th>Adı</th>
                                <th>Birim</th>
                                <th>Standart Fiyat</th>
                                <th>Min Stok</th>
                                <th>Max Stok</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($item['code']); ?></strong></td>
                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                <td><?php echo htmlspecialchars($item['unit_of_measure'] ?? '-'); ?></td>
                                <td><?php echo Utils::formatCurrency($item['standard_price'] ?? 0); ?></td>
                                <td><?php echo $item['min_stock'] ?? 0; ?></td>
                                <td><?php echo $item['max_stock'] ?? 0; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endforeach; ?>

            <?php if (empty($items)): ?>
            <div class="card">
                <div class="card-body">
                    <div class="alert alert-info">ℹ️ Katalogda ürün bulunmamaktadır.</div>
                </div>
            </div>
            <?php endif; ?>

        </main>
    </div>

    <script src="<?php echo PROCUREMENT_PATH; ?>/assets/script.js"></script>
</body>
</html>
