<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

$auth = Auth::getInstance();
$user = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PO Detay - <?php echo htmlspecialchars($po['po_number']); ?></title>
  <link rel="stylesheet" href="<?php echo PROCUREMENT_URL; ?>/assets/style.css">
</head>
<body>
<nav class="navbar">
  <div class="navbar-brand">Satın Alma Sistemi</div>
  <div class="user-menu">
    <span style="color:white;"><?php echo htmlspecialchars($user['full_name']); ?></span>
    <div class="user-avatar"><?php echo strtoupper(substr($user['full_name'],0,1)); ?></div>
    <a href="<?php echo PROCUREMENT_URL; ?>/views/logout.php" style="color:white;text-decoration:none;">Çıkış</a>
  </div>
</nav>

<div class="d-flex" style="min-height: calc(100vh - 70px);">
  <div style="width:250px;">
    <div class="sidebar">
      <ul class="sidebar-menu">
        <li class="sidebar-section-title">Temel</li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/views/dashboard.php">📊 Dashboard</a></li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/controllers/PoController.php?action=list" class="active">📦 PO</a></li>
      </ul>
    </div>
  </div>

  <main class="main-content" style="flex:1;">
    <div class="page-header">
      <h1 class="page-title">📦 <?php echo htmlspecialchars($po['po_number']); ?></h1>
      <div class="page-actions">
        <a class="btn btn-secondary" href="<?php echo PROCUREMENT_URL; ?>/controllers/PoController.php?action=list">← Liste</a>

        <?php if ($auth->hasPermission('approve') && $po['status']==='created'): ?>
          <a class="btn btn-warning" href="<?php echo PROCUREMENT_URL; ?>/controllers/PoController.php?action=approve&id=<?php echo (int)$po['id']; ?>">Onayla</a>
        <?php endif; ?>

        <?php if ($auth->hasPermission('create_rfq') && $po['status']==='approved'): ?>
          <a class="btn btn-primary" href="<?php echo PROCUREMENT_URL; ?>/controllers/PoController.php?action=send&id=<?php echo (int)$po['id']; ?>">Gönderildi İşaretle</a>
        <?php endif; ?>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
        <div class="d-flex" style="justify-content:space-between;gap:12px;flex-wrap:wrap;">
          <div>
            <div class="text-muted">Tedarikçi</div>
            <div><strong><?php echo htmlspecialchars(($po['vendor_code'] ?? '').' - '.($po['vendor_name'] ?? '')); ?></strong></div>
            <div class="text-muted"><?php echo htmlspecialchars($po['vendor_email'] ?? ''); ?></div>
          </div>
          <div>
            <div class="text-muted">Durum</div>
            <div><span class="badge <?php echo Utils::getStatusClass($po['status']); ?>"><?php echo htmlspecialchars($po['status']); ?></span></div>
          </div>
          <div>
            <div class="text-muted">Toplam</div>
            <div><strong><?php echo htmlspecialchars($po['total_amount']); ?> <?php echo htmlspecialchars($po['currency']); ?></strong></div>
          </div>
        </div>

        <?php if (!empty($po['notes'])): ?>
          <hr class="my-3">
          <div class="text-muted">Not</div>
          <div><?php echo nl2br(htmlspecialchars($po['notes'])); ?></div>
        <?php endif; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-header">Sipariş Satırları</div>
      <div class="card-body">
        <?php if (empty($lines)): ?>
          <div class="alert alert-info">Satır yok.</div>
        <?php else: ?>
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Açıklama</th>
                <th>Miktar</th>
                <th>Birim Fiyat</th>
                <th>KDV%</th>
                <th>Toplam</th>
                <th>Alınan</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($lines as $l): ?>
                <tr>
                  <td><?php echo (int)$l['line_number']; ?></td>
                  <td><?php echo htmlspecialchars($l['description']); ?></td>
                  <td><?php echo htmlspecialchars($l['qty']); ?></td>
                  <td><?php echo htmlspecialchars($l['unit_price']); ?></td>
                  <td><?php echo htmlspecialchars($l['tax_rate']); ?></td>
                  <td><strong><?php echo htmlspecialchars($l['line_total']); ?></strong> <?php echo htmlspecialchars($l['currency']); ?></td>
                  <td><?php echo htmlspecialchars($l['received_qty']); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>

  </main>
</div>
</body>
</html>
