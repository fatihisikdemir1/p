<?php
/**
 * Dashboard - Satın Alma Sistemi Ana Sayfası
 */
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

$auth = Auth::getInstance();
$db   = Database::getInstance();
$user = $auth->getCurrentUser();

/** aktif menu helper */
$path = $_SERVER['REQUEST_URI'] ?? '';
function activeMenu($needle, $path){
    return (strpos($path, $needle) !== false) ? 'active' : '';
}

/**
 * KPI verilerini al (tablo yoksa 0)
 * Not: PR stateleri: draft, submitted, approved, rejected, cancelled
 */
$stats = [
    'total_pr'        => Utils::safeCount('purchase_requests'),
    'approved_pr'     => Utils::safeCount('purchase_requests', "WHERE status = 'approved'"),
    'pending_pr'      => Utils::safeCount('purchase_requests', "WHERE status = 'submitted'"),
    'total_rfq'       => Utils::safeCount('rfqs'),
    'total_po'        => Utils::safeCount('purchase_orders'),
    'total_invoice'   => Utils::safeCount('invoices'),
    'pending_payment' => Utils::safeCount('invoices', "WHERE payment_status IN ('unpaid', 'partial')"),
];

/** Bekleyen onaylar */
$pending_approvals = [];
if (Utils::tableExists('approvals') && Utils::tableExists('purchase_requests')) {
    $pending_approvals = $db->select(
        "SELECT a.*, pr.pr_number, pr.title
         FROM approvals a
         LEFT JOIN purchase_requests pr ON a.entity_id = pr.id
         WHERE a.entity_type = 'purchase_request'
           AND a.status = 'pending'
           AND a.approver_id = ?
         ORDER BY a.created_at DESC
         LIMIT 10",
        [(int)$user['id']]
    );
}

/** Son PR'ler */
$recent_prs = [];
if (Utils::tableExists('purchase_requests')) {
    // users tablosunda bazen "name" bazen "full_name" olur → ikisini de destekle
    $recent_prs = $db->select(
        "SELECT pr.*,
                COALESCE(u.full_name, u.name, u.username, u.email) AS requester_name,
                d.name as department_name
         FROM purchase_requests pr
         LEFT JOIN users u ON pr.requester_id = u.id
         LEFT JOIN departments d ON pr.department_id = d.id
         ORDER BY pr.created_at DESC
         LIMIT 5"
    );
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Satın Alma Sistemi - Dashboard</title>
    <link rel="stylesheet" href="<?php echo PROCUREMENT_URL; ?>/assets/style.css">
</head>
<body>
<nav class="navbar">
    <div class="navbar-brand">Satın Alma Sistemi</div>
    <div class="user-menu">
        <span style="color: white;">Hoş geldiniz, <?php echo htmlspecialchars($user['full_name']); ?></span>
        <div class="user-avatar"><?php echo strtoupper(substr($user['full_name'], 0, 1)); ?></div>
        <a href="<?php echo PROCUREMENT_URL; ?>/views/logout.php" style="color: white; text-decoration: none;">Çıkış</a>
    </div>
</nav>

<div class="d-flex" style="min-height: calc(100vh - 70px);">
    <div style="width: 250px;">
        <div class="sidebar">
            <ul class="sidebar-menu">
                <li class="sidebar-section-title">Temel</li>

                <li>
                    <a class="<?php echo activeMenu('/views/dashboard.php', $path); ?>"
                       href="<?php echo PROCUREMENT_URL; ?>/views/dashboard.php">📊 Dashboard</a>
                </li>

                <li>
                    <a class="<?php echo activeMenu('PurchaseRequestController.php', $path); ?>"
                       href="<?php echo PROCUREMENT_URL; ?>/controllers/PurchaseRequestController.php?action=list">📋 PR (Talepler)</a>
                </li>

                <li>
                    <a class="<?php echo activeMenu('RfqController.php', $path); ?>"
                       href="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=list">📮 RFQ / Teklif</a>
                </li>

                <li>
                    <a class="<?php echo activeMenu('PoController.php', $path); ?>"
                       href="<?php echo PROCUREMENT_URL; ?>/controllers/PoController.php?action=list">📦 PO (Sipariş)</a>
                </li>

                <li>
                    <a class="<?php echo activeMenu('GrnController.php', $path); ?>"
                       href="<?php echo PROCUREMENT_URL; ?>/controllers/GrnController.php?action=list">✅ GRN (Mal Kabul)</a>
                </li>

                <li>
                    <a class="<?php echo activeMenu('InvoiceController.php', $path); ?>"
                       href="<?php echo PROCUREMENT_URL; ?>/controllers/InvoiceController.php?action=list">💰 Fatura & 3-Way</a>
                </li>

                <li class="sidebar-section-title">Yönetim</li>
                <li><a href="<?php echo PROCUREMENT_URL; ?>/views/vendor_list.php">🤝 Tedarikçiler</a></li>
                <li><a href="<?php echo PROCUREMENT_URL; ?>/views/items_list.php">📦 Ürün/Hizmet Kataloğu</a></li>

                <?php if ($auth->hasRole('admin')): ?>
                    <li class="sidebar-section-title">Admin</li>
                    <li><a href="<?php echo PROCUREMENT_URL; ?>/views/settings.php">⚙️ Ayarlar</a></li>
                    <li><a href="<?php echo PROCUREMENT_URL; ?>/views/users.php">👥 Kullanıcılar</a></li>
                    <li><a href="<?php echo PROCUREMENT_URL; ?>/views/audit_logs.php">📋 Audit Logları</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <main class="main-content" style="flex: 1;">
        <div class="page-header">
            <h1 class="page-title">📊 Dashboard</h1>
        </div>

        <div class="dashboard-grid">
            <div class="stat-card primary">
                <div class="stat-icon">📋</div>
                <div class="stat-number"><?php echo (int)$stats['total_pr']; ?></div>
                <div class="stat-label">Toplam PR</div>
            </div>

            <div class="stat-card success">
                <div class="stat-icon">✓</div>
                <div class="stat-number"><?php echo (int)$stats['approved_pr']; ?></div>
                <div class="stat-label">Onaylı PR</div>
            </div>

            <div class="stat-card warning">
                <div class="stat-icon">⏳</div>
                <div class="stat-number"><?php echo (int)$stats['pending_pr']; ?></div>
                <div class="stat-label">Bekleyen PR</div>
            </div>

            <div class="stat-card primary">
                <div class="stat-icon">📮</div>
                <div class="stat-number"><?php echo (int)$stats['total_rfq']; ?></div>
                <div class="stat-label">RFQ</div>
            </div>

            <div class="stat-card primary">
                <div class="stat-icon">📦</div>
                <div class="stat-number"><?php echo (int)$stats['total_po']; ?></div>
                <div class="stat-label">PO</div>
            </div>

            <div class="stat-card success">
                <div class="stat-icon">💰</div>
                <div class="stat-number"><?php echo (int)$stats['total_invoice']; ?></div>
                <div class="stat-label">Faturalar</div>
            </div>

            <div class="stat-card danger">
                <div class="stat-icon">⚠️</div>
                <div class="stat-number"><?php echo (int)$stats['pending_payment']; ?></div>
                <div class="stat-label">Ödeme Bekleyen</div>
            </div>
        </div>

        <?php if (!empty($pending_approvals)): ?>
            <div class="card mb-4">
                <div class="card-header">
                    ⏳ Sizden Onay Bekleyen PR (<?php echo count($pending_approvals); ?>)
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>PR</th>
                            <th>Başlık</th>
                            <th>Tarih</th>
                            <th>İşlem</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($pending_approvals as $approval): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($approval['pr_number'] ?? '-'); ?></strong></td>
                                <td><?php echo htmlspecialchars($approval['title'] ?? '-'); ?></td>
                                <td><?php echo Utils::formatDate($approval['created_at'] ?? null); ?></td>
                                <td>
                                    <a class="btn btn-sm btn-primary"
                                       href="<?php echo PROCUREMENT_URL; ?>/controllers/PurchaseRequestController.php?action=view&id=<?php echo (int)$approval['entity_id']; ?>">
                                        👁️ İncele
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">📋 Son PR'ler</div>
            <div class="card-body">
                <?php if (empty($recent_prs)): ?>
                    <div class="text-muted">Henüz kayıt yok.</div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                        <tr>
                            <th>PR</th>
                            <th>Başlık</th>
                            <th>İstek Sahibi</th>
                            <th>Departman</th>
                            <th>Durum</th>
                            <th>Tarih</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($recent_prs as $pr): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($pr['pr_number']); ?></strong></td>
                                <td><?php echo htmlspecialchars($pr['title']); ?></td>
                                <td><?php echo htmlspecialchars($pr['requester_name'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($pr['department_name'] ?? '-'); ?></td>
                                <td>
                                    <span class="badge <?php echo Utils::getStatusClass($pr['status']); ?>">
                                        <?php echo htmlspecialchars($pr['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo Utils::formatDate($pr['created_at']); ?></td>
                                <td>
                                    <a class="btn btn-sm btn-primary"
                                       href="<?php echo PROCUREMENT_URL; ?>/controllers/PurchaseRequestController.php?action=view&id=<?php echo (int)$pr['id']; ?>">
                                        👁️
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

    </main>
</div>
</body>
</html>
