<?php
/**
 * Satın Alma İsteği Detay Sayfası
 */

require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

$prId = intval($_GET['id'] ?? 0);
if (!$prId) {
    die("Geçersiz PR ID");
}

$service = new PurchaseRequestService();
$auth = Auth::getInstance();
$user = $auth->getCurrentUser();
$logger = Logger::getInstance();

// PR'yi al
$pr = $service->getPurchaseRequestById($prId);
if (!$pr) {
    http_response_code(404);
    die("PR bulunamadı");
}

// Erişim kontrolü
if (!$auth->hasRole('admin') && $pr['requester_id'] != $user['id'] && $pr['department_id'] != $user['department_id']) {
    http_response_code(403);
    die("Yetkiniz yok");
}

$lines = $service->getPRLines($prId);
$total = $service->calculatePRTotal($prId);
$auditLogs = $logger->getAuditLogs('purchase_request', $prId);

// Onay bilgilerini al
$approvals = $auth->getCurrentUser()['pdo']->query(
    "SELECT * FROM approvals 
     WHERE entity_type = 'purchase_request' AND entity_id = ?",
    [$prId]
);

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PR Detay - Satın Alma Sistemi</title>
    <link rel="stylesheet" href="<?php echo PROCUREMENT_PATH; ?>/assets/style.css">
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar">
        <div class="navbar-brand">Satın Alma Sistemi</div>
        <div class="user-menu">
            <span style="color: white;">Hoş geldiniz, <?php echo htmlspecialchars($user['full_name']); ?></span>
            <div class="user-avatar"><?php echo strtoupper(substr($user['full_name'], 0, 1)); ?></div>
            <a href="<?php echo PROCUREMENT_PATH; ?>/views/logout.php" style="color: white; text-decoration: none;">Çıkış</a>
        </div>
    </nav>

    <div class="d-flex" style="min-height: calc(100vh - 70px);">
        <!-- SIDEBAR -->
        <div style="width: 250px;">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li class="sidebar-section-title">Temel İşlemler</li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/views/dashboard.php">📊 Dashboard</a></li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/controllers/PurchaseRequestController.php?action=list">📋 Satın Alma İstekleri</a></li>
                </ul>
            </div>
        </div>

        <!-- MAIN CONTENT -->
        <main class="main-content" style="flex: 1;">
            <div class="page-header">
                <div>
                    <h1 class="page-title"><?php echo htmlspecialchars($pr['pr_number']); ?></h1>
                    <p style="color: #7f8c8d; margin-top: 5px;">
                        <span class="badge <?php echo Utils::getStatusClass($pr['status']); ?>">
                            <?php echo Utils::getStatusLabel('purchase_request', $pr['status']); ?>
                        </span>
                    </p>
                </div>
                <div class="page-actions">
                    <?php if ($pr['status'] === 'draft' && $auth->hasPermission('edit')): ?>
                    <a href="<?php echo PROCUREMENT_PATH; ?>/controllers/PurchaseRequestController.php?action=edit&id=<?php echo $pr['id']; ?>" class="btn btn-primary">✏️ Düzenle</a>
                    <?php endif; ?>
                    <?php if ($pr['status'] === 'draft'): ?>
                    <a href="javascript:submitPR(<?php echo $pr['id']; ?>)" class="btn btn-success">📤 Gönder</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- DETAY KARTLARI -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <!-- SOL TARAF -->
                <div class="card">
                    <div class="card-header">📋 İstek Detayları</div>
                    <div class="card-body">
                        <div style="margin-bottom: 15px;">
                            <strong style="display: block; color: #7f8c8d; font-size: 12px; text-transform: uppercase;">Başlık</strong>
                            <p><?php echo htmlspecialchars($pr['title']); ?></p>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <strong style="display: block; color: #7f8c8d; font-size: 12px; text-transform: uppercase;">Açıklama</strong>
                            <p><?php echo htmlspecialchars($pr['description'] ?? '-'); ?></p>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <strong style="display: block; color: #7f8c8d; font-size: 12px; text-transform: uppercase;">Gerekçe</strong>
                            <p><?php echo htmlspecialchars($pr['justification'] ?? '-'); ?></p>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <strong style="display: block; color: #7f8c8d; font-size: 12px; text-transform: uppercase;">İstek Sahibi</strong>
                            <p><?php echo htmlspecialchars($pr['requester_name'] ?? '-'); ?></p>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <strong style="display: block; color: #7f8c8d; font-size: 12px; text-transform: uppercase;">Departman</strong>
                            <p><?php echo htmlspecialchars($pr['department_name'] ?? '-'); ?></p>
                        </div>
                    </div>
                </div>

                <!-- SAĞ TARAF -->
                <div class="card">
                    <div class="card-header">💰 Finansal Detaylar</div>
                    <div class="card-body">
                        <div style="margin-bottom: 15px;">
                            <strong style="display: block; color: #7f8c8d; font-size: 12px; text-transform: uppercase;">Tahmini Tutar</strong>
                            <p style="font-size: 18px; font-weight: bold; color: #27ae60;">
                                <?php echo Utils::formatCurrency($pr['estimated_amount'], $pr['currency']); ?>
                            </p>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <strong style="display: block; color: #7f8c8d; font-size: 12px; text-transform: uppercase;">Gerçek Toplam</strong>
                            <p style="font-size: 18px; font-weight: bold;">
                                <?php echo Utils::formatCurrency($total, $pr['currency']); ?>
                            </p>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <strong style="display: block; color: #7f8c8d; font-size: 12px; text-transform: uppercase;">Bütçe Kodu</strong>
                            <p><?php echo htmlspecialchars($pr['budget_code'] ?? '-'); ?></p>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <strong style="display: block; color: #7f8c8d; font-size: 12px; text-transform: uppercase;">Gerekli Tarih</strong>
                            <p><?php echo Utils::formatDate($pr['required_date'] ?? '-'); ?></p>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <strong style="display: block; color: #7f8c8d; font-size: 12px; text-transform: uppercase;">Öncelik</strong>
                            <p>
                                <?php 
                                $priorityLabels = ['low' => 'Düşük', 'medium' => 'Orta', 'high' => 'Yüksek', 'urgent' => 'Acil'];
                                echo htmlspecialchars($priorityLabels[$pr['priority']] ?? '-');
                                ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- SATIR DETAYLARI -->
            <div class="card mb-4">
                <div class="card-header">📦 İstek Satırları</div>
                <div class="card-body">
                    <?php if (empty($lines)): ?>
                    <div class="alert alert-warning">⚠️ Bu istekte satır bulunmamaktadır.</div>
                    <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Sıra</th>
                                <th>Açıklama</th>
                                <th>Ürün</th>
                                <th>Miktar</th>
                                <th>Birim Fiyat</th>
                                <th>Vergi</th>
                                <th>Toplam</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($lines as $line): ?>
                            <tr>
                                <td><?php echo $line['line_number']; ?></td>
                                <td><?php echo htmlspecialchars($line['description'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($line['item_name'] ?? '-'); ?></td>
                                <td><?php echo $line['quantity'] . ' ' . $line['unit_of_measure']; ?></td>
                                <td><?php echo Utils::formatCurrency($line['unit_price'], $line['currency']); ?></td>
                                <td><?php echo $line['tax_rate']; ?>%</td>
                                <td><strong><?php echo Utils::formatCurrency($line['line_total'], $line['currency']); ?></strong></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr style="background-color: #ecf0f1; font-weight: bold;">
                                <td colspan="6" style="text-align: right;">TOPLAM:</td>
                                <td><?php echo Utils::formatCurrency($total, $pr['currency']); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                    <?php endif; ?>
                </div>
            </div>

            <!-- ONAY TİMLİNESİ -->
            <?php if (!empty($auditLogs)): ?>
            <div class="card">
                <div class="card-header">📅 Etkinlik Geçmişi</div>
                <div class="card-body">
                    <div class="timeline">
                        <?php foreach ($auditLogs as $log): ?>
                        <div class="timeline-item <?php echo strpos($log['action'], 'approved') !== false ? 'success' : ''; ?>">
                            <div class="timeline-content">
                                <div class="timeline-date"><?php echo Utils::formatDateTime($log['created_at']); ?></div>
                                <div class="timeline-title">
                                    <?php 
                                    $actionLabels = [
                                        'CREATE' => 'İstek Oluşturuldu',
                                        'UPDATE' => 'İstek Güncellendi',
                                        'STATUS_CHANGE' => 'Durum Değişimi',
                                        'APPROVAL' => 'Onay',
                                        'DELETE' => 'Silindi',
                                    ];
                                    echo htmlspecialchars($actionLabels[$log['action']] ?? $log['action']);
                                    ?>
                                </div>
                                <div class="timeline-description">
                                    <strong><?php echo htmlspecialchars($log['full_name'] ?? 'Sistem'); ?></strong>
                                    <?php if ($log['description']): ?>
                                    <br><?php echo htmlspecialchars($log['description']); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

        </main>
    </div>

    <script src="<?php echo PROCUREMENT_PATH; ?>/assets/script.js"></script>
</body>
</html>
