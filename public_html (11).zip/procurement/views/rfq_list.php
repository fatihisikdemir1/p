<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

$auth = Auth::getInstance();
$db   = Database::getInstance();
$user = $auth->getCurrentUser();

$status = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';

?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RFQ / Teklifler - Satın Alma</title>
  <link rel="stylesheet" href="<?php echo PROCUREMENT_URL; ?>/assets/style.css">
</head>
<body>
<nav class="navbar">
  <div class="navbar-brand">Satın Alma Sistemi</div>
  <div class="user-menu">
    <span style="color:white;">Hoş geldiniz, <?php echo htmlspecialchars($user['full_name']); ?></span>
    <div class="user-avatar"><?php echo strtoupper(substr($user['full_name'],0,1)); ?></div>
    <a href="<?php echo PROCUREMENT_URL; ?>/views/logout.php" style="color:white;text-decoration:none;">Çıkış</a>
  </div>
</nav>

<div class="d-flex" style="min-height: calc(100vh - 70px);">
  <div style="width:250px;">
    <div class="sidebar">
      <ul class="sidebar-menu">
        <li class="sidebar-section-title">Temel</li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/views/dashboard.php">📊 Dashboard</a></li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/controllers/PurchaseRequestController.php?action=list">📋 Satın Alma İstekleri</a></li>
        <li><a class="active" href="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=list">📮 RFQ / Teklifler</a></li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/views/po_list.php">📦 PO</a></li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/views/grn_list.php">✅ GRN</a></li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/views/invoice_list.php">💰 Faturalar</a></li>
      </ul>
    </div>
  </div>

  <main class="main-content" style="flex:1;">
    <div class="page-header">
      <h1 class="page-title">📮 RFQ / Teklifler</h1>
      <div class="page-actions">
        <?php if ($auth->hasPermission('create_rfq')): ?>
          <a class="btn btn-primary" href="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=create">➕ Yeni RFQ</a>
        <?php endif; ?>
      </div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
        <form method="GET" action="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php" class="d-flex" style="gap:10px;align-items:center;">
          <input type="hidden" name="action" value="list">
          <input class="form-control" style="max-width:260px;" name="search" placeholder="Ara: RFQ no / PR no / başlık" value="<?php echo htmlspecialchars($search); ?>">
          <select class="form-control" style="max-width:220px;" name="status">
            <option value="">Tümü</option>
            <?php foreach (['created','sent','quoted','selected','closed'] as $st): ?>
              <option value="<?php echo $st; ?>" <?php echo ($status===$st?'selected':''); ?>><?php echo $st; ?></option>
            <?php endforeach; ?>
          </select>
          <button class="btn btn-secondary" type="submit">Filtrele</button>
        </form>
      </div>
    </div>

    <?php if (!empty($error ?? null)): ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if (($_GET['action'] ?? '') === 'create' && $auth->hasPermission('create_rfq')): ?>
      <?php
        $approvedPRs = $approvedPRs ?? $db->select("SELECT id, pr_number, title FROM purchase_requests WHERE status='approved' ORDER BY id DESC LIMIT 100");
        $vendorList  = $vendorList ?? $db->select("SELECT id, code, name FROM vendors WHERE is_active=1 ORDER BY name");
      ?>
      <div class="card mb-4">
        <div class="card-header">➕ Yeni RFQ Oluştur</div>
        <div class="card-body">
          <form method="POST" action="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=create">
            <div class="row" style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
              <div class="form-group">
                <label class="required">Onaylı PR</label>
                <select name="pr_id" class="form-control" required>
                  <option value="">Seçiniz</option>
                  <?php foreach ($approvedPRs as $pr): ?>
                    <option value="<?php echo (int)$pr['id']; ?>">
                      <?php echo htmlspecialchars($pr['pr_number'].' - '.$pr['title']); ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="form-group">
                <label>Teklif Son Tarih</label>
                <input type="date" name="due_date" class="form-control">
              </div>
            </div>

            <div class="form-group">
              <label class="required">Tedarikçiler</label>
              <div class="card" style="border:1px solid #eee;">
                <div class="card-body" style="max-height:180px;overflow:auto;">
                  <?php foreach ($vendorList as $v): ?>
                    <label style="display:flex;gap:8px;align-items:center;margin-bottom:6px;">
                      <input type="checkbox" name="vendor_ids[]" value="<?php echo (int)$v['id']; ?>">
                      <span><strong><?php echo htmlspecialchars($v['code']); ?></strong> — <?php echo htmlspecialchars($v['name']); ?></span>
                    </label>
                  <?php endforeach; ?>
                </div>
              </div>
              <div class="text-muted" style="margin-top:6px;">En az 1 tedarikçi seç.</div>
            </div>

            <div class="form-group">
              <label>Not</label>
              <textarea name="notes" class="form-control" rows="3"></textarea>
            </div>

            <button class="btn btn-primary" type="submit">RFQ Oluştur</button>
          </form>
        </div>
      </div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header">RFQ Listesi</div>
      <div class="card-body">
        <?php if (empty($rfqs ?? [])): ?>
          <div class="alert alert-info">RFQ bulunamadı.</div>
        <?php else: ?>
          <table class="table">
            <thead>
              <tr>
                <th>RFQ</th>
                <th>PR</th>
                <th>Başlık</th>
                <th>Durum</th>
                <th>Tarih</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rfqs as $r): ?>
                <tr>
                  <td><strong><?php echo htmlspecialchars($r['rfq_number']); ?></strong></td>
                  <td><?php echo htmlspecialchars($r['pr_number'] ?? '-'); ?></td>
                  <td><?php echo htmlspecialchars($r['pr_title'] ?? '-'); ?></td>
                  <td><span class="badge <?php echo Utils::getStatusClass($r['status']); ?>"><?php echo htmlspecialchars($r['status']); ?></span></td>
                  <td><?php echo Utils::formatDate($r['created_at']); ?></td>
                  <td>
                    <a class="btn btn-sm btn-primary" href="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=view&id=<?php echo (int)$r['id']; ?>">👁️</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>

  </main>
</div>

<script src="<?php echo PROCUREMENT_URL; ?>/assets/script.js"></script>
</body>
</html>
