<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();

$auth = Auth::getInstance();
$user = $auth->getCurrentUser();

$status = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PO Listesi</title>
  <link rel="stylesheet" href="<?php echo PROCUREMENT_URL; ?>/assets/style.css">
</head>
<body>
<nav class="navbar">
  <div class="navbar-brand">Satın Alma Sistemi</div>
  <div class="user-menu">
    <span style="color:white;"><?php echo htmlspecialchars($user['full_name']); ?></span>
    <div class="user-avatar"><?php echo strtoupper(substr($user['full_name'],0,1)); ?></div>
    <a href="<?php echo PROCUREMENT_URL; ?>/views/logout.php" style="color:white;text-decoration:none;">Çıkış</a>
  </div>
</nav>

<div class="d-flex" style="min-height: calc(100vh - 70px);">
  <div style="width:250px;">
    <div class="sidebar">
      <ul class="sidebar-menu">
        <li class="sidebar-section-title">Temel</li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/views/dashboard.php">📊 Dashboard</a></li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/controllers/PurchaseRequestController.php?action=list">📋 PR</a></li>
        <li><a href="<?php echo PROCUREMENT_URL; ?>/controllers/RfqController.php?action=list">📮 RFQ</a></li>
        <li><a class="active" href="<?php echo PROCUREMENT_URL; ?>/controllers/PoController.php?action=list">📦 PO</a></li>
      </ul>
    </div>
  </div>

  <main class="main-content" style="flex:1;">
    <div class="page-header">
      <h1 class="page-title">📦 Satınalma Siparişleri (PO)</h1>
      <div class="page-actions"></div>
    </div>

    <div class="card mb-3">
      <div class="card-body">
        <form method="GET" action="<?php echo PROCUREMENT_URL; ?>/controllers/PoController.php" class="d-flex" style="gap:10px;align-items:center;">
          <input type="hidden" name="action" value="list">
          <input class="form-control" style="max-width:280px;" name="search" placeholder="Ara: PO no / tedarikçi" value="<?php echo htmlspecialchars($search); ?>">
          <select class="form-control" style="max-width:220px;" name="status">
            <option value="">Tümü</option>
            <?php foreach (['created','approved','sent','partially_received','received','closed','cancelled'] as $st): ?>
              <option value="<?php echo $st; ?>" <?php echo ($status===$st?'selected':''); ?>><?php echo $st; ?></option>
            <?php endforeach; ?>
          </select>
          <button class="btn btn-secondary" type="submit">Filtrele</button>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-header">PO Listesi</div>
      <div class="card-body">
        <?php if (empty($pos ?? [])): ?>
          <div class="alert alert-info">PO bulunamadı.</div>
        <?php else: ?>
          <table class="table">
            <thead>
              <tr>
                <th>PO</th>
                <th>Tedarikçi</th>
                <th>Toplam</th>
                <th>Para</th>
                <th>Durum</th>
                <th>Tarih</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($pos as $po): ?>
                <tr>
                  <td><strong><?php echo htmlspecialchars($po['po_number']); ?></strong></td>
                  <td><?php echo htmlspecialchars(($po['vendor_code'] ?? '').' - '.($po['vendor_name'] ?? '')); ?></td>
                  <td><?php echo htmlspecialchars($po['total_amount']); ?></td>
                  <td><?php echo htmlspecialchars($po['currency']); ?></td>
                  <td><span class="badge <?php echo Utils::getStatusClass($po['status']); ?>"><?php echo htmlspecialchars($po['status']); ?></span></td>
                  <td><?php echo Utils::formatDate($po['created_at']); ?></td>
                  <td>
                    <a class="btn btn-sm btn-primary" href="<?php echo PROCUREMENT_URL; ?>/controllers/PoController.php?action=view&id=<?php echo (int)$po['id']; ?>">👁️</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>

  </main>
</div>
</body>
</html>
