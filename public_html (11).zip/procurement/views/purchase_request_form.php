<?php
/**
 * Satın Alma İsteği Form Sayfası (Yeni/Düzenle)
 */

require_once __DIR__ . '/../includes/bootstrap.php';
require_permission('create_pr');

$db = Database::getInstance();
$auth = Auth::getInstance();
$user = $auth->getCurrentUser();

$prId = intval($_GET['id'] ?? 0);
$pr = null;
$lines = [];
$isEdit = false;

if ($prId) {
    $service = new PurchaseRequestService();
    $pr = $service->getPurchaseRequestById($prId);
    if (!$pr) {
        die("PR bulunamadı");
    }
    $lines = $service->getPRLines($prId);
    $isEdit = true;
}

// Departmanları al
$departments = $db->select("SELECT * FROM departments WHERE is_active = 1");

// Ürünleri al
$items = $db->select("SELECT * FROM items WHERE is_active = 1 ORDER BY name");

$error = $_GET['error'] ?? '';

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $isEdit ? 'Düzenle' : 'Yeni'; ?> - Satın Alma İsteği</title>
    <link rel="stylesheet" href="<?php echo PROCUREMENT_PATH; ?>/assets/style.css">
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar">
        <div class="navbar-brand">Satın Alma Sistemi</div>
        <div class="user-menu">
            <span style="color: white;">Hoş geldiniz, <?php echo htmlspecialchars($user['full_name']); ?></span>
            <div class="user-avatar"><?php echo strtoupper(substr($user['full_name'], 0, 1)); ?></div>
            <a href="<?php echo PROCUREMENT_PATH; ?>/views/logout.php" style="color: white; text-decoration: none;">Çıkış</a>
        </div>
    </nav>

    <div class="d-flex" style="min-height: calc(100vh - 70px);">
        <!-- SIDEBAR -->
        <div style="width: 250px;">
            <div class="sidebar">
                <ul class="sidebar-menu">
                    <li class="sidebar-section-title">Temel İşlemler</li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/views/dashboard.php">📊 Dashboard</a></li>
                    <li><a href="<?php echo PROCUREMENT_PATH; ?>/controllers/PurchaseRequestController.php?action=list">📋 Satın Alma İstekleri</a></li>
                </ul>
            </div>
        </div>

        <!-- MAIN CONTENT -->
        <main class="main-content" style="flex: 1;">
            <div class="page-header">
                <h1 class="page-title"><?php echo $isEdit ? '✏️ İsteği Düzenle' : '➕ Yeni İstek Oluştur'; ?></h1>
            </div>

            <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo PROCUREMENT_PATH; ?>/controllers/PurchaseRequestController.php?action=<?php echo $isEdit ? 'edit' : 'create'; ?>&id=<?php echo $prId; ?>" id="pr-form">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                    <!-- SOL TARAF -->
                    <div class="card">
                        <div class="card-header">📋 Genel Bilgiler</div>
                        <div class="card-body">
                            <div class="form-group">
                                <label class="required">Başlık</label>
                                <input type="text" name="title" required value="<?php echo htmlspecialchars($pr['title'] ?? ''); ?>">
                            </div>

                            <div class="form-group">
                                <label>Açıklama</label>
                                <textarea name="description" style="min-height: 100px;"><?php echo htmlspecialchars($pr['description'] ?? ''); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label>Gerekçe</label>
                                <textarea name="justification" style="min-height: 100px;"><?php echo htmlspecialchars($pr['justification'] ?? ''); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label class="required">Departman</label>
                                <select name="department_id" required>
                                    <option value="">-- Seç --</option>
                                    <?php foreach ($departments as $dept): ?>
                                    <option value="<?php echo $dept['id']; ?>" <?php echo ($pr['department_id'] ?? $user['department_id']) == $dept['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($dept['name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- SAĞ TARAF -->
                    <div class="card">
                        <div class="card-header">💰 Finansal Bilgiler</div>
                        <div class="card-body">
                            <div class="form-group">
                                <label class="required">Tahmini Tutar</label>
                                <input type="number" name="estimated_amount" step="0.01" required value="<?php echo $pr['estimated_amount'] ?? 0; ?>">
                            </div>

                            <div class="form-group">
                                <label>Bütçe Kodu</label>
                                <input type="text" name="budget_code" value="<?php echo htmlspecialchars($pr['budget_code'] ?? ''); ?>">
                            </div>

                            <div class="form-group">
                                <label class="required">Gerekli Tarih</label>
                                <input type="date" name="required_date" required value="<?php echo $pr['required_date'] ?? ''; ?>">
                            </div>

                            <div class="form-group">
                                <label class="required">Öncelik</label>
                                <select name="priority" required>
                                    <option value="low" <?php echo ($pr['priority'] ?? 'medium') === 'low' ? 'selected' : ''; ?>>Düşük</option>
                                    <option value="medium" <?php echo ($pr['priority'] ?? 'medium') === 'medium' ? 'selected' : ''; ?>>Orta</option>
                                    <option value="high" <?php echo ($pr['priority'] ?? 'medium') === 'high' ? 'selected' : ''; ?>>Yüksek</option>
                                    <option value="urgent" <?php echo ($pr['priority'] ?? 'medium') === 'urgent' ? 'selected' : ''; ?>>Acil</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- SATIR DETAYLARI -->
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span>📦 İstek Satırları</span>
                            <button type="button" class="btn btn-sm btn-success" onclick="addLine()">➕ Satır Ekle</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="lines-container">
                            <?php if (!empty($lines)): ?>
                                <?php foreach ($lines as $index => $line): ?>
                                <div id="line-<?php echo $index; ?>" style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin-bottom: 15px;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                        <h4>Satır <?php echo $index + 1; ?></h4>
                                        <button type="button" class="btn btn-danger btn-sm" onclick="removeLine(<?php echo $index; ?>)">🗑️ Sil</button>
                                    </div>
                                    <div class="input-group">
                                        <textarea name="line_description[]" placeholder="Açıklama" style="flex: 1; min-height: 60px;"><?php echo htmlspecialchars($line['description'] ?? ''); ?></textarea>
                                    </div>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 10px;">
                                        <input type="number" name="line_quantity[]" placeholder="Miktar" step="0.01" value="<?php echo $line['quantity']; ?>" required>
                                        <input type="number" name="line_unit_price[]" placeholder="Birim Fiyat" step="0.01" value="<?php echo $line['unit_price']; ?>" required>
                                        <input type="text" name="line_unit_of_measure[]" placeholder="Birim" value="<?php echo htmlspecialchars($line['unit_of_measure'] ?? 'Adet'); ?>">
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div id="line-1" style="background: #f8f9fa; padding: 15px; border-radius: 6px; margin-bottom: 15px;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                        <h4>Satır 1</h4>
                                        <button type="button" class="btn btn-danger btn-sm" onclick="removeLine(1)">🗑️ Sil</button>
                                    </div>
                                    <div class="input-group">
                                        <textarea name="line_description[]" placeholder="Açıklama" style="flex: 1; min-height: 60px;"></textarea>
                                    </div>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 10px;">
                                        <input type="number" name="line_quantity[]" placeholder="Miktar" step="0.01" required>
                                        <input type="number" name="line_unit_price[]" placeholder="Birim Fiyat" step="0.01" required>
                                        <input type="text" name="line_unit_of_measure[]" placeholder="Birim" value="Adet">
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- BUTONLAR -->
                <div class="card" style="margin-top: 20px;">
                    <div class="card-body" style="display: flex; gap: 10px; justify-content: flex-end;">
                        <a href="<?php echo PROCUREMENT_PATH; ?>/controllers/PurchaseRequestController.php?action=list" class="btn btn-secondary">📩 İptal</a>
                        <button type="submit" class="btn btn-success">💾 Kaydet</button>
                        <?php if ($isEdit && $pr['status'] === 'draft'): ?>
                        <button type="button" class="btn btn-primary" onclick="submitPR(<?php echo $prId; ?>)">📤 Gönder</button>
                        <?php endif; ?>
                    </div>
                </div>
            </form>

        </main>
    </div>

    <script src="<?php echo PROCUREMENT_PATH; ?>/assets/script.js"></script>
    <script>
        let lineCount = <?php echo max(count($lines), 1); ?>;
    </script>
</body>
</html>
