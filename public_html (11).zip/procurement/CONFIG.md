# Satın Alma Sistemi - Yapılandırma

## Veritabanı Bağlantısı

Dosya: `procurement/includes/bootstrap.php` (14-19. satırlar)

```php
$host = getenv('DB_HOST') ?: 'localhost';
$dbname = getenv('DB_NAME') ?: 'u336896947_workflow';
$user = getenv('DB_USER') ?: 'u336896947_admin';
$pass = getenv('DB_PASS') ?: '147Fatih..';
```

### Kullanılan Krediler:
- **Host**: localhost
- **Veritabanı**: u336896947_workflow
- **Kullanıcı**: u336896947_admin
- **Şifre**: 147Fatih..

## Ortam Değişkenleri (Opsiyonel)

`.env` dosyası oluşturarak:

```
DB_HOST=localhost
DB_NAME=u336896947_workflow
DB_USER=u336896947_admin
DB_PASS=147Fatih..
SITE_URL=http://localhost
LOG_LEVEL=info
```

## Kurulum Sonrası

1. ✅ Veritabanı şeması yüklendi
2. ✅ Admin kullanıcısı oluşturuldu (admin/admin123)
3. ✅ Örnek tedarikçiler eklendi
4. ✅ Ürün kataloğu dolduruldu
5. ⏳ Rol ve izinler özelleştirilmesi

## Dosya İzinleri

```bash
chmod 755 procurement/
chmod 755 procurement/uploads/
chmod 644 procurement/assets/*
chmod 644 procurement/views/*
```

## Muhasebe Entegrasyonu Ayarları

Dosya: `procurement/includes/bootstrap.php` (sonuna ekle)

```php
// Optional: Accounting system integration
// define('ACCOUNTING_ENABLED', true);
// define('ACCOUNTING_SYSTEM', 'logo'); // logo, parasut, netsis
// define('ACCOUNTING_API_KEY', '...');
```

## Güvenlik Ayarları

### Session Timeout
Dosya: `procurement/includes/bootstrap.php`

```php
ini_set('session.gc_maxlifetime', 3600); // 1 saat
session_set_cookie_params(['lifetime' => 3600]);
```

### HTTPS (Üretimde)

```php
// Bootstrap'e ekle:
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}
```

## Loglama Seviyesi

Dosya: `procurement/includes/Logger.php`

```php
define('LOG_ERRORS', true);
define('LOG_LEVEL', 'info'); // debug, info, warning, error
```

## E-posta Bildirimleri (Hazırlık)

```php
define('MAIL_HOST', 'smtp.example.com');
define('MAIL_USER', 'notifications@example.com');
define('MAIL_PASS', 'password');
define('MAIL_FROM', 'procure@example.com');
```

## Cron Jobs (Hazırlık)

### Günlük Raporlar
```bash
0 9 * * * php /app/procurement/cron/daily_report.php
```

### Onayda Hatırlatma
```bash
0 10 * * MON-FRI php /app/procurement/cron/approval_reminder.php
```

### Ödeme Hatırlatması
```bash
0 8 * * * php /app/procurement/cron/payment_reminder.php
```

---

**Not**: Yapılandırma değişikliklerinden sonra tarayıcı cache'i temizleyin.
