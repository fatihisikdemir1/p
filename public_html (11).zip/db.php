<?php
declare(strict_types=1);

/**
 * Single DB include wrapper
 * - Existing project already uses /config/db.php
 * - Other pages call /db.php
 */
require __DIR__ . "/config/db.php";
