<?php
require "auth.php";
require "config/db.php";

$userId = $_SESSION["user"]["id"];

$stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM notifications 
    WHERE user_id = ? AND is_read = 0
");
$stmt->execute([$userId]);

echo (int)$stmt->fetchColumn();
