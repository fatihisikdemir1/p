<?php
require __DIR__ . "/auth.php";
require __DIR__ . "/db.php";

$taskId = (int)($_GET["id"] ?? 0);
$part   = (string)($_GET["part"] ?? "");

if ($taskId <= 0) { http_response_code(400); echo "<div class='text-danger'>Geçersiz task_id</div>"; exit; }

$userId = (int)($_SESSION["user"]["id"] ?? 0);
$role   = $_SESSION["user"]["role"] ?? "member";

/* member sadece kendi görevini görsün */
$params = [$taskId];
$cond   = "id=?";
if ($role === "member") {
  $cond .= " AND assigned_to=?";
  $params[] = $userId;
}
$st = $pdo->prepare("SELECT id FROM tasks WHERE $cond LIMIT 1");
$st->execute($params);
if (!$st->fetchColumn()) { http_response_code(403); echo "<div class='text-danger'>Yetkin yok</div>"; exit; }

function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8"); }

if ($part === "comments") {

  $comments = [];
  try {
    $cs = $pdo->prepare("
      SELECT c.*, u.name AS user_name, tu.name AS tagged_name
      FROM task_comments c
      LEFT JOIN users u ON u.id=c.user_id
      LEFT JOIN users tu ON tu.id=c.tagged_user_id
      WHERE c.task_id=?
      ORDER BY c.id DESC
      LIMIT 50
    ");
    $cs->execute([$taskId]);
    $comments = $cs->fetchAll(PDO::FETCH_ASSOC);
  } catch (Throwable $e) { $comments = []; }

  if (!$comments) {
    echo "<div class='td-muted'>Henüz mesaj yok.</div>";
    exit;
  }

  echo "<div class='d-flex flex-column gap-2'>";
  foreach ($comments as $c) {
    $name = e($c["user_name"] ?? "Kullanıcı");
    $time = e($c["created_at"] ?? "");
    $body = e($c["body"] ?? "");
    $tag  = $c["tagged_name"] ?? "";

    echo "<div class='cm-item'>
            <div class='cm-head'>
              <div class='cm-name'>{$name}";
    if ($tag) {
      echo " <span class='cm-tag'><i class='bi bi-at'></i>".e($tag)."</span>";
    }
    echo "    </div>
              <div class='cm-time'>{$time}</div>
            </div>
            <div class='cm-msg'>{$body}</div>
          </div>";
  }
  echo "</div>";
  exit;
}

if ($part === "files") {

  $files = [];
  try {
    $fs = $pdo->prepare("SELECT * FROM task_files WHERE task_id=? ORDER BY uploaded_at DESC");
    $fs->execute([$taskId]);
    $files = $fs->fetchAll(PDO::FETCH_ASSOC);
  } catch (Throwable $e) { $files = []; }

  if (!$files) {
    echo "<div class='td-muted'>Henüz dosya yok.</div>";
    exit;
  }

  echo "<div class='d-flex flex-column gap-2'>";
  foreach ($files as $f) {
    $url = $f["url"] ?? ("uploads/".($f["filename"] ?? ""));
    $on  = $f["original_name"] ?? ($f["filename"] ?? "dosya");
    $dt  = $f["uploaded_at"] ?? "";

    echo "<div class='td-fileitem'>
            <div class='td-fileleft'>
              <div class='td-fileicon'><i class='bi bi-file-earmark'></i></div>
              <div style='min-width:0'>
                <a class='td-filename text-decoration-none' target='_blank' href='".e($url)."'>".e($on)."</a>
                <div class='td-muted'>".e($dt)."</div>
              </div>
            </div>
            <div class='td-filemeta'><i class='bi bi-box-arrow-up-right'></i></div>
          </div>";
  }
  echo "</div>";
  exit;
}

http_response_code(400);
echo "<div class='text-danger'>Geçersiz part</div>";
