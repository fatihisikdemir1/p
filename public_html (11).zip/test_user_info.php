<?php
// Test sayfası - Kullanıcı bilgilerini kontrol et
declare(strict_types=1);
require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

echo "<h1>Kullanıcı Bilgileri Debug</h1>";
echo "<pre>";
echo "User ID: " . $userId . "\n";
echo "User Name: " . $userName . "\n";
echo "User Role: " . $userRole . "\n";
echo "Company ID: " . $companyId . "\n";
echo "Is Super Admin: " . (is_super_admin() ? 'YES' : 'NO') . "\n";
echo "</pre>";

// Firma bilgisi
if ($companyId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
    $stmt->execute([$companyId]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<h2>Firma Bilgisi:</h2>";
    echo "<pre>";
    print_r($company);
    echo "</pre>";
}

// Kullanıcı sayısı
$stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE company_id = ?");
$stmt->execute([$companyId]);
$userCount = $stmt->fetchColumn();

echo "<h2>Firma Kullanıcı Sayısı: " . $userCount . "</h2>";

// has_permission testi
echo "<h2>Yetkiler:</h2>";
echo "manage_users: " . (has_permission('manage_users') ? 'YES' : 'NO') . "<br>";
echo "view_all_tasks: " . (has_permission('view_all_tasks') ? 'YES' : 'NO') . "<br>";
?>