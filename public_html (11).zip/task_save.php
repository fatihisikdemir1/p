<?php
declare(strict_types=1);

ini_set('display_errors','0');
error_reporting(E_ALL);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

header("Content-Type: application/json; charset=utf-8");

if (($_SERVER["REQUEST_METHOD"] ?? "") !== "POST") {
  http_response_code(405);
  echo json_encode(["ok"=>false,"error"=>"Method not allowed"]);
  exit;
}

$taskId = (int)($_POST["task_id"] ?? 0);
if ($taskId <= 0) {
  echo json_encode(["ok"=>false,"error"=>"task_id eksik"]);
  exit;
}

if ($userRole === "user" || $userRole === "member") {
  http_response_code(403);
  echo json_encode(["ok"=>false,"error"=>"Yetkiniz yok"]);
  exit;
}

$title = trim((string)($_POST["title"] ?? ""));
$desc  = trim((string)($_POST["description"] ?? ""));
$status = trim((string)($_POST["status"] ?? "todo"));
$priority = trim((string)($_POST["priority"] ?? "medium"));
$assigned_to = (int)($_POST["assigned_to"] ?? 0);
$due_date = trim((string)($_POST["due_date"] ?? ""));

$allowedStatus = ["todo","doing","done"];
$allowedPri = ["low","medium","high","urgent"];
if (!in_array($status, $allowedStatus, true)) $status = "todo";
if (!in_array($priority, $allowedPri, true)) $priority = "medium";

try {
  $cols = [];
  $rs = $pdo->query("DESCRIBE tasks");
  foreach ($rs->fetchAll(PDO::FETCH_ASSOC) as $r) $cols[$r["Field"]] = true;

  $sets = [];
  $bind = [];

  if (isset($cols["title"]))       { $sets[]="title=:title"; $bind[":title"]=$title; }
  if (isset($cols["description"])) { $sets[]="description=:description"; $bind[":description"]=$desc; }
  if (isset($cols["status"]))      { $sets[]="status=:status"; $bind[":status"]=$status; }
  if (isset($cols["priority"]))    { $sets[]="priority=:priority"; $bind[":priority"]=$priority; }
  if (isset($cols["assigned_to"])) { $sets[]="assigned_to=:assigned_to"; $bind[":assigned_to"]=($assigned_to>0?$assigned_to:null); }
  if (isset($cols["due_date"]))    { $sets[]="due_date=:due_date"; $bind[":due_date"]=($due_date!==""?$due_date:null); }

  if (isset($cols["updated_at"]))  { $sets[]="updated_at=NOW()"; }

  if (!$sets) {
    echo json_encode(["ok"=>false,"error"=>"Tasks tablosunda güncellenecek kolon yok"]);
    exit;
  }

  $bind[":id"] = $taskId;

  $sql = "UPDATE tasks SET ".implode(", ", $sets)." WHERE id=:id LIMIT 1";
  $pdo->prepare($sql)->execute($bind);

  $status_label = ($status==="todo"?"Yapılacak":($status==="doing"?"Devam":"Tamam"));
  $priority_label = ($priority==="urgent"?"Acil":($priority==="high"?"Yüksek":($priority==="low"?"Düşük":"Orta")));

  echo json_encode([
    "ok"=>true,
    "status_label"=>$status_label,
    "priority_label"=>$priority_label,
    "task"=>[
      "id"=>$taskId,
      "status"=>$status,
      "priority"=>$priority
    ]
  ]);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(["ok"=>false,"error"=>"DB update hatası","detail"=>$e->getMessage()]);
}