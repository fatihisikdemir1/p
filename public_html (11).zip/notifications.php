<?php
require "auth.php";
require "config/db.php";

$userId = $_SESSION["user"]["id"];

// Okundu yap
if (isset($_GET["read"])) {
    $id = (int)$_GET["read"];
    $pdo->prepare("
        UPDATE notifications SET is_read = 1
        WHERE id = ? AND user_id = ?
    ")->execute([$id, $userId]);
    header("Location: notifications.php");
    exit;
}

// Bildirimleri çek
$stmt = $pdo->prepare("
    SELECT *
    FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$stmt->execute([$userId]);
$notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!doctype html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>İş Takibi</title>
<style>
.unread { background:#fff3cd; }
.read   { background:#f5f5f5; color:#777; }
.box {
    padding:10px;
    border:1px solid #ccc;
    margin-bottom:6px;
}
</style>
</head>
<body>

<?php require "menu.php"; ?>

<h2>🔔 Bildirimler</h2>

<?php if (!$notifications): ?>
<p>Bildirim yok.</p>
<?php endif; ?>

<?php foreach ($notifications as $n): ?>
<div class="box <?= $n['is_read'] ? 'read' : 'unread' ?>">
    <?= htmlspecialchars($n["message"]) ?><br>
    <small><?= $n["created_at"] ?></small><br>

    <?php if (!$n["is_read"]): ?>
        <a href="?read=<?= $n['id'] ?>">Okundu olarak işaretle</a>
    <?php endif; ?>
</div>
<?php endforeach; ?>

</body>
</html>
