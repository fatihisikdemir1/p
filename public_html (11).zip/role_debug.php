<?php
/**
 * DEBUG SCRIPT - Kullanıcı Rolü Kontrolü
 * KULLANDIKTAN SONRA SİLİN!
 */

// Error handling
ini_set('display_errors', '1');
error_reporting(E_ALL);

// Sadece auth.php yükle (o zaten rbac.php'yi yükler)
try {
  if (!file_exists(__DIR__ . "/auth.php")) {
    throw new Exception("auth.php bulunamadı!");
  }
  require_once __DIR__ . "/auth.php";

} catch (Exception $e) {
  die("
  <html>
  <head><title>Hata</title><style>body{font-family:monospace;padding:20px;background:#1e1e1e;color:#ff4444;}</style></head>
  <body>
    <h1>❌ Hata</h1>
    <p>" . htmlspecialchars($e->getMessage()) . "</p>
    <p><strong>Çözüm:</strong> auth.php dosyasının public_html klasöründe olduğundan emin olun</p>
  </body>
  </html>
  ");
}

header("Content-Type: text/html; charset=utf-8");

// Session kontrolü
if (!isset($_SESSION["user"]["id"])) {
  die("
  <html>
  <head><title>Giriş Yapın</title><style>body{font-family:monospace;padding:20px;background:#1e1e1e;color:#ffaa00;}</style></head>
  <body>
    <h1>⚠️ Giriş Yapmanız Gerekiyor</h1>
    <p><a href='login.php' style='color:#00ff00'>Buradan giriş yapın</a></p>
  </body>
  </html>
  ");
}

$userId = (int)$_SESSION["user"]["id"];
$userEmail = (string)$_SESSION["user"]["email"];
$userName = (string)$_SESSION["user"]["name"];
$rawRole = (string)$_SESSION["user"]["role"];
$normalizedRole = current_user_role();
$companyId = (int)($_SESSION["user"]["company_id"] ?? 0);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Role Debug - finansconnect.com</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { 
  font-family: 'Courier New', monospace; 
  padding: 20px; 
  background: #0a0e17; 
  color: #00ff41;
  line-height: 1.6;
}
.container {
  max-width: 1000px;
  margin: 0 auto;
}
.box {
  background: #1a1f2e;
  border: 2px solid #00ff41;
  padding: 25px;
  margin: 20px 0;
  border-radius: 12px;
  box-shadow: 0 0 20px rgba(0, 255, 65, 0.1);
}
h1 { 
  color: #00ff41; 
  font-size: 32px; 
  margin-bottom: 10px;
  text-shadow: 0 0 10px rgba(0, 255, 65, 0.3);
}
h2 { 
  color: #00ff41; 
  font-size: 22px; 
  margin-bottom: 15px;
  border-bottom: 2px solid #00ff41;
  padding-bottom: 10px;
}
h3 { 
  color: #ffa500; 
  font-size: 18px; 
  margin: 15px 0 10px 0;
}
.ok { color: #00ff41; font-weight: bold; }
.error { color: #ff4444; font-weight: bold; }
.warning { color: #ffa500; font-weight: bold; }
.info { color: #44aaff; }
table {
  width: 100%;
  border-collapse: collapse;
  margin: 15px 0;
  background: #0f1419;
}
th, td {
  border: 1px solid #2a3f5f;
  padding: 12px;
  text-align: left;
}
th {
  background: #1a2332;
  color: #00ff41;
  font-weight: bold;
}
tr:nth-child(even) {
  background: #0a0e17;
}
code {
  background: #0a0e17;
  padding: 3px 8px;
  border-radius: 4px;
  color: #ffa500;
  border: 1px solid #2a3f5f;
}
pre {
  background: #0a0e17;
  padding: 15px;
  border-radius: 8px;
  overflow-x: auto;
  color: #44aaff;
  border: 1px solid #2a3f5f;
  margin: 10px 0;
}
.big-status {
  font-size: 24px;
  font-weight: bold;
  padding: 25px;
  text-align: center;
  border-radius: 12px;
  margin: 20px 0;
  text-shadow: 0 0 10px currentColor;
}
.status-good {
  background: linear-gradient(135deg, #1a4d2e, #2d5f3e);
  border: 3px solid #00ff41;
  color: #00ff41;
}
.status-bad {
  background: linear-gradient(135deg, #4d1a1a, #5f2d2d);
  border: 3px solid #ff4444;
  color: #ff4444;
}
.sql-box {
  background: #0f1922;
  border: 2px solid #44aaff;
  padding: 20px;
  border-radius: 8px;
  margin: 15px 0;
}
.step-box {
  background: #1a2f1a;
  border-left: 4px solid #00ff41;
  padding: 15px;
  margin: 10px 0;
}
ol, ul {
  margin-left: 25px;
  margin-top: 10px;
}
li {
  margin: 8px 0;
}
a {
  color: #00ff41;
  text-decoration: none;
  border-bottom: 1px dotted #00ff41;
}
a:hover {
  color: #44ff88;
}
.badge {
  display: inline-block;
  padding: 4px 10px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: bold;
  margin-left: 10px;
}
.badge-admin {
  background: #00ff41;
  color: #0a0e17;
}
.badge-user {
  background: #ffa500;
  color: #0a0e17;
}
</style>
</head>
<body>

<div class="container">

<h1>🔍 Kullanıcı Rolü Debug Panel</h1>
<p style="color: #888; margin-bottom: 30px;">finansconnect.com - Role & Permission Checker</p>

<div class="box">
  <h2>👤 Kullanıcı Bilgileri</h2>
  <table>
    <tr>
      <th style="width:200px">Bilgi</th>
      <th>Değer</th>
    </tr>
    <tr>
      <td>Kullanıcı ID</td>
      <td><code><?= $userId ?></code></td>
    </tr>
    <tr>
      <td>İsim</td>
      <td><strong><?= htmlspecialchars($userName) ?></strong></td>
    </tr>
    <tr>
      <td>Email</td>
      <td><?= htmlspecialchars($userEmail) ?></td>
    </tr>
    <tr>
      <td>Company ID</td>
      <td><code><?= $companyId ?></code></td>
    </tr>
  </table>
</div>

<?php
$isSuper = ($normalizedRole === "super_admin");
$isCompanyAdmin = ($normalizedRole === "company_admin");
$isUser = ($normalizedRole === "user");

if ($isSuper): ?>
  <div class="big-status status-good">
    ✅ SÜPER ADMİN
    <div style="font-size: 16px; margin-top: 10px; opacity: 0.9;">
      Tüm menü öğelerini görebilirsiniz
    </div>
  </div>
<?php elseif ($isCompanyAdmin): ?>
  <div class="big-status status-good">
    ✅ COMPANY ADMIN
    <div style="font-size: 16px; margin-top: 10px; opacity: 0.9;">
      Projeler, Kullanıcılar, Görev Ekle menüleri görünmeli
    </div>
  </div>
<?php else: ?>
  <div class="big-status status-bad">
    ⚠️ USER ROLÜ
    <div style="font-size: 16px; margin-top: 10px; opacity: 0.9;">
      Sadece "Görevlerim" menüsünü görebilirsiniz
    </div>
  </div>
<?php endif; ?>

<div class="box">
  <h2>🎭 Rol Detayları</h2>
  <table>
    <tr>
      <th style="width:250px">Kontrol</th>
      <th>Sonuç</th>
    </tr>
    <tr>
      <td>Session'daki Ham Rol</td>
      <td><code><?= htmlspecialchars($rawRole) ?></code></td>
    </tr>
    <tr>
      <td><strong>Normalize Edilmiş Rol</strong></td>
      <td>
        <code class="<?= $isUser ? 'error' : 'ok' ?>"><?= htmlspecialchars($normalizedRole) ?></code>
        <?php if ($isSuper): ?>
          <span class="badge badge-admin">SUPER</span>
        <?php elseif ($isCompanyAdmin): ?>
          <span class="badge badge-admin">ADMIN</span>
        <?php else: ?>
          <span class="badge badge-user">USER</span>
        <?php endif; ?>
      </td>
    </tr>
    <tr>
      <td>is_super_admin()</td>
      <td class="<?= $isSuper ? 'ok' : 'error' ?>"><?= $isSuper ? '✓ TRUE' : '✗ FALSE' ?></td>
    </tr>
    <tr>
      <td>is_company_admin()</td>
      <td class="<?= is_company_admin() ? 'ok' : 'error' ?>"><?= is_company_admin() ? '✓ TRUE' : '✗ FALSE' ?></td>
    </tr>
    <tr>
      <td>is_user()</td>
      <td class="<?= $isUser ? 'warning' : 'ok' ?>"><?= $isUser ? '✓ TRUE' : '✗ FALSE' ?></td>
    </tr>
  </table>
</div>

<div class="box">
  <h2>📋 Menü Görünürlük Haritası</h2>
  <table>
    <tr>
      <th>Menü Öğesi</th>
      <th style="width: 120px;">Durum</th>
      <th>Koşul</th>
    </tr>
    <tr>
      <td><strong>Görevlerim</strong></td>
      <td class="ok">✓ Görünür</td>
      <td>Herkes</td>
    </tr>
    <tr style="<?= ($isSuper || $isCompanyAdmin) ? '' : 'opacity: 0.5;' ?>">
      <td><strong>Projeler</strong></td>
      <td class="<?= ($isSuper || $isCompanyAdmin) ? 'ok' : 'error' ?>">
        <?= ($isSuper || $isCompanyAdmin) ? '✓ Görünür' : '✗ Görünmez' ?>
      </td>
      <td>Admin veya Super Admin</td>
    </tr>
    <tr style="<?= ($isSuper || $isCompanyAdmin) ? '' : 'opacity: 0.5;' ?>">
      <td><strong>Proje Ekle</strong></td>
      <td class="<?= ($isSuper || $isCompanyAdmin) ? 'ok' : 'error' ?>">
        <?= ($isSuper || $isCompanyAdmin) ? '✓ Görünür' : '✗ Görünmez' ?>
      </td>
      <td>Admin veya Super Admin</td>
    </tr>
    <tr style="<?= ($isSuper || $isCompanyAdmin) ? '' : 'opacity: 0.5;' ?>">
      <td><strong>Kullanıcılar</strong></td>
      <td class="<?= ($isSuper || $isCompanyAdmin) ? 'ok' : 'error' ?>">
        <?= ($isSuper || $isCompanyAdmin) ? '✓ Görünür' : '✗ Görünmez' ?>
      </td>
      <td>Admin veya Super Admin</td>
    </tr>
    <tr style="<?= ($isSuper || $isCompanyAdmin) ? '' : 'opacity: 0.5;' ?>">
      <td><strong>Görev Ekle</strong></td>
      <td class="<?= ($isSuper || $isCompanyAdmin) ? 'ok' : 'error' ?>">
        <?= ($isSuper || $isCompanyAdmin) ? '✓ Görünür' : '✗ Görünmez' ?>
      </td>
      <td>Admin veya Super Admin</td>
    </tr>
    <tr style="<?= $isSuper ? '' : 'opacity: 0.5;' ?>">
      <td><strong>Firmalar</strong></td>
      <td class="<?= $isSuper ? 'ok' : 'error' ?>">
        <?= $isSuper ? '✓ Görünür' : '✗ Görünmez' ?>
      </td>
      <td>Sadece Super Admin</td>
    </tr>
    <tr style="<?= $isSuper ? '' : 'opacity: 0.5;' ?>">
      <td><strong>Firma Ekle</strong></td>
      <td class="<?= $isSuper ? 'ok' : 'error' ?>">
        <?= $isSuper ? '✓ Görünür' : '✗ Görünmez' ?>
      </td>
      <td>Sadece Super Admin</td>
    </tr>
  </table>
</div>

<?php if ($isUser): ?>
<div class="box" style="border-color: #ff4444;">
  <h2 style="color: #ff4444;">⚠️ SORUN TESPİT EDİLDİ</h2>
  <p style="font-size: 18px; margin-bottom: 20px;">
    <strong>Rolünüz "user" olduğu için menüde sadece "Görevlerim" görüyorsunuz!</strong>
  </p>
  
  <div class="step-box">
    <h3>🔧 ÇÖZÜM - Adım Adım</h3>
    
    <h3 style="margin-top: 20px;">Adım 1: phpMyAdmin'e Girin</h3>
    <p>cPanel veya hosting panelinden phpMyAdmin'i açın</p>
    
    <h3>Adım 2: SQL Sekmesine Tıklayın</h3>
    
    <h3>Adım 3: Bu Komutu Kopyalayıp Yapıştırın</h3>
    
    <div class="sql-box">
      <p class="info"><strong>Company Admin olmak için:</strong></p>
      <pre>UPDATE users 
SET role = 'company_admin'
WHERE id = <?= $userId ?>;</pre>
      
      <p class="info" style="margin-top: 20px;"><strong>Veya Super Admin olmak için:</strong></p>
      <pre>UPDATE users 
SET role = 'super_admin'
WHERE id = <?= $userId ?>;</pre>
    </div>
    
    <h3>Adım 4: "Go" veya "Çalıştır" Butonuna Tıklayın</h3>
    
    <h3>Adım 5: Başarılı Mesajını Görün</h3>
    <p class="ok">✓ "1 row affected" veya "Affected rows: 1" görmelisiniz</p>
    
    <h3>Adım 6: Logout + Login Yapın</h3>
    <ol>
      <li><a href="logout.php">Buradan çıkış yapın</a></li>
      <li>Tekrar giriş yapın</li>
      <li>Dashboard'a gidin</li>
      <li class="ok">✓ Menüde tüm öğeler görünecek!</li>
    </ol>
  </div>
</div>
<?php else: ?>
<div class="box" style="border-color: #00ff41;">
  <h2>✅ Rolünüz Uygun!</h2>
  <p style="font-size: 18px;">
    <strong>Menüde uygun öğeleri görmelisiniz.</strong>
  </p>
  
  <p style="margin-top: 20px;">Eğer menüde öğeler görünmüyorsa:</p>
  <ol>
    <li><a href="logout.php">Logout yapın</a></li>
    <li>Tekrar login olun</li>
    <li>Tarayıcı cache'ini temizleyin (Ctrl + Shift + Delete)</li>
    <li>Sayfayı hard refresh yapın (Ctrl + F5)</li>
  </ol>
</div>
<?php endif; ?>

<div class="box">
  <h2>🔍 Veritabanı Doğrulama</h2>
  <p>Veritabanınızda gerçek değeri görmek için bu sorguyu çalıştırın:</p>
  
  <pre>SELECT id, name, email, role, company_id 
FROM users 
WHERE id = <?= $userId ?>;</pre>
  
  <p class="info" style="margin-top: 15px;">
    Bu sorguyu phpMyAdmin SQL sekmesinde çalıştırın ve <code>role</code> sütununa bakın.
  </p>
</div>

<div class="box" style="background: #2a1f1f; border-color: #ff4444;">
  <h2 style="color: #ff4444;">🔒 GÜVENLİK UYARISI</h2>
  <p style="font-size: 18px; color: #ff4444;">
    <strong>Bu sayfayı kontrol ettikten sonra MUTLAKA SİLİN!</strong>
  </p>
  <p style="margin-top: 15px; color: #ffa500;">
    Dosya adı: <code style="color: #fff;">role_debug.php</code>
  </p>
  <p style="margin-top: 10px;">
    FTP veya File Manager ile <code>public_html/role_debug.php</code> dosyasını silin.
  </p>
</div>

<div style="text-align: center; margin: 40px 0; padding: 20px; color: #555; border-top: 1px solid #2a3f5f;">
  <p>finansconnect.com Role Debug Tool v2.0</p>
  <p>Son Güncelleme: 6 Şubat 2026</p>
</div>

</div>

</body>
</html>