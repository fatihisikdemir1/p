<?php require "auth.php"; ?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Muhasebe</title></head>
<body>

<?php require "menu.php"; ?>

<h2>Muhasebe</h2>
<p>Faturalar, fişler, kayıtlar burada.</p>

</body>
</html>
