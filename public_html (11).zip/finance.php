<?php
require __DIR__ . "/auth.php";
header("Location: /finance/dashboard.php");
exit;
