<?php
require __DIR__ . "/auth.php";

$taskId = (int)($_GET['id'] ?? 0);
$msg = $_GET['msg'] ?? "";

// Görev bilgilerini çek
$stmt = $pdo->prepare("
    SELECT t.*, 
           p.name as project_name, p.company_id,
           u1.name as assigned_user_name,
           u2.name as creator_name
    FROM tasks t
    LEFT JOIN projects p ON t.project_id = p.id
    LEFT JOIN users u1 ON t.assigned_to = u1.id
    LEFT JOIN users u2 ON t.created_by = u2.id
    WHERE t.id = ?
");
$stmt->execute([$taskId]);
$task = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$task) {
    die("Görev bulunamadı");
}

// Yetki kontrolü
if (!is_super_admin() && (int)$task['company_id'] !== $companyId) {
    die("Bu göreve erişiminiz yok");
}

// Dosya yükleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES['task_file'])) {
    try {
        $uploadDir = __DIR__ . "/uploads/tasks/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileName = $_FILES['task_file']['name'];
        $tmpName = $_FILES['task_file']['tmp_name'];
        $fileSize = $_FILES['task_file']['size'];
        
        $safeFileName = time() . '_' . preg_replace('/[^a-zA-Z0-9._-]/', '_', $fileName);
        $filePath = $uploadDir . $safeFileName;
        
        if (move_uploaded_file($tmpName, $filePath)) {
            $stmt = $pdo->prepare("
                INSERT INTO task_files (task_id, file_name, file_path, file_size, uploaded_by, uploaded_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$taskId, $fileName, 'uploads/tasks/' . $safeFileName, $fileSize, $userId]);
            
            header("Location: task_detail.php?id=$taskId&msg=file_uploaded");
            exit;
        }
    } catch (Exception $e) {
        $msg = "error_" . $e->getMessage();
    }
}

// Yorum ekleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_comment'])) {
    try {
        $comment = trim($_POST['comment'] ?? "");
        
        if (empty($comment)) {
            throw new Exception("Yorum boş olamaz");
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO task_comments (task_id, user_id, comment, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$taskId, $userId, $comment]);
        
        header("Location: task_detail.php?id=$taskId&msg=comment_added");
        exit;
        
    } catch (Exception $e) {
        $msg = "error_" . $e->getMessage();
    }
}

// Hızlı durum güncelleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['quick_update'])) {
    try {
        $status = $_POST['status'] ?? "";
        $priority = $_POST['priority'] ?? "";
        
        $stmt = $pdo->prepare("UPDATE tasks SET status = ?, priority = ? WHERE id = ?");
        $stmt->execute([$status, $priority, $taskId]);
        
        // Güncel bilgiyi çek
        $stmt = $pdo->prepare("
            SELECT t.*, 
                   p.name as project_name, p.company_id,
                   u1.name as assigned_user_name,
                   u2.name as creator_name
            FROM tasks t
            LEFT JOIN projects p ON t.project_id = p.id
            LEFT JOIN users u1 ON t.assigned_to = u1.id
            LEFT JOIN users u2 ON t.created_by = u2.id
            WHERE t.id = ?
        ");
        $stmt->execute([$taskId]);
        $task = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $msg = "updated";
        
    } catch (Exception $e) {
        $msg = "error_" . $e->getMessage();
    }
}

// Dosyaları çek
$stmt = $pdo->prepare("
    SELECT f.*, u.name as uploader_name
    FROM task_files f
    LEFT JOIN users u ON f.uploaded_by = u.id
    WHERE f.task_id = ?
    ORDER BY f.uploaded_at DESC
");
$stmt->execute([$taskId]);
$files = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Yorumları çek
$stmt = $pdo->prepare("
    SELECT c.*, u.name as user_name
    FROM task_comments c
    LEFT JOIN users u ON c.user_id = u.id
    WHERE c.task_id = ?
    ORDER BY c.created_at ASC
");
$stmt->execute([$taskId]);
$comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Öncelik ve durum renkleri
$priorityColors = [
    'low' => 'success',
    'medium' => 'warning',
    'high' => 'danger'
];

$statusColors = [
    'pending' => 'secondary',
    'in_progress' => 'primary',
    'completed' => 'success'
];

$statusLabels = [
    'pending' => '⏳ Bekliyor',
    'in_progress' => '🔄 Devam Ediyor',
    'completed' => '✅ Tamamlandı'
];

$priorityLabels = [
    'low' => '🟢 Düşük',
    'medium' => '🟡 Orta',
    'high' => '🔴 Yüksek'
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($task['title']) ?> - Görev Detay</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); min-height: 100vh; padding: 30px; }
.page-container { max-width: 1400px; margin: 0 auto; }
.card { border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); margin-bottom: 20px; }
.task-header { background: white; border-radius: 15px; padding: 25px; margin-bottom: 20px; }
.file-card { background: #f8fafc; border: 2px solid #e2e8f0; border-radius: 10px; padding: 15px; margin-bottom: 10px; transition: all 0.3s; }
.file-card:hover { border-color: #3b82f6; background: #eff6ff; }
.comment-item { background: #f1f5f9; border-radius: 10px; padding: 15px; margin-bottom: 15px; }
.comment-item.own { background: #dbeafe; border-left: 4px solid #3b82f6; }
.message-input { position: sticky; bottom: 20px; background: white; border-radius: 10px; padding: 15px; box-shadow: 0 -2px 10px rgba(0,0,0,0.1); }
.btn-update { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color: white; }
.btn-update:hover { background: linear-gradient(135deg, #1e293b 0%, #1e3a8a 100%); color: white; }
</style>
</head>
<body>

<div class="page-container">
    
    <!-- Header -->
    <div class="task-header">
        <div class="d-flex justify-content-between align-items-start mb-3">
            <div>
                <h2 class="mb-2"><?= htmlspecialchars($task['title']) ?></h2>
                <div class="d-flex gap-2 align-items-center">
                    <span class="badge bg-<?= $statusColors[$task['status']] ?> px-3 py-2">
                        <?= $statusLabels[$task['status']] ?>
                    </span>
                    <span class="badge bg-<?= $priorityColors[$task['priority']] ?> px-3 py-2">
                        <?= $priorityLabels[$task['priority']] ?>
                    </span>
                    <span class="text-muted">
                        <i class="bi bi-folder"></i> <?= htmlspecialchars($task['project_name']) ?>
                    </span>
                </div>
            </div>
            <div>
                <a href="task_edit.php?id=<?= $taskId ?>" class="btn btn-warning">
                    <i class="bi bi-pencil"></i> Düzenle
                </a>
                <a href="tasks.php" class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i> Geri
                </a>
            </div>
        </div>

        <?php if($msg === 'created'): ?>
            <div class="alert alert-success">✅ Görev başarıyla oluşturuldu!</div>
        <?php elseif($msg === 'updated'): ?>
            <div class="alert alert-success">✅ Görev güncellendi!</div>
        <?php elseif($msg === 'file_uploaded'): ?>
            <div class="alert alert-success">✅ Dosya yüklendi!</div>
        <?php elseif($msg === 'comment_added'): ?>
            <div class="alert alert-success">✅ Yorum eklendi!</div>
        <?php elseif(strpos($msg, 'error_') === 0): ?>
            <div class="alert alert-danger">❌ <?= htmlspecialchars(substr($msg, 6)) ?></div>
        <?php endif; ?>

        <div class="row mt-3">
            <div class="col-md-3">
                <small class="text-muted">Atanan</small><br>
                <strong><?= htmlspecialchars($task['assigned_user_name'] ?? 'Atanmamış') ?></strong>
            </div>
            <div class="col-md-3">
                <small class="text-muted">Oluşturan</small><br>
                <strong><?= htmlspecialchars($task['creator_name']) ?></strong>
            </div>
            <div class="col-md-3">
                <small class="text-muted">Başlangıç</small><br>
                <strong><?= date('d.m.Y', strtotime($task['start_date'])) ?></strong>
            </div>
            <div class="col-md-3">
                <small class="text-muted">Bitiş</small><br>
                <strong><?= date('d.m.Y', strtotime($task['due_date'])) ?></strong>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Sol Taraf - Detaylar -->
        <div class="col-md-8">
            
            <!-- Açıklama -->
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-text-paragraph"></i> Açıklama</h5>
                </div>
                <div class="card-body">
                    <?php if(!empty($task['description'])): ?>
                        <p class="mb-0"><?= nl2br(htmlspecialchars($task['description'])) ?></p>
                    <?php else: ?>
                        <p class="text-muted mb-0"><em>Açıklama eklenmemiş</em></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Dosyalar -->
            <div class="card">
                <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-paperclip"></i> Dosyalar (<?= count($files) ?>)</h5>
                    <button class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#uploadModal">
                        <i class="bi bi-upload"></i> Dosya Yükle
                    </button>
                </div>
                <div class="card-body">
                    <?php if(empty($files)): ?>
                        <p class="text-muted text-center py-3 mb-0">
                            <i class="bi bi-inbox" style="font-size: 48px;"></i><br>
                            Henüz dosya yüklenmemiş
                        </p>
                    <?php else: ?>
                        <?php foreach($files as $file): ?>
                        <div class="file-card">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <i class="bi bi-file-earmark text-primary" style="font-size: 24px;"></i>
                                    <strong class="ms-2"><?= htmlspecialchars($file['file_name']) ?></strong>
                                    <br>
                                    <small class="text-muted ms-5">
                                        <?= number_format($file['file_size'] / 1024, 1) ?> KB • 
                                        <?= htmlspecialchars($file['uploader_name']) ?> • 
                                        <?= date('d.m.Y H:i', strtotime($file['uploaded_at'])) ?>
                                    </small>
                                </div>
                                <a href="<?= htmlspecialchars($file['file_path']) ?>" class="btn btn-primary" download>
                                    <i class="bi bi-download"></i>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Yorumlar / Mesajlar -->
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="bi bi-chat-dots"></i> Mesajlar (<?= count($comments) ?>)</h5>
                </div>
                <div class="card-body" style="max-height: 500px; overflow-y: auto;">
                    <?php if(empty($comments)): ?>
                        <p class="text-muted text-center py-3 mb-0">
                            <i class="bi bi-chat" style="font-size: 48px;"></i><br>
                            Henüz mesaj yok. İlk mesajı siz gönderin!
                        </p>
                    <?php else: ?>
                        <?php foreach($comments as $comment): ?>
                        <div class="comment-item <?= (int)$comment['user_id'] === $userId ? 'own' : '' ?>">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <strong><?= htmlspecialchars($comment['user_name']) ?></strong>
                                    <?php if((int)$comment['user_id'] === $userId): ?>
                                        <span class="badge bg-primary ms-1">Siz</span>
                                    <?php endif; ?>
                                    <br>
                                    <small class="text-muted"><?= date('d.m.Y H:i', strtotime($comment['created_at'])) ?></small>
                                </div>
                            </div>
                            <p class="mt-2 mb-0"><?= nl2br(htmlspecialchars($comment['comment'])) ?></p>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Mesaj Gönder -->
            <div class="message-input">
                <form method="post">
                    <div class="input-group">
                        <input type="text" name="comment" class="form-control form-control-lg" placeholder="Mesaj yazın..." required>
                        <button type="submit" name="add_comment" class="btn btn-success btn-lg">
                            <i class="bi bi-send"></i> Gönder
                        </button>
                    </div>
                </form>
            </div>

        </div>

        <!-- Sağ Taraf - Hızlı İşlemler -->
        <div class="col-md-4">
            
            <!-- Hızlı Güncelleme -->
            <div class="card">
                <div class="card-header bg-warning">
                    <h5 class="mb-0"><i class="bi bi-lightning"></i> Hızlı Güncelleme</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Durum</label>
                            <select name="status" class="form-select form-select-lg">
                                <option value="pending" <?= $task['status'] === 'pending' ? 'selected' : '' ?>>⏳ Bekliyor</option>
                                <option value="in_progress" <?= $task['status'] === 'in_progress' ? 'selected' : '' ?>>🔄 Devam Ediyor</option>
                                <option value="completed" <?= $task['status'] === 'completed' ? 'selected' : '' ?>>✅ Tamamlandı</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Öncelik</label>
                            <select name="priority" class="form-select form-select-lg">
                                <option value="low" <?= $task['priority'] === 'low' ? 'selected' : '' ?>>🟢 Düşük</option>
                                <option value="medium" <?= $task['priority'] === 'medium' ? 'selected' : '' ?>>🟡 Orta</option>
                                <option value="high" <?= $task['priority'] === 'high' ? 'selected' : '' ?>>🔴 Yüksek</option>
                            </select>
                        </div>
                        <button type="submit" name="quick_update" class="btn btn-update w-100">
                            <i class="bi bi-check-circle"></i> Güncelle
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </div>

</div>

<!-- Upload Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="bi bi-upload"></i> Dosya Yükle</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="file" name="task_file" class="form-control form-control-lg" required>
                    <small class="text-muted">PDF, Word, Excel, Resim dosyaları desteklenmektedir</small>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-info">
                        <i class="bi bi-upload"></i> Yükle
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>