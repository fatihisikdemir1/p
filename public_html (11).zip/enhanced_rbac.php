<?php
// enhanced_rbac.php

function is_super_admin(): bool {
    global $userRole;
    return $userRole === 'super_admin';
}

function can_create_super_admin(): bool {
    return is_super_admin();
}

function has_permission(string $permission): bool {
    global $userId, $userRole, $pdo;
    
    if (is_super_admin()) {
        return true;
    }
    
    if ($userRole === 'company_admin') {
        $companyAdminPermissions = [
            'manage_users',
            'view_all_tasks',
            'manage_projects',
            'manage_tasks',
            'view_own_tasks',
            'edit_own_tasks',
            'delete_own_tasks',
            'edit_any_project',
            'delete_any_project',
            'delete_any_task'
        ];
        
        if (in_array($permission, $companyAdminPermissions)) {
            return true;
        }
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) 
            FROM role_permissions rp
            INNER JOIN roles r ON rp.role_id = r.id
            INNER JOIN users u ON u.role_id = r.id
            WHERE u.id = ? AND rp.permission_key = ? AND rp.permission_value = 1
        ");
        $stmt->execute([$userId, $permission]);
        return (int)$stmt->fetchColumn() > 0;
    } catch (Exception $e) {
        return false;
    }
}

function can_manage_roles(): bool {
    return is_super_admin();
}

function can_edit_project(int $projectId): bool {
    global $userId, $companyId, $pdo;
    
    if (is_super_admin()) return true;
    if (has_permission('edit_any_project')) return true;
    
    $stmt = $pdo->prepare("SELECT created_by, company_id FROM projects WHERE id = ?");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$project) return false;
    if ((int)$project['company_id'] === $companyId) return true;
    
    return (int)$project['created_by'] === $userId;
}

function can_delete_project(int $projectId): bool {
    global $userId, $companyId, $pdo;
    
    if (is_super_admin()) return true;
    if (has_permission('delete_any_project')) return true;
    
    $stmt = $pdo->prepare("SELECT created_by, company_id FROM projects WHERE id = ?");
    $stmt->execute([$projectId]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$project) return false;
    if ((int)$project['company_id'] === $companyId) return true;
    
    return (int)$project['created_by'] === $userId;
}

function can_edit_task(int $taskId): bool {
    global $userId, $pdo;
    
    if (is_super_admin()) return true;
    
    $stmt = $pdo->prepare("SELECT assigned_to, created_by FROM tasks WHERE id = ?");
    $stmt->execute([$taskId]);
    $task = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$task) return false;
    
    if (has_permission('edit_own_tasks')) {
        if ((int)$task['assigned_to'] === $userId || (int)$task['created_by'] === $userId) {
            return true;
        }
    }
    
    return false;
}

function can_delete_task(int $taskId): bool {
    global $userId, $companyId, $pdo;
    
    if (is_super_admin()) return true;
    if (has_permission('delete_any_task')) return true;
    
    $stmt = $pdo->prepare("
        SELECT t.assigned_to, t.created_by, p.company_id
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        WHERE t.id = ?
    ");
    $stmt->execute([$taskId]);
    $task = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$task) return false;
    if ((int)$task['company_id'] === $companyId) return true;
    
    if (has_permission('delete_own_tasks')) {
        if ((int)$task['assigned_to'] === $userId || (int)$task['created_by'] === $userId) {
            return true;
        }
    }
    
    return false;
}