<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require __DIR__ . "/auth.php";

$msg = "";
$err = "";

// Görev oluşturma
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['create_task'])) {
    try {
        $title = trim($_POST['title'] ?? "");
        $description = trim($_POST['description'] ?? "");
        $projectId = (int)($_POST['project_id'] ?? 0);
        $assignedUsers = $_POST['assigned_to'] ?? []; // Çoklu seçim
        $priority = $_POST['priority'] ?? 'medium';
        $status = $_POST['status'] ?? 'pending';
        $startDate = $_POST['start_date'] ?? null;
        $dueDate = $_POST['due_date'] ?? null;
        $createTag = isset($_POST['create_tag']) ? 1 : 0;
        $tagName = trim($_POST['tag_name'] ?? "");
        
        if (empty($title) || $projectId === 0) {
            throw new Exception("Başlık ve proje zorunludur");
        }
        
        if (empty($startDate) || empty($dueDate)) {
            throw new Exception("Başlangıç ve bitiş tarihi zorunludur");
        }
        
        if (strtotime($dueDate) < strtotime($startDate)) {
            throw new Exception("Bitiş tarihi başlangıç tarihinden önce olamaz");
        }
        
        // Görevi oluştur
        $stmt = $pdo->prepare("
            INSERT INTO tasks (project_id, title, description, assigned_to, priority, status, start_date, due_date, created_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        // İlk atanan kişiyi assigned_to'ya koy (geriye dönük uyumluluk)
        $mainAssignedTo = !empty($assignedUsers) ? (int)$assignedUsers[0] : null;
        
        $stmt->execute([
            $projectId,
            $title,
            $description,
            $mainAssignedTo,
            $priority,
            $status,
            $startDate,
            $dueDate,
            $userId
        ]);
        
        $taskId = $pdo->lastInsertId();
        
        // Çoklu atamaları kaydet
        if (!empty($assignedUsers)) {
            $stmt = $pdo->prepare("
                INSERT INTO task_assignments (task_id, user_id, assigned_at)
                VALUES (?, ?, NOW())
            ");
            
            foreach ($assignedUsers as $assignedUserId) {
                $assignedUserId = (int)$assignedUserId;
                if ($assignedUserId > 0) {
                    try {
                        $stmt->execute([$taskId, $assignedUserId]);
                        
                        // Her atanan kişi için etiket oluştur
                        if ($createTag && !empty($tagName)) {
                            $tagStmt = $pdo->prepare("
                                INSERT INTO task_tags (task_id, user_id, tag_name, tag_color, created_at)
                                VALUES (?, ?, ?, 'primary', NOW())
                            ");
                            $tagStmt->execute([$taskId, $assignedUserId, $tagName]);
                        }
                    } catch (Exception $e) {
                        // Duplicate ise geç
                    }
                }
            }
        }
        
        // Dosya yükleme
        if (isset($_FILES['files']) && !empty($_FILES['files']['name'][0])) {
            $uploadDir = __DIR__ . '/uploads/tasks/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            $fileCount = count($_FILES['files']['name']);
            for ($i = 0; $i < $fileCount; $i++) {
                if ($_FILES['files']['error'][$i] === UPLOAD_ERR_OK) {
                    $fileName = basename($_FILES['files']['name'][$i]);
                    $fileSize = $_FILES['files']['size'][$i];
                    $fileTmp = $_FILES['files']['tmp_name'][$i];
                    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                    
                    $newFileName = uniqid() . '_' . $fileName;
                    $filePath = $uploadDir . $newFileName;
                    
                    if (move_uploaded_file($fileTmp, $filePath)) {
                        $stmt = $pdo->prepare("
                            INSERT INTO task_files (task_id, file_name, file_path, file_size, uploaded_by, uploaded_at)
                            VALUES (?, ?, ?, ?, ?, NOW())
                        ");
                        $stmt->execute([
                            $taskId,
                            $fileName,
                            '/uploads/tasks/' . $newFileName,
                            $fileSize,
                            $userId
                        ]);
                    }
                }
            }
        }
        
        header("Location: task_detail.php?id=$taskId");
        exit;
        
    } catch (Exception $e) {
        $err = $e->getMessage();
    }
}

// Projeleri çek
if (is_super_admin()) {
    $projects = $pdo->query("SELECT * FROM projects ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE company_id = ? ORDER BY name");
    $stmt->execute([$companyId]);
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Kullanıcıları çek
if (is_super_admin()) {
    $users = $pdo->query("SELECT id, name, email FROM users ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("SELECT id, name, email FROM users WHERE company_id = ? ORDER BY name");
    $stmt->execute([$companyId]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Yeni Görev Oluştur</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
<style>
body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 30px; }
.form-container { max-width: 900px; margin: 0 auto; background: white; border-radius: 20px; padding: 40px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); }
.form-header { border-bottom: 3px solid #667eea; padding-bottom: 20px; margin-bottom: 30px; }
.form-section { background: #f8fafc; border-radius: 15px; padding: 25px; margin-bottom: 25px; }
.section-title { color: #667eea; font-weight: 700; margin-bottom: 20px; font-size: 18px; }
.file-upload-area { border: 3px dashed #cbd5e1; border-radius: 15px; padding: 30px; text-align: center; transition: all 0.3s; cursor: pointer; }
.file-upload-area:hover { border-color: #667eea; background: #f1f5f9; }
.file-upload-area.drag-over { border-color: #667eea; background: #dbeafe; }
.file-preview { background: white; border-radius: 10px; padding: 12px; margin-top: 10px; display: flex; justify-content: space-between; align-items: center; }
.select2-container--bootstrap-5 .select2-selection { border-radius: 10px; padding: 8px; }
</style>
</head>
<body>

<div class="form-container">
    <div class="form-header">
        <h2 style="color: #667eea;"><i class="bi bi-plus-circle-fill"></i> Yeni Görev Oluştur</h2>
        <p class="text-muted mb-0">Çoklu kişi ataması ve etiket oluşturma</p>
    </div>

    <?php if ($err): ?>
        <div class="alert alert-danger">
            <i class="bi bi-exclamation-triangle"></i> <?= $err ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        
        <!-- Temel Bilgiler -->
        <div class="form-section">
            <div class="section-title"><i class="bi bi-info-circle"></i> Temel Bilgiler</div>
            
            <div class="mb-3">
                <label class="form-label fw-bold">Görev Başlığı *</label>
                <input type="text" name="title" class="form-control form-control-lg" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Açıklama</label>
                <textarea name="description" class="form-control" rows="4"></textarea>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Proje *</label>
                    <select name="project_id" class="form-select" required>
                        <option value="">Seçiniz...</option>
                        <?php foreach ($projects as $project): ?>
                            <option value="<?= $project['id'] ?>"><?= htmlspecialchars($project['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Öncelik</label>
                    <select name="priority" class="form-select">
                        <option value="low">🟢 Düşük</option>
                        <option value="medium" selected>🟡 Orta</option>
                        <option value="high">🔴 Yüksek</option>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Başlangıç Tarihi *</label>
                    <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>

                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Bitiş Tarihi *</label>
                    <input type="date" name="due_date" class="form-control" value="<?= date('Y-m-d', strtotime('+7 days')) ?>" required>
                </div>
            </div>
        </div>

        <!-- Çoklu Kişi Atama -->
        <div class="form-section">
            <div class="section-title"><i class="bi bi-people-fill"></i> Kişi Atama (Çoklu Seçim)</div>
            
            <div class="mb-3">
                <label class="form-label fw-bold">Atanacak Kişiler</label>
                <select name="assigned_to[]" id="assignedUsers" class="form-select" multiple>
                    <?php foreach ($users as $user): ?>
                        <option value="<?= $user['id'] ?>">
                            <?= htmlspecialchars($user['name']) ?> (<?= htmlspecialchars($user['email']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <small class="text-muted">Ctrl/Cmd tuşu ile birden fazla kişi seçebilirsiniz</small>
            </div>
        </div>

        <!-- Etiket Oluşturma -->
        <div class="form-section">
            <div class="section-title"><i class="bi bi-tag-fill"></i> Etiket Oluşturma</div>
            
            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" name="create_tag" id="createTag" onchange="toggleTagInput()">
                <label class="form-check-label fw-bold" for="createTag">
                    Atanan kişiler için otomatik etiket oluştur
                </label>
            </div>

            <div id="tagInputArea" style="display: none;">
                <div class="mb-3">
                    <label class="form-label fw-bold">Etiket Adı</label>
                    <input type="text" name="tag_name" class="form-control" placeholder="Örn: Yeni Görev Ataması">
                    <small class="text-muted">Bu etiket atanan her kişinin etiket listesinde görünecektir</small>
                </div>
            </div>
        </div>

        <!-- Dosya Yükleme -->
        <div class="form-section">
            <div class="section-title"><i class="bi bi-paperclip"></i> Dosya Ekleme (Opsiyonel)</div>
            
            <div class="file-upload-area" id="fileDropArea">
                <i class="bi bi-cloud-upload" style="font-size: 48px; color: #cbd5e1;"></i>
                <p class="mt-3 mb-2"><strong>Dosyaları buraya sürükleyin</strong></p>
                <p class="text-muted mb-3">veya</p>
                <label class="btn btn-primary">
                    <i class="bi bi-folder"></i> Dosya Seç
                    <input type="file" name="files[]" id="fileInput" multiple style="display: none;" onchange="handleFiles(this.files)">
                </label>
                <p class="text-muted small mt-3">Birden fazla dosya seçebilirsiniz</p>
            </div>

            <div id="filePreviewArea"></div>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" name="create_task" class="btn btn-primary btn-lg flex-fill">
                <i class="bi bi-check-circle"></i> Görevi Oluştur
            </button>
            <a href="tasks.php" class="btn btn-secondary btn-lg">
                <i class="bi bi-x-circle"></i> İptal
            </a>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
// Select2 için çoklu seçim
$(document).ready(function() {
    $('#assignedUsers').select2({
        theme: 'bootstrap-5',
        placeholder: 'Kişileri seçin...',
        allowClear: true,
        width: '100%'
    });
});

// Tag input toggle
function toggleTagInput() {
    const tagArea = document.getElementById('tagInputArea');
    const checkbox = document.getElementById('createTag');
    tagArea.style.display = checkbox.checked ? 'block' : 'none';
}

// Dosya işleme
let selectedFiles = [];

function handleFiles(files) {
    for (let file of files) {
        if (!selectedFiles.find(f => f.name === file.name && f.size === file.size)) {
            selectedFiles.push(file);
        }
    }
    updateFilePreview();
}

function removeFile(index) {
    selectedFiles.splice(index, 1);
    updateFilePreview();
}

function updateFilePreview() {
    const previewArea = document.getElementById('filePreviewArea');
    
    if (selectedFiles.length === 0) {
        previewArea.innerHTML = '';
        return;
    }
    
    let html = '<div class="mt-3">';
    selectedFiles.forEach((file, index) => {
        const size = (file.size / 1024).toFixed(1);
        html += `
            <div class="file-preview">
                <div>
                    <i class="bi bi-file-earmark"></i>
                    <strong>${file.name}</strong>
                    <small class="text-muted">(${size} KB)</small>
                </div>
                <button type="button" class="btn btn-sm btn-danger" onclick="removeFile(${index})">
                    <i class="bi bi-x"></i>
                </button>
            </div>
        `;
    });
    html += '</div>';
    
    previewArea.innerHTML = html;
}

// Drag & Drop
const dropArea = document.getElementById('fileDropArea');

['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    dropArea.addEventListener(eventName, preventDefaults, false);
});

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

['dragenter', 'dragover'].forEach(eventName => {
    dropArea.addEventListener(eventName, () => {
        dropArea.classList.add('drag-over');
    }, false);
});

['dragleave', 'drop'].forEach(eventName => {
    dropArea.addEventListener(eventName, () => {
        dropArea.classList.remove('drag-over');
    }, false);
});

dropArea.addEventListener('drop', function(e) {
    const dt = e.dataTransfer;
    const files = dt.files;
    handleFiles(files);
}, false);

// Tarih validasyonu
document.querySelector('input[name="due_date"]').addEventListener('change', function() {
    const startDate = document.querySelector('input[name="start_date"]').value;
    const endDate = this.value;
    
    if (startDate && endDate && endDate < startDate) {
        alert('Bitiş tarihi başlangıç tarihinden önce olamaz!');
        this.value = '';
    }
});
</script>

</body>
</html>