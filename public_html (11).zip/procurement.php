<?php
require __DIR__ . "/auth.php";
header("Location: /procurement/views/dashboard.php");
exit;
