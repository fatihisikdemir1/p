<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// Firma filtresi (super admin icin)
$filterCompanyId = (int)($_GET['company_id'] ?? 0);

// Firma listesi (super admin icin)
$companies = [];
if (is_super_admin()) {
    $companies = $pdo->query("SELECT id, name FROM companies ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
}

// Projeleri listele
if (is_super_admin()) {
    if ($filterCompanyId > 0) {
        $whereClause = "WHERE p.company_id = ?";
        $params = [$filterCompanyId];
    } else {
        $whereClause = "";
        $params = [];
    }
} else {
    $whereClause = "WHERE p.company_id = ?";
    $params = [$companyId];
}

$stmt = $pdo->prepare("
    SELECT p.*, 
           c.name as company_name,
           COUNT(DISTINCT t.id) as task_count,
           creator.name as creator_name
    FROM projects p
    LEFT JOIN companies c ON p.company_id = c.id
    LEFT JOIN tasks t ON p.id = t.project_id
    LEFT JOIN users creator ON p.created_by = creator.id
    {$whereClause}
    GROUP BY p.id
    ORDER BY p.created_at DESC
");
$stmt->execute($params);
$projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Projeler</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>

<div class="container-fluid p-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-folder"></i> Projeler</h2>
        </div>
        <div class="col-auto">
            <a href="dashboard.php" class="btn btn-secondary">
                <i class="bi bi-house"></i> Dashboard
            </a>
        </div>
    </div>

    <?php if (is_super_admin() && !empty($companies)): ?>
    <div class="card mb-3">
        <div class="card-body">
            <form method="get" class="row g-3 align-items-end">
                <div class="col-md-6">
                    <label class="form-label">Firma Filtrele</label>
                    <select name="company_id" class="form-select" onchange="this.form.submit()">
                        <option value="0">Tüm Firmalar</option>
                        <?php foreach ($companies as $company): ?>
                            <option value="<?= (int)$company['id'] ?>" 
                                    <?= $filterCompanyId === (int)$company['id'] ? 'selected' : '' ?>>
                                <?= e($company['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-funnel"></i> Filtrele
                    </button>
                    <?php if ($filterCompanyId > 0): ?>
                    <a href="projects.php" class="btn btn-secondary">
                        <i class="bi bi-x"></i> Temizle
                    </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Proje Adı</th>
                            <?php if (is_super_admin()): ?><th>Firma</th><?php endif; ?>
                            <th>Görev Sayısı</th>
                            <th>Oluşturan</th>
                            <th>Tarih</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($projects as $project): ?>
                        <tr>
                            <td><strong><?= e($project['name']) ?></strong></td>
                            <?php if (is_super_admin()): ?>
                            <td><?= e($project['company_name'] ?? '-') ?></td>
                            <?php endif; ?>
                            <td><span class="badge bg-primary"><?= (int)$project['task_count'] ?></span></td>
                            <td><?= e($project['creator_name'] ?? '-') ?></td>
                            <td><?= date('d.m.Y', strtotime($project['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</body>
</html>