<?php
require __DIR__ . "/auth.php";
header("Location: /modules.php");
exit;
