<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// İstatistikler
if (is_super_admin()) {
    // Super admin tüm dataları görür
    $totalProjects = $pdo->query("SELECT COUNT(*) FROM projects")->fetchColumn();
    $totalTasks = $pdo->query("SELECT COUNT(*) FROM tasks")->fetchColumn();
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $totalCompanies = $pdo->query("SELECT COUNT(*) FROM companies")->fetchColumn();
    
    $completedTasks = $pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'completed'")->fetchColumn();
    $pendingTasks = $pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'pending'")->fetchColumn();
    $inProgressTasks = $pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'in_progress'")->fetchColumn();
} else {
    // Company admin ve user sadece kendi şirketini görür
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE company_id = ?");
    $stmt->execute([$companyId]);
    $totalProjects = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        WHERE p.company_id = ?
    ");
    $stmt->execute([$companyId]);
    $totalTasks = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE company_id = ?");
    $stmt->execute([$companyId]);
    $totalUsers = $stmt->fetchColumn();
    
    $totalCompanies = 1; // Kendi şirketi
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        WHERE p.company_id = ? AND t.status = 'completed'
    ");
    $stmt->execute([$companyId]);
    $completedTasks = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        WHERE p.company_id = ? AND t.status = 'pending'
    ");
    $stmt->execute([$companyId]);
    $pendingTasks = $stmt->fetchColumn();
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        WHERE p.company_id = ? AND t.status = 'in_progress'
    ");
    $stmt->execute([$companyId]);
    $inProgressTasks = $stmt->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Raporlar</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<div class="container-fluid p-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-bar-chart"></i> Raporlar ve İstatistikler</h2>
        </div>
        <div class="col-auto">
            <a href="dashboard.php" class="btn btn-secondary">
                <i class="bi bi-house"></i> Dashboard
            </a>
        </div>
    </div>

    <!-- İstatistik Kartları -->
    <div class="row mb-4">
        <?php if (is_super_admin()): ?>
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h3><?= (int)$totalCompanies ?></h3>
                    <p class="mb-0">Toplam Firma</p>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h3><?= (int)$totalProjects ?></h3>
                    <p class="mb-0">Toplam Proje</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h3><?= (int)$totalTasks ?></h3>
                    <p class="mb-0">Toplam Görev</p>
                </div>
            </div>
        </div>
        
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h3><?= (int)$totalUsers ?></h3>
                    <p class="mb-0">Toplam Kullanıcı</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Grafikler -->
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Görev Durumu</h5>
                </div>
                <div class="card-body">
                    <canvas id="taskStatusChart"></canvas>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Genel Özet</h5>
                </div>
                <div class="card-body">
                    <canvas id="overviewChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Görev Durumu Grafiği
const taskStatusCtx = document.getElementById('taskStatusChart').getContext('2d');
new Chart(taskStatusCtx, {
    type: 'pie',
    data: {
        labels: ['Tamamlandı', 'Devam Ediyor', 'Bekliyor'],
        datasets: [{
            data: [<?= (int)$completedTasks ?>, <?= (int)$inProgressTasks ?>, <?= (int)$pendingTasks ?>],
            backgroundColor: ['#10b981', '#3b82f6', '#6b7280']
        }]
    }
});

// Genel Özet Grafiği
const overviewCtx = document.getElementById('overviewChart').getContext('2d');
new Chart(overviewCtx, {
    type: 'bar',
    data: {
        labels: ['Projeler', 'Görevler', 'Kullanıcılar'],
        datasets: [{
            label: 'Toplam',
            data: [<?= (int)$totalProjects ?>, <?= (int)$totalTasks ?>, <?= (int)$totalUsers ?>],
            backgroundColor: ['#10b981', '#3b82f6', '#f59e0b']
        }]
    },
    options: {
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>

</body>
</html>