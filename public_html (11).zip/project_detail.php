<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$projectId = (int)($_GET['id'] ?? 0);

if ($projectId === 0) {
    header("Location: projects.php");
    exit;
}

// Projeyi al
$stmt = $pdo->prepare("
    SELECT p.*, 
           c.name as company_name,
           creator.name as creator_name
    FROM projects p
    LEFT JOIN companies c ON p.company_id = c.id
    LEFT JOIN users creator ON p.created_by = creator.id
    WHERE p.id = ?
");
$stmt->execute([$projectId]);
$project = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$project) {
    die("Proje bulunamadı");
}

// Company admin sadece kendi firmasını görebilir
if (!is_super_admin() && (int)$project['company_id'] !== $companyId) {
    die("Bu projeyi görüntüleme yetkiniz yok");
}

// Projeye ait görevler
$stmt = $pdo->prepare("
    SELECT t.*,
           assigned.name as assigned_name,
           creator.name as creator_name
    FROM tasks t
    LEFT JOIN users assigned ON t.assigned_to = assigned.id
    LEFT JOIN users creator ON t.created_by = creator.id
    WHERE t.project_id = ?
    ORDER BY t.created_at DESC
");
$stmt->execute([$projectId]);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Dosyalar (varsa files tablosu)
$files = [];
$filesTableExists = false;
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'project_files'");
    if ($stmt->rowCount() > 0) {
        $filesTableExists = true;
        $stmt = $pdo->prepare("
            SELECT * FROM project_files 
            WHERE project_id = ? 
            ORDER BY uploaded_at DESC
        ");
        $stmt->execute([$projectId]);
        $files = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    // Tablo yoksa devam et
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title><?= e($project['name']) ?> - Proje Detay</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container-fluid p-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-folder"></i> <?= e($project['name']) ?></h2>
            <p class="text-muted"><?= e($project['description'] ?? '') ?></p>
        </div>
        <div class="col-auto">
            <a href="projects.php" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i> Projelere Dön
            </a>
            <a href="dashboard.php" class="btn btn-secondary">
                <i class="bi bi-house"></i> Dashboard
            </a>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h4><?= count($tasks) ?></h4>
                    <small class="text-muted">Toplam Görev</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h4><?= count($files) ?></h4>
                    <small class="text-muted">Dosya</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <small class="text-muted">Oluşturan</small>
                    <h6><?= e($project['creator_name'] ?? '-') ?></h6>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <small class="text-muted">Tarih</small>
                    <h6><?= date('d.m.Y', strtotime($project['created_at'])) ?></h6>
                </div>
            </div>
        </div>
    </div>

    <!-- Görevler -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0"><i class="bi bi-check-square"></i> Görevler</h5>
        </div>
        <div class="card-body">
            <?php if (empty($tasks)): ?>
                <p class="text-muted text-center">Bu projede henüz görev yok</p>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Görev</th>
                            <th>Durum</th>
                            <th>Atanan</th>
                            <th>Öncelik</th>
                            <th>Bitiş Tarihi</th>
                            <th>Oluşturan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tasks as $task): ?>
                        <tr>
                            <td><strong><?= e($task['title']) ?></strong></td>
                            <td>
                                <?php
                                $statusBadge = 'secondary';
                                $statusText = 'Bekliyor';
                                if ($task['status'] === 'in_progress') {
                                    $statusBadge = 'primary';
                                    $statusText = 'Devam Ediyor';
                                } elseif ($task['status'] === 'completed') {
                                    $statusBadge = 'success';
                                    $statusText = 'Tamamlandı';
                                }
                                ?>
                                <span class="badge bg-<?= $statusBadge ?>"><?= $statusText ?></span>
                            </td>
                            <td><?= e($task['assigned_name'] ?? '-') ?></td>
                            <td>
                                <?php if ($task['priority'] === 'high'): ?>
                                    <span class="badge bg-danger">Yüksek</span>
                                <?php elseif ($task['priority'] === 'medium'): ?>
                                    <span class="badge bg-warning">Orta</span>
                                <?php else: ?>
                                    <span class="badge bg-info">Düşük</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= $task['due_date'] ? date('d.m.Y', strtotime($task['due_date'])) : '-' ?>
                            </td>
                            <td><?= e($task['creator_name'] ?? '-') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Dosyalar -->
    <?php if ($filesTableExists): ?>
    <div class="card">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0"><i class="bi bi-file-earmark"></i> Dosyalar</h5>
        </div>
        <div class="card-body">
            <?php if (empty($files)): ?>
                <p class="text-muted text-center">Bu projede henüz dosya yok</p>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Dosya Adı</th>
                            <th>Boyut</th>
                            <th>Yükleyen</th>
                            <th>Tarih</th>
                            <th>İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($files as $file): ?>
                        <tr>
                            <td>
                                <i class="bi bi-file-earmark"></i>
                                <?= e($file['file_name']) ?>
                            </td>
                            <td><?= e($file['file_size'] ?? '-') ?></td>
                            <td><?= e($file['uploaded_by'] ?? '-') ?></td>
                            <td><?= date('d.m.Y H:i', strtotime($file['uploaded_at'])) ?></td>
                            <td>
                                <a href="<?= e($file['file_path']) ?>" 
                                   class="btn btn-sm btn-primary" download>
                                    <i class="bi bi-download"></i> İndir
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php else: ?>
    <div class="alert alert-info">
        <i class="bi bi-info-circle"></i> Dosya yönetimi sistemi henüz kurulmamış.
    </div>
    <?php endif; ?>
</div>

</body>
</html>