<?php
require_once __DIR__ . "/inc/common.php";
$current = "/finance/receivables.php";
$pageTitle = "FinansConnect • Alacak Takibi";
?>
<?php require __DIR__ . "/inc/layout_head.php"; ?>
<?php require __DIR__ . "/inc/menu.php"; ?>

<main class="content">
  <div class="topbar">
    <div class="title">
      <h1><i class="bi bi-person-check"></i> Alacak Takibi</h1>
      <p>Müşteri bazlı alacak, vade, gecikme; kısmi tahsilat; otomatik aging.</p>
    </div>
    <div class="actions">
      <a class="btn ghost" href="/finance/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
      <a class="btn ghost" href="/modules.php"><i class="bi bi-grid"></i> Modül Seç</a>
    </div>
  </div>

  <div class="card">
    <h2><i class="bi bi-list-check"></i> Liste (Demo)</h2>
    <table class="table">
      <thead><tr><th>Referans</th><th>Tarih</th><th>Açıklama</th><th class="amt">Tutar</th></tr></thead>
      <tbody>
        <tr><td>CUST-AL-001</td><td>2026-02-15</td><td>Müşteri A • Açık</td><td class='amt'>28.000 ₺</td></tr>
<tr><td>CUST-AL-002</td><td>2026-01-10</td><td>Müşteri B • Gecikmiş</td><td class='amt'>12.000 ₺</td></tr>
      </tbody>
    </table>
    
    <div class="note">Bu ekranlar süreç odaklı mimariye göre hazırlandı. Bir sonraki adım: DB tabloları + gerçek CRUD.</div>
  </div>
</main>

<?php require __DIR__ . "/inc/layout_foot.php"; ?>
