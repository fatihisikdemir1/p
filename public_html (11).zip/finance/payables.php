<?php
require_once __DIR__ . "/inc/common.php";
$current = "/finance/payables.php";
$pageTitle = "FinansConnect • Borç Takibi";
?>
<?php require __DIR__ . "/inc/layout_head.php"; ?>
<?php require __DIR__ . "/inc/menu.php"; ?>

<main class="content">
  <div class="topbar">
    <div class="title">
      <h1><i class="bi bi-building-check"></i> Borç Takibi</h1>
      <p>Tedarikçi bazlı borç, vade ve gecikme uyarıları.</p>
    </div>
    <div class="actions">
      <a class="btn ghost" href="/finance/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
      <a class="btn ghost" href="/modules.php"><i class="bi bi-grid"></i> Modül Seç</a>
    </div>
  </div>

  <div class="card">
    <h2><i class="bi bi-list-check"></i> Liste (Demo)</h2>
    <table class="table">
      <thead><tr><th>Referans</th><th>Tarih</th><th>Açıklama</th><th class="amt">Tutar</th></tr></thead>
      <tbody>
        <tr><td>VEND-BR-001</td><td>2026-02-12</td><td>Tedarikçi X • Açık</td><td class='amt'>18.500 ₺</td></tr>
<tr><td>VEND-BR-002</td><td>2026-01-28</td><td>Tedarikçi Y • Gecikmiş</td><td class='amt'>7.200 ₺</td></tr>
      </tbody>
    </table>
    
    <div class="note">Bu ekranlar süreç odaklı mimariye göre hazırlandı. Bir sonraki adım: DB tabloları + gerçek CRUD.</div>
  </div>
</main>

<?php require __DIR__ . "/inc/layout_foot.php"; ?>
