<?php
require_once __DIR__ . "/inc/common.php";
$current = "/finance/aging.php";
$pageTitle = "FinansConnect • Yaşlandırma (Aging) Raporu";
?>
<?php require __DIR__ . "/inc/layout_head.php"; ?>
<?php require __DIR__ . "/inc/menu.php"; ?>

<main class="content">
  <div class="topbar">
    <div class="title">
      <h1><i class="bi bi-hourglass-split"></i> Yaşlandırma (Aging) Raporu</h1>
      <p>0–30 / 31–60 / 61–90 / 90+ gün. Alacak ve borç yaşlandırması + risk görünümü.</p>
    </div>
    <div class="actions">
      <a class="btn ghost" href="/finance/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
      <a class="btn ghost" href="/modules.php"><i class="bi bi-grid"></i> Modül Seç</a>
    </div>
  </div>

  <div class="card">
    <h2><i class="bi bi-list-check"></i> Liste (Demo)</h2>
    <table class="table">
      <thead><tr><th>Referans</th><th>Tarih</th><th>Açıklama</th><th class="amt">Tutar</th></tr></thead>
      <tbody>
        <tr><td>0–30</td><td>-</td><td>Toplam Risk</td><td class='amt'>38.000 ₺</td></tr>
<tr><td>31–60</td><td>-</td><td>Toplam Risk</td><td class='amt'>14.500 ₺</td></tr>
<tr><td>61–90</td><td>-</td><td>Toplam Risk</td><td class='amt'>6.000 ₺</td></tr>
<tr><td>90+</td><td>-</td><td>Toplam Risk</td><td class='amt'>12.000 ₺</td></tr>
      </tbody>
    </table>
    
    <div class="note">Bu ekranlar süreç odaklı mimariye göre hazırlandı. Bir sonraki adım: DB tabloları + gerçek CRUD.</div>
  </div>
</main>

<?php require __DIR__ . "/inc/layout_foot.php"; ?>
