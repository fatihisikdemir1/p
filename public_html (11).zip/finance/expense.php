<?php
require_once __DIR__ . "/inc/common.php";
$current = "/finance/expense.php";
$pageTitle = "FinansConnect • Gider Yönetimi";
?>
<?php require __DIR__ . "/inc/layout_head.php"; ?>
<?php require __DIR__ . "/inc/menu.php"; ?>

<main class="content">
  <div class="topbar">
    <div class="title">
      <h1><i class="bi bi-arrow-up-right"></i> Gider Yönetimi</h1>
      <p>Kira, Maaş, Fatura, Hizmet vb. giderleri kaydet. Ödeme listesi ve borç takibini besler.</p>
    </div>
    <div class="actions">
      <a class="btn ghost" href="/finance/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
      <a class="btn ghost" href="/modules.php"><i class="bi bi-grid"></i> Modül Seç</a>
    </div>
  </div>

  <div class="card">
    <h2><i class="bi bi-list-check"></i> Liste (Demo)</h2>
    <table class="table">
      <thead><tr><th>Referans</th><th>Tarih</th><th>Açıklama</th><th class="amt">Tutar</th></tr></thead>
      <tbody>
        <tr><td>EXP-00044</td><td>2026-02-02</td><td>Kira</td><td class='amt'>35.000 ₺</td></tr>
<tr><td>EXP-00045</td><td>2026-02-06</td><td>Enerji</td><td class='amt'>12.500 ₺</td></tr>
      </tbody>
    </table>
    
        <div class="hr"></div>
        <h2><i class="bi bi-pencil-square"></i> Hızlı Kayıt (Demo Form)</h2>
        <div class="form">
          <div class="field"><label>Tarih</label><input class="input" type="date" value="<?= date('Y-m-d') ?>"></div>
          <div class="field"><label>Tutar (₺)</label><input class="input" type="number" placeholder="0"></div>
          <div class="field"><label>Kategori / Tip</label><input class="input" placeholder="Örn: Satış / Kira / Hizmet"></div>
          <div class="field"><label>Durum</label>
            <select class="input"><option>Beklemede</option><option>Gerçekleşti</option></select>
          </div>
          <div class="field" style="grid-column:1/-1"><label>Açıklama</label><textarea class="input" placeholder="Not..."></textarea></div>
        </div>
        <div class="toolbar">
          <button class="btn" type="button"><i class="bi bi-check2-circle"></i> Kaydet (Demo)</button>
          <a class="btn ghost" href="/finance/dashboard.php"><i class="bi bi-arrow-left"></i> Dashboard</a>
        </div>
        
    <div class="note">Bu ekranlar süreç odaklı mimariye göre hazırlandı. Bir sonraki adım: DB tabloları + gerçek CRUD.</div>
  </div>
</main>

<?php require __DIR__ . "/inc/layout_foot.php"; ?>
