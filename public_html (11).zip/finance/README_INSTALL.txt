FINANSCONNECT - FINANCE FULL MODULE (SPEC MATCH) v1

KURULUM:
1) Sunucuda şu klasörü SİL:
   /home/u336896947/domains/finansconnect.com/public_html/finance/

2) Zip içindeki 'finance' klasörünü aynen public_html altına yükle:
   public_html/finance/...

3) Aç:
   https://finansconnect.com/finance/dashboard.php

MENÜ (BİREBİR SPEC):
1 Dashboard
2 Gelir Yönetimi
3 Gider Yönetimi
4 Hesaplar (Banka/Kasa/Kredi Kartları/Döviz)
5 Çek/Senet
6 Alacak
7 Borç
8 Ödeme Listesi
9 Aging
10 Raporlar
11 Ayarlar

NOT:
- Bu sürüm tasarım + sayfa iskeletidir (demo data).
- Sonraki adım: DB tabloları + CRUD + KPI hesapları.
