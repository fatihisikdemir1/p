<?php
require_once __DIR__ . "/inc/common.php";
$current = "/finance/accounts_fx.php";
$pageTitle = "FinansConnect • Döviz Hesapları";
?>
<?php require __DIR__ . "/inc/layout_head.php"; ?>
<?php require __DIR__ . "/inc/menu.php"; ?>

<main class="content">
  <div class="topbar">
    <div class="title">
      <h1><i class="bi bi-currency-exchange"></i> Döviz Hesapları</h1>
      <p>Dövizli hesaplar, kur, FX hareketleri (placeholder).</p>
    </div>
    <div class="actions">
      <a class="btn ghost" href="/finance/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
      <a class="btn ghost" href="/modules.php"><i class="bi bi-grid"></i> Modül Seç</a>
    </div>
  </div>

  <div class="card">
    <h2><i class="bi bi-list-check"></i> Liste (Demo)</h2>
    <table class="table">
      <thead><tr><th>Referans</th><th>Tarih</th><th>Açıklama</th><th class="amt">Tutar</th></tr></thead>
      <tbody>
        <tr><td>USD-ACC</td><td>-</td><td>USD Hesabı</td><td class='amt'>12.000 $</td></tr>
<tr><td>EUR-ACC</td><td>-</td><td>EUR Hesabı</td><td class='amt'>8.500 €</td></tr>
      </tbody>
    </table>
    
    <div class="note">Bu ekranlar süreç odaklı mimariye göre hazırlandı. Bir sonraki adım: DB tabloları + gerçek CRUD.</div>
  </div>
</main>

<?php require __DIR__ . "/inc/layout_foot.php"; ?>
