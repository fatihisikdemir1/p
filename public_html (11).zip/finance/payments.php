<?php
require_once __DIR__ . "/inc/common.php";
$current = "/finance/payments.php";
$pageTitle = "FinansConnect • Ödeme Listesi";
?>
<?php require __DIR__ . "/inc/layout_head.php"; ?>
<?php require __DIR__ . "/inc/menu.php"; ?>

<main class="content">
  <div class="topbar">
    <div class="title">
      <h1><i class="bi bi-list-check"></i> Ödeme Listesi</h1>
      <p>Yaklaşan ödemeler, gecikenler, günlük/haftalık plan. Borç + kredi taksitleri + çek/senet birleşik görünüm.</p>
    </div>
    <div class="actions">
      <a class="btn ghost" href="/finance/dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
      <a class="btn ghost" href="/modules.php"><i class="bi bi-grid"></i> Modül Seç</a>
    </div>
  </div>

  <div class="card">
    <h2><i class="bi bi-list-check"></i> Liste (Demo)</h2>
    <table class="table">
      <thead><tr><th>Referans</th><th>Tarih</th><th>Açıklama</th><th class="amt">Tutar</th></tr></thead>
      <tbody>
        <tr><td>PAY-PLAN-01</td><td>2026-02-10</td><td>Tedarikçi X • Banka</td><td class='amt'>18.500 ₺</td></tr>
<tr><td>PAY-PLAN-02</td><td>2026-02-11</td><td>Kredi Taksiti • Banka</td><td class='amt'>9.800 ₺</td></tr>
      </tbody>
    </table>
    
    <div class="note">Bu ekranlar süreç odaklı mimariye göre hazırlandı. Bir sonraki adım: DB tabloları + gerçek CRUD.</div>
  </div>
</main>

<?php require __DIR__ . "/inc/layout_foot.php"; ?>
