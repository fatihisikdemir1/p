<?php // expects $current ?>
<aside class="sidebar">
  <div class="brand">
    <div class="t"><i class="bi bi-graph-up"></i> FinansConnect</div>
    <div class="s">Finans Yönetim Sistemi • Süreç Odaklı</div>
  </div>

  <div class="sec">Modüller</div>
  <a class="item" href="/dashboard.php"><i class="bi bi-grid-1x2"></i> Uygulama (Görev/Proje)</a>
  <a class="item" href="/procurement/views/dashboard.php"><i class="bi bi-bag-check"></i> Satınalma</a>
  <a class="item" href="/credit/dashboard.php"><i class="bi bi-bank"></i> Kredi Takip</a>

  <div class="sec">Genel</div>
  <a class="item <?= active('/finance/dashboard.php',$current) ?>" href="/finance/dashboard.php">
    <i class="bi bi-speedometer2"></i> Ana Sayfa (Dashboard)
  </a>

  <div class="sec">Gelir & Gider</div>
  <a class="item <?= active('/finance/income.php',$current) ?>" href="/finance/income.php">
    <i class="bi bi-arrow-down-left"></i> Gelir Yönetimi
  </a>
  <a class="item <?= active('/finance/expense.php',$current) ?>" href="/finance/expense.php">
    <i class="bi bi-arrow-up-right"></i> Gider Yönetimi
  </a>

  <div class="sec">Hesaplar</div>
  <a class="item <?= active('/finance/accounts_bank.php',$current) ?>" href="/finance/accounts_bank.php">
    <i class="bi bi-bank2"></i> Banka Hesapları
  </a>
  <a class="item <?= active('/finance/accounts_cash.php',$current) ?>" href="/finance/accounts_cash.php">
    <i class="bi bi-cash"></i> Kasa
  </a>
  <a class="item <?= active('/finance/accounts_cards.php',$current) ?>" href="/finance/accounts_cards.php">
    <i class="bi bi-credit-card"></i> Kredi Kartları
  </a>
  <a class="item <?= active('/finance/accounts_fx.php',$current) ?>" href="/finance/accounts_fx.php">
    <i class="bi bi-currency-exchange"></i> Döviz Hesapları
  </a>

  <div class="sec">Takip</div>
  <a class="item <?= active('/finance/cheques_notes.php',$current) ?>" href="/finance/cheques_notes.php">
    <i class="bi bi-file-earmark-check"></i> Çek / Senet Takibi
  </a>
  <a class="item <?= active('/finance/receivables.php',$current) ?>" href="/finance/receivables.php">
    <i class="bi bi-person-check"></i> Alacak Takibi
  </a>
  <a class="item <?= active('/finance/payables.php',$current) ?>" href="/finance/payables.php">
    <i class="bi bi-building-check"></i> Borç Takibi
  </a>
  <a class="item <?= active('/finance/payments.php',$current) ?>" href="/finance/payments.php">
    <i class="bi bi-list-check"></i> Ödeme Listesi
  </a>
  <a class="item <?= active('/finance/aging.php',$current) ?>" href="/finance/aging.php">
    <i class="bi bi-hourglass-split"></i> Yaşlandırma (Aging)
  </a>

  <div class="sec">Rapor</div>
  <a class="item <?= active('/finance/reports.php',$current) ?>" href="/finance/reports.php">
    <i class="bi bi-bar-chart"></i> Raporlar
  </a>

  <div class="sec">Sistem</div>
  <a class="item <?= active('/finance/settings.php',$current) ?>" href="/finance/settings.php">
    <i class="bi bi-gear"></i> Ayarlar
  </a>
  <a class="item" href="/cashflow/dashboard.php">
    <i class="bi bi-arrow-left-right"></i> Nakit Akışı
    <span class="badge-mini">Modül</span>
  </a>
  <a class="item" href="/credit/dashboard.php">
    <i class="bi bi-bank"></i> Kredi Takibi
    <span class="badge-mini">Modül</span>
  </a>
  <a class="item" href="/modules.php">
    <i class="bi bi-grid"></i> Modül Seç
  </a>

  <div class="userbox">
    <div class="avatar"><?= strtoupper(substr($userName,0,1)) ?></div>
    <div>
      <div class="u1"><?= e($userName) ?></div>
      <div class="u2"><?= e($userRole) ?></div>
    </div>
    <a class="logout" href="/logout.php">Çıkış</a>
  </div>
</aside>
