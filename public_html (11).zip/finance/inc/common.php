<?php
declare(strict_types=1);

header("Content-Type: text/html; charset=utf-8");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

require_once __DIR__ . "/../../auth.php";

$userName = $_SESSION["user"]["name"] ?? ($_SESSION["user"]["full_name"] ?? "Kullanıcı");
$userRole = $_SESSION["user"]["role"] ?? "user";

function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8"); }
function tr_money($n){ return number_format((float)$n, 0, ",", ".") . " ₺"; }
function active($path, $current){ return $path === $current ? "active" : ""; }
?>