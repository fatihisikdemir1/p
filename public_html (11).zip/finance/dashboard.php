<?php
require_once __DIR__ . "/inc/common.php";
$current = "/finance/dashboard.php";
$pageTitle = "FinansConnect • Dashboard";

$kpi = [
  "total_income" => 275000,
  "total_expense" => 125000,
  "cash_balance" => 25000,
  "bank_balance" => 150000,
  "receivable" => 45000,
  "payable" => 24000,
  "overdue_receivable" => 12000,
];

$net = $kpi["total_income"] - $kpi["total_expense"];
?>
<?php require __DIR__ . "/inc/layout_head.php"; ?>
<?php require __DIR__ . "/inc/menu.php"; ?>

<main class="content">
  <div class="topbar">
    <div class="title">
      <h1><i class="bi bi-speedometer2"></i> CFO Dashboard</h1>
      <p>Gelir/Gider • Banka/Kasa • Alacak/Borç • Aging • 2026-02-08</p>
    </div>
    <div class="actions">
      <a class="btn" href="/finance/income.php"><i class="bi bi-plus-circle"></i> Gelir Ekle</a>
      <a class="btn" href="/finance/expense.php"><i class="bi bi-plus-circle"></i> Gider Ekle</a>
      <a class="btn ghost" href="/cashflow/dashboard.php"><i class="bi bi-arrow-left-right"></i> Nakit Akışı</a>
    </div>
  </div>

  <section class="kpis">
    <div class="kpi"><div><div class="name">Toplam Gelir</div><div class="val" style="color:var(--green)"><?= tr_money($kpi["total_income"]) ?></div></div><div class="ico"><i class="bi bi-arrow-down-left"></i></div></div>
    <div class="kpi"><div><div class="name">Toplam Gider</div><div class="val" style="color:var(--red)"><?= tr_money($kpi["total_expense"]) ?></div></div><div class="ico"><i class="bi bi-arrow-up-right"></i></div></div>
    <div class="kpi"><div><div class="name">Banka Bakiyesi</div><div class="val"><?= tr_money($kpi["bank_balance"]) ?></div></div><div class="ico"><i class="bi bi-bank2"></i></div></div>
    <div class="kpi"><div><div class="name">Nakit Bakiye</div><div class="val"><?= tr_money($kpi["cash_balance"]) ?></div></div><div class="ico"><i class="bi bi-cash"></i></div></div>
  </section>

  <section class="grid3" style="margin-bottom:14px">
    <div class="card">
      <h2><i class="bi bi-person-check"></i> Toplam Alacak</h2>
      <div class="pill"><i class="bi bi-check2-circle"></i> <?= tr_money($kpi["receivable"]) ?></div>
      <div class="note">Alacak modülündeki açık kalemlerden hesaplanır.</div>
    </div>
    <div class="card">
      <h2><i class="bi bi-building-check"></i> Toplam Borç</h2>
      <div class="pill"><i class="bi bi-info-circle"></i> <?= tr_money($kpi["payable"]) ?></div>
      <div class="note">Borç modülündeki açık kalemlerden hesaplanır.</div>
    </div>
    <div class="card">
      <h2><i class="bi bi-exclamation-triangle"></i> Gecikmiş Alacak</h2>
      <div class="pill" style="border-color:#FFD7D7;background:#FFF5F5"><i class="bi bi-exclamation-circle"></i> <span style="color:var(--red)"><?= tr_money($kpi["overdue_receivable"]) ?></span></div>
      <div class="note">Vadesi geçen açık kalemler.</div>
    </div>
  </section>

  <section class="grid2">
    <div class="card">
      <h2><i class="bi bi-graph-up"></i> Aylık Nakit Akışı (Demo)</h2>
      <table class="table">
        <thead><tr><th>Ay</th><th class="amt">Gelir</th><th class="amt">Gider</th></tr></thead>
        <tbody>
          <tr><td>Ocak</td><td class="amt"><?= tr_money(92000) ?></td><td class="amt"><?= tr_money(61000) ?></td></tr>
          <tr><td>Şubat</td><td class="amt"><?= tr_money(103000) ?></td><td class="amt"><?= tr_money(74000) ?></td></tr>
          <tr><td>Mart</td><td class="amt"><?= tr_money(80000) ?></td><td class="amt"><?= tr_money(52000) ?></td></tr>
        </tbody>
      </table>
      <div class="note">Not: Grafik DB bağlanınca otomatik oluşacak (gelir vs gider).</div>
    </div>

    <aside class="card">
      <h2><i class="bi bi-shield-check"></i> Yönetim Notu</h2>
      <div style="padding:12px;border-radius:14px;background:#F8FAFF;border:1px solid #E6E9FF">
        <?php
          $msg = ($net>=0) ? "Net sonuç pozitif. Nakit akışı stabil." : "Net sonuç negatif. Ödeme planını kontrol et.";
          $c = ($net>=0) ? "var(--green)" : "var(--red)";
        ?>
        <div style="font-weight:950;color:<?= $c ?>"><?= e($msg) ?></div>
        <div style="margin-top:8px;color:var(--muted);font-weight:800;font-size:12px">
          Yaşlandırma ekranından 90+ riskleri kontrol et.
        </div>
      </div>

      <div class="hr"></div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <a class="btn" href="/finance/payments.php"><i class="bi bi-list-check"></i> Ödeme Listesi</a>
        <a class="btn ghost" href="/finance/aging.php"><i class="bi bi-hourglass-split"></i> Aging Raporu</a>
      </div>
    </aside>
  </section>
</main>

<?php require __DIR__ . "/inc/layout_foot.php"; ?>
