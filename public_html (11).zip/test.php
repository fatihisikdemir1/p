<?php
require __DIR__ . "/auth.php";

// Görünüm tercihi
$view = $_GET['view'] ?? $_COOKIE['tasks_view'] ?? 'card';
if (isset($_GET['view'])) {
    setcookie('tasks_view', $view, time() + 86400 * 30, '/');
}

// Görevleri çek - Filtreli
if (is_super_admin()) {
    $stmt = $pdo->query("
        SELECT t.*, p.name as project_name, p.company_id,
               u1.name as assigned_user_name,
               u2.name as creator_name
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        LEFT JOIN users u1 ON t.assigned_to = u1.id
        LEFT JOIN users u2 ON t.created_by = u2.id
        ORDER BY t.created_at DESC
    ");
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} elseif (has_permission('view_all_tasks')) {
    // Company admin - tüm şirket görevleri
    $stmt = $pdo->prepare("
        SELECT t.*, p.name as project_name, p.company_id,
               u1.name as assigned_user_name,
               u2.name as creator_name
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        LEFT JOIN users u1 ON t.assigned_to = u1.id
        LEFT JOIN users u2 ON t.created_by = u2.id
        WHERE p.company_id = ?
        ORDER BY t.created_at DESC
    ");
    $stmt->execute([$companyId]);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Normal user - sadece kendine ait
    $stmt = $pdo->prepare("
        SELECT t.*, p.name as project_name, p.company_id,
               u1.name as assigned_user_name,
               u2.name as creator_name
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        LEFT JOIN users u1 ON t.assigned_to = u1.id
        LEFT JOIN users u2 ON t.created_by = u2.id
        WHERE p.company_id = ? AND (t.assigned_to = ? OR t.created_by = ?)
        ORDER BY t.created_at DESC
    ");
    $stmt->execute([$companyId, $userId, $userId]);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$statusColors = [
    'pending' => 'secondary',
    'in_progress' => 'primary',
    'completed' => 'success'
];

$priorityColors = [
    'low' => 'success',
    'medium' => 'warning',
    'high' => 'danger'
];

$statusIcons = [
    'pending' => '⏳',
    'in_progress' => '🔄',
    'completed' => '✅'
];

$priorityIcons = [
    'low' => '🟢',
    'medium' => '🟡',
    'high' => '🔴'
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Görevlerim</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); min-height: 100vh; padding: 30px; }
.page-container { max-width: 1400px; margin: 0 auto; }
.header-card { background: white; border-radius: 15px; padding: 20px 30px; margin-bottom: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.view-toggle { background: #f1f5f9; border-radius: 10px; padding: 5px; display: inline-flex; }
.view-toggle .btn { border: none; border-radius: 8px; padding: 8px 20px; }
.view-toggle .btn.active { background: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1); color: #1e3a8a; }

/* Card View */
.task-card { background: white; border-radius: 12px; padding: 20px; margin-bottom: 15px; transition: all 0.3s; cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.task-card:hover { transform: translateY(-3px); box-shadow: 0 5px 20px rgba(0,0,0,0.15); }
.task-card-title { font-size: 18px; font-weight: 600; margin-bottom: 10px; color: #1e3a8a; }
.task-card-meta { font-size: 14px; color: #64748b; }

/* List View */
.task-list-item { background: white; border-radius: 10px; padding: 15px 20px; margin-bottom: 10px; display: flex; align-items: center; justify-content: space-between; transition: all 0.3s; cursor: pointer; }
.task-list-item:hover { background: #f8fafc; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
</style>
</head>
<body>

<div class="page-container">
    
    <!-- Header -->
    <div class="header-card">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h2 class="mb-0"><i class="bi bi-check-square"></i> Görevlerim</h2>
                <small class="text-muted"><?= count($tasks) ?> görev</small>
            </div>
            <div class="col-md-4 text-center">
                <div class="view-toggle">
                    <a href="?view=card" class="btn <?= $view === 'card' ? 'active' : '' ?>">
                        <i class="bi bi-grid-3x3"></i> Kart
                    </a>
                    <a href="?view=list" class="btn <?= $view === 'list' ? 'active' : '' ?>">
                        <i class="bi bi-list-ul"></i> Liste
                    </a>
                </div>
            </div>
            <div class="col-md-4 text-end">
                <a href="task_create.php" class="btn btn-success">
                    <i class="bi bi-plus-circle"></i> Yeni Görev
                </a>
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="bi bi-house"></i> Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Tasks Content -->
    <?php if (empty($tasks)): ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="bi bi-inbox" style="font-size: 64px; color: #cbd5e1;"></i>
                <h4 class="mt-3 text-muted">Henüz görev yok</h4>
                <p class="text-muted">Yeni bir görev oluşturarak başlayın</p>
                <a href="task_create.php" class="btn btn-primary btn-lg mt-3">
                    <i class="bi bi-plus-circle"></i> İlk Görevi Oluştur
                </a>
            </div>
        </div>
    <?php else: ?>

        <?php if ($view === 'card'): ?>
            <!-- CARD VIEW -->
            <div class="row">
                <?php foreach ($tasks as $task): ?>
                <div class="col-md-4" onclick="window.location='task_detail.php?id=<?= $task['id'] ?>'">
                    <div class="task-card">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div class="task-card-title"><?= htmlspecialchars($task['title']) ?></div>
                            <span class="badge bg-<?= $priorityColors[$task['priority']] ?>">
                                <?= $priorityIcons[$task['priority']] ?>
                            </span>
                        </div>
                        
                        <div class="mb-3">
                            <span class="badge bg-<?= $statusColors[$task['status']] ?> me-1">
                                <?= $statusIcons[$task['status']] ?> 
                                <?= ucfirst($task['status']) ?>
                            </span>
                            <small class="text-muted">
                                <i class="bi bi-folder"></i> <?= htmlspecialchars($task['project_name']) ?>
                            </small>
                        </div>
                        
                        <?php if (!empty($task['description'])): ?>
                        <p class="task-card-meta mb-3" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                            <?= htmlspecialchars($task['description']) ?>
                        </p>
                        <?php endif; ?>
                        
                        <div class="task-card-meta">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <i class="bi bi-person"></i>
                                    <?= htmlspecialchars($task['assigned_user_name'] ?? 'Atanmamış') ?>
                                </div>
                                <div>
                                    <i class="bi bi-calendar"></i>
                                    <?= date('d.m.Y', strtotime($task['due_date'])) ?>
                                </div>
                            </div>
                        </div>
                        
                        <?php if ((int)$task['created_by'] === $userId): ?>
                        <div class="mt-2">
                            <span class="badge bg-info">Benim</span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

        <?php else: ?>
            <!-- LIST VIEW -->
            <div class="card">
                <div class="card-body p-0">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 40%;">Görev</th>
                                <th>Proje</th>
                                <th>Atanan</th>
                                <th>Durum</th>
                                <th>Öncelik</th>
                                <th>Bitiş</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tasks as $task): ?>
                            <tr onclick="window.location='task_detail.php?id=<?= $task['id'] ?>'" style="cursor: pointer;">
                                <td>
                                    <strong><?= htmlspecialchars($task['title']) ?></strong>
                                    <?php if ((int)$task['created_by'] === $userId): ?>
                                        <span class="badge bg-info ms-1">Benim</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <i class="bi bi-folder"></i> <?= htmlspecialchars($task['project_name']) ?>
                                    </small>
                                </td>
                                <td><?= htmlspecialchars($task['assigned_user_name'] ?? 'Atanmamış') ?></td>
                                <td>
                                    <span class="badge bg-<?= $statusColors[$task['status']] ?>">
                                        <?= $statusIcons[$task['status']] ?> <?= ucfirst($task['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?= $priorityColors[$task['priority']] ?>">
                                        <?= $priorityIcons[$task['priority']] ?>
                                    </span>
                                </td>
                                <td>
                                    <small><?= date('d.m.Y', strtotime($task['due_date'])) ?></small>
                                </td>
                                <td>
                                    <a href="task_detail.php?id=<?= $task['id'] ?>" class="btn btn-sm btn-primary" onclick="event.stopPropagation()">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

    <?php endif; ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>