<?php
declare(strict_types=1);
require __DIR__ . "/config/db.php";

$msg = "";
$err = "";
$token = $_GET["token"] ?? "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $password = trim($_POST["password"] ?? "");
    $confirmPassword = trim($_POST["confirm_password"] ?? "");
    $token = $_POST["token"] ?? "";
    
    if ($password === "" || $confirmPassword === "") {
        $err = "Tum alanlar zorunludur";
    } elseif ($password !== $confirmPassword) {
        $err = "Sifreler eslesmiyor";
    } elseif (strlen($password) < 6) {
        $err = "Sifre en az 6 karakter olmalidir";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT user_id FROM password_reset_tokens WHERE token = ? AND used = 0 AND expires_at > NOW()");
            $stmt->execute([$token]);
            $resetToken = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$resetToken) {
                $err = "Gecersiz veya suresi dolmus link";
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("UPDATE users SET password = ?, password_changed_at = NOW(), must_change_password = 0 WHERE id = ?");
                $stmt->execute([$hashedPassword, $resetToken['user_id']]);
                
                $stmt = $pdo->prepare("UPDATE password_reset_tokens SET used = 1 WHERE token = ?");
                $stmt->execute([$token]);
                
                $msg = "Sifreniz basariyla degistirildi!";
            }
        } catch (Exception $e) {
            $err = "Bir hata olustu";
        }
    }
}

if (!$msg && $token) {
    $stmt = $pdo->prepare("SELECT user_id FROM password_reset_tokens WHERE token = ? AND used = 0 AND expires_at > NOW()");
    $stmt->execute([$token]);
    if (!$stmt->fetch()) {
        $err = "Gecersiz veya suresi dolmus link";
        $token = "";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Sifre Sifirlama</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-body p-4">
                    <h3 class="text-center mb-4">Yeni Sifre Belirle</h3>
                    
                    <?php if($msg): ?>
                        <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
                        <a href="login.php" class="btn btn-primary w-100">Giris Yap</a>
                    <?php elseif($err && !$token): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($err) ?></div>
                        <a href="forgot_password.php" class="btn btn-secondary w-100">Tekrar Dene</a>
                    <?php else: ?>
                        <?php if($err): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($err) ?></div>
                        <?php endif; ?>
                        
                        <form method="post">
                            <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                            
                            <div class="mb-3">
                                <label>Yeni Sifre</label>
                                <input type="password" name="password" class="form-control" required>
                                <small class="text-muted">En az 6 karakter</small>
                            </div>
                            
                            <div class="mb-3">
                                <label>Yeni Sifre Tekrar</label>
                                <input type="password" name="confirm_password" class="form-control" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100">Sifreyi Degistir</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>