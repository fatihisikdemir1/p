<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Test</title>
</head>
<body>
<h1>BASIC TEST</h1>

<h2>1. PHP Works?</h2>
<p>✅ YES - PHP Version: <?= phpversion() ?></p>

<h2>2. Can we make a simple PDO?</h2>
<?php
try {
    $testPdo = new PDO(
        'mysql:host=localhost;dbname=u336896947_workflow;charset=utf8mb4',
        'u336896947_admin',
        '147Fatih..',  // ← Şifrenizi buraya yazın
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    echo "<p style='color:green;'>✅ DATABASE CONNECTED!</p>";
    
    $stmt = $testPdo->query("SELECT COUNT(*) FROM users");
    $count = $stmt->fetchColumn();
    echo "<p>✅ Found $count users in database</p>";
    
} catch (PDOException $e) {
    echo "<p style='color:red;'>❌ DATABASE ERROR: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>

<h2>3. Does config/db.php exist?</h2>
<?php
$configFile = __DIR__ . '/config/db.php';
if (file_exists($configFile)) {
    echo "<p>✅ File exists: $configFile</p>";
    echo "<p>Trying to load it...</p>";
    
    try {
        require $configFile;
        echo "<p style='color:green;'>✅ Config loaded successfully!</p>";
        
        if (isset($pdo)) {
            echo "<p>✅ PDO object exists</p>";
            $stmt = $pdo->query("SELECT COUNT(*) FROM users");
            $userCount = $stmt->fetchColumn();
            echo "<p>✅ Can query database: $userCount users</p>";
        } else {
            echo "<p style='color:red;'>❌ PDO object not created</p>";
        }
        
    } catch (Exception $e) {
        echo "<p style='color:red;'>❌ ERROR loading config: " . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
    }
} else {
    echo "<p style='color:red;'>❌ File not found: $configFile</p>";
}
?>

<h2>4. PHP Info (for debugging)</h2>
<p>Display Errors: <?= ini_get('display_errors') ?></p>
<p>Error Reporting: <?= error_reporting() ?></p>
<p>Current Directory: <?= getcwd() ?></p>

</body>
</html>