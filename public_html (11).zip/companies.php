<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";
require __DIR__ . "/config/rbac.php";

// Get user context from session
$companyId = (int)($_SESSION["user"]["company_id"] ?? 0);
$userRole = current_user_role();

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, "UTF-8"); }

// Super admin için companies listesi
if (is_super_admin()) {
  header("Location: super_company_list.php");
  exit;
}

// Company admin için kendi firması
if (is_company_admin()) {
  try {
    // Kendi firmasını göster
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ? LIMIT 1");
    $stmt->execute([$companyId]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$company) {
      throw new Exception("Firma bulunamadı.");
    }
    
    ?>
    <!doctype html>
    <html lang="tr">
    <head>
      <meta charset="UTF-8">
      <title>Firma Paneli</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="p-3">
    <div class="container" style="max-width:900px">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="m-0">Firma Paneli</h3>
        <a class="btn btn-secondary" href="dashboard.php">Dashboard</a>
      </div>

      <div class="card p-4">
        <h5 class="mb-3">Firma Bilgileri</h5>
        
        <div class="mb-3">
          <label class="form-label fw-bold">Firma Adı</label>
          <div class="form-control-plaintext"><?= e($company["name"] ?? "") ?></div>
        </div>
        
        <div class="mb-3">
          <label class="form-label fw-bold">Firma ID</label>
          <div class="form-control-plaintext"><?= (int)$company["id"] ?></div>
        </div>
        
        <?php if (!empty($company["created_at"])): ?>
        <div class="mb-3">
          <label class="form-label fw-bold">Oluşturulma Tarihi</label>
          <div class="form-control-plaintext"><?= date("d.m.Y H:i", strtotime($company["created_at"])) ?></div>
        </div>
        <?php endif; ?>
        
        <hr class="my-4">
        
        <h6 class="mb-3">Hızlı Erişim</h6>
        <div class="d-flex gap-2 flex-wrap">
          <a href="users.php" class="btn btn-primary">
            <i class="bi bi-people"></i> Kullanıcıları Yönet
          </a>
          <a href="projects.php" class="btn btn-primary">
            <i class="bi bi-folder"></i> Projeleri Yönet
          </a>
          <a href="dashboard.php" class="btn btn-outline-secondary">
            <i class="bi bi-house"></i> Dashboard
          </a>
        </div>
      </div>
    </div>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    </body>
    </html>
    <?php
    exit;
    
  } catch (Throwable $e) {
    http_response_code(500);
    echo "Hata: " . htmlspecialchars($e->getMessage());
    exit;
  }
}

// Diğer roller erişemez
http_response_code(403);
echo "Bu sayfaya erişim yetkiniz yok.";