<?php
declare(strict_types=1);
require_once __DIR__ . "/inc/bootstrap.php";

/**
 * FinansConnect - Nakit Akışı Dashboard (TR)
 * - "Manual yok": bu demo $events; prod'da DB/view'dan gelir.
 */

// =================== DEMO VERİ (prod: DB'den çekilecek) ===================
$events = [
  // direction: in/out/transfer, bucket: ops_in / other_in / ops_out / fin_out / tax_out / invest / transfer
  ["date"=>"2026-02-01","direction"=>"in","bucket"=>"ops_in","item"=>"Mal Satış Tahsilatları","amount"=>850000,"status"=>"realized","source"=>"Faturalar","account"=>"Banka"],
  ["date"=>"2026-02-02","direction"=>"in","bucket"=>"ops_in","item"=>"E-Ticaret / POS Tahsilatları","amount"=>120000,"status"=>"realized","source"=>"Tahsilat","account"=>"Banka"],
  ["date"=>"2026-02-05","direction"=>"in","bucket"=>"other_in","item"=>"Faiz Gelirleri","amount"=>18000,"status"=>"realized","source"=>"Banka","account"=>"Banka"],

  ["date"=>"2026-02-03","direction"=>"out","bucket"=>"ops_out","item"=>"Tedarikçi Ödemeleri","amount"=>260000,"status"=>"realized","source"=>"Ödeme Listesi","account"=>"Banka"],
  ["date"=>"2026-02-06","direction"=>"out","bucket"=>"ops_out","item"=>"Maaş Ödemeleri","amount"=>210000,"status"=>"expected","source"=>"Harcamalar","account"=>"Banka"],
  ["date"=>"2026-02-10","direction"=>"out","bucket"=>"fin_out","item"=>"Kredi Faiz Ödemeleri","amount"=>42000,"status"=>"expected","source"=>"Kredi Takibi","account"=>"Banka"],
  ["date"=>"2026-02-15","direction"=>"out","bucket"=>"tax_out","item"=>"KDV Ödemeleri","amount"=>95000,"status"=>"expected","source"=>"Beyannameler","account"=>"Banka"],

  ["date"=>"2026-02-07","direction"=>"out","bucket"=>"invest","item"=>"Yazılım / Lisans Alımları","amount"=>38000,"status"=>"realized","source"=>"Satın Alma","account"=>"Banka"],

  ["date"=>"2026-02-08","direction"=>"transfer","bucket"=>"transfer","item"=>"Bankadan Kasaya Transfer","amount"=>50000,"status"=>"realized","source"=>"Hesaplar","account"=>"Banka → Kasa"],
];

function sum_events(array $events, callable $filter): float {
  $t = 0.0;
  foreach ($events as $ev) if ($filter($ev)) $t += (float)$ev["amount"];
  return $t;
}

// KPI
$totalIn  = sum_events($events, fn($ev)=>$ev["direction"]==="in");
$totalOut = sum_events($events, fn($ev)=>$ev["direction"]==="out");
$net      = $totalIn - $totalOut;

// Tahmini dönem sonu bakiye (demo): "mevcut bakiye" + net (prod: hesap bakiyeleri + beklenen)
$currentBalance = 1250000; // demo
$estEndBalance  = $currentBalance + $net;

// Gruplama
$groups = [
  "ops_in"   => ["title"=>"Operasyonel Nakit Girişleri", "items"=>[]],
  "other_in" => ["title"=>"Diğer Nakit Girişleri",      "items"=>[]],

  "ops_out"  => ["title"=>"Operasyonel Nakit Çıkışları", "items"=>[]],
  "fin_out"  => ["title"=>"Finansal Nakit Çıkışları",    "items"=>[]],
  "tax_out"  => ["title"=>"Vergisel Nakit Çıkışları",    "items"=>[]],

  "invest"   => ["title"=>"Yatırım Kaynaklı Nakit Hareketleri", "items"=>[]],
  "transfer" => ["title"=>"İç Transferler (Neti Etkilemez)",    "items"=>[]],
];

foreach ($events as $ev) {
  $b = $ev["bucket"];
  if (isset($groups[$b])) $groups[$b]["items"][] = $ev;
}

function status_badge(string $status): array {
  return $status === "realized"
    ? ["bg"=>"#E8FFF1","fg"=>"#127D3A","text"=>"Gerçekleşti"]
    : ["bg"=>"#FFF6E5","fg"=>"#9A5B00","text"=>"Beklenen"];
}

?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FinansConnect • Nakit Akışı</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="layout">

  <!-- SOL MENÜ -->
  <aside class="sidebar">
    <div class="brand">
      <div class="t"><i class="bi bi-graph-up"></i> FinansConnect</div>
      <div class="s">Kurumsal • Süreç Odaklı • Tek Merkez</div>
    </div>

    <nav class="menu">
      <div class="sec">Menü</div>
      <a class="item" href="/modules.php"><i class="bi bi-grid-1x2"></i> Modül Seç</a>

      <div class="sec">Finans</div>
      <a class="item" href="/finance/dashboard.php"><i class="bi bi-speedometer2"></i> Ana Sayfa</a>
      <a class="item" href="#"><i class="bi bi-star"></i> Sık Kullanılanlar</a>
      <a class="item" href="#"><i class="bi bi-journal-text"></i> Defterler</a>
      <a class="item" href="#"><i class="bi bi-wallet2"></i> Harcamalar</a>
      <a class="item" href="#"><i class="bi bi-receipt"></i> Faturalar</a>
      <a class="item" href="#"><i class="bi bi-file-earmark-text"></i> Beyannameler</a>
      <a class="item" href="#"><i class="bi bi-people"></i> Alacak Takibi</a>
      <a class="item" href="/credit/dashboard.php"><i class="bi bi-bank"></i> Kredi Takibi</a>
      <a class="item active" href="/cashflow/dashboard.php"><i class="bi bi-arrow-left-right"></i> Nakit Akışı</a>
      <a class="item" href="#"><i class="bi bi-list-check"></i> Ödeme Listesi</a>
      <a class="item" href="#"><i class="bi bi-bar-chart"></i> Raporlar</a>
    </nav>
  </aside>

  <!-- İÇERİK -->
  <main class="content">

    <div class="topbar">
      <div class="title">
        <h1><i class="bi bi-arrow-left-right"></i> Nakit Akışı</h1>
        <p>Gerçekleşen & beklenen akışlar • Kaynak modül bazında izlenebilir</p>
      </div>

      <div class="filters">
        <span class="chip"><i class="bi bi-calendar3"></i> Görünüm</span>
        <select>
          <option>Günlük</option>
          <option selected>Haftalık</option>
          <option>Aylık</option>
        </select>

        <input type="date" value="2026-02-01">
        <input type="date" value="2026-02-29">

        <span class="chip"><i class="bi bi-funnel"></i> Durum</span>
        <select>
          <option selected>Gerçekleşen + Beklenen</option>
          <option>Gerçekleşen</option>
          <option>Beklenen</option>
        </select>
      </div>
    </div>

    <!-- KPI -->
    <section class="kpis">
      <div class="kpi">
        <div class="l">
          <div class="name">Toplam Nakit Girişi</div>
          <div class="val" style="color:var(--green)"><?= tr_money($totalIn) ?></div>
          <div class="tag muted">Operasyonel + Diğer</div>
        </div>
        <div class="ico"><i class="bi bi-arrow-down-left"></i></div>
      </div>

      <div class="kpi">
        <div class="l">
          <div class="name">Toplam Nakit Çıkışı</div>
          <div class="val" style="color:var(--red)"><?= tr_money($totalOut) ?></div>
          <div class="tag muted">Operasyonel + Finansal + Vergisel + Yatırım</div>
        </div>
        <div class="ico"><i class="bi bi-arrow-up-right"></i></div>
      </div>

      <div class="kpi">
        <div class="l">
          <div class="name">Net Nakit Akışı</div>
          <div class="val" style="color:<?= $net >= 0 ? 'var(--green)' : 'var(--red)' ?>"><?= tr_money($net) ?></div>
          <div class="tag muted"><?= $net >= 0 ? "Pozitif" : "Negatif / Risk" ?></div>
        </div>
        <div class="ico"><i class="bi bi-activity"></i></div>
      </div>

      <div class="kpi">
        <div class="l">
          <div class="name">Tahmini Dönem Sonu Bakiyesi</div>
          <div class="val" style="color:var(--orange)"><?= tr_money($estEndBalance) ?></div>
          <div class="tag muted">Mevcut: <?= tr_money($currentBalance) ?></div>
        </div>
        <div class="ico"><i class="bi bi-graph-up-arrow"></i></div>
      </div>
    </section>

    <section class="grid2">

      <!-- SOL: Kalemler -->
      <div class="card">
        <h2><i class="bi bi-list-ul"></i> Nakit Akış Kalemleri</h2>

        <div class="sub">
          <h3>1️⃣ Nakit Girişleri</h3>

          <?php foreach (["ops_in","other_in"] as $b): ?>
            <div style="margin-top:10px; font-weight:950; color:#0f172a;">
              <?= e($groups[$b]["title"]) ?>
            </div>

            <table>
              <thead>
                <tr>
                  <th>Kalem</th>
                  <th>Kaynak</th>
                  <th>Hesap</th>
                  <th>Durum</th>
                  <th class="amt">Tutar</th>
                </tr>
              </thead>
              <tbody>
              <?php if (empty($groups[$b]["items"])): ?>
                <tr><td colspan="5" class="muted">Kayıt yok.</td></tr>
              <?php else: ?>
                <?php foreach ($groups[$b]["items"] as $ev): $sb = status_badge($ev["status"]); ?>
                  <tr>
                    <td><?= e($ev["item"]) ?><div class="muted"><?= e($ev["date"]) ?></div></td>
                    <td><?= e($ev["source"]) ?></td>
                    <td><?= e($ev["account"]) ?></td>
                    <td><span class="badge" style="background:<?= $sb["bg"] ?>; color:<?= $sb["fg"] ?>;"><?= e($sb["text"]) ?></span></td>
                    <td class="amt" style="color:var(--green)"><?= tr_money((float)$ev["amount"]) ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
              </tbody>
            </table>
          <?php endforeach; ?>
        </div>

        <div class="sub">
          <h3>2️⃣ Nakit Çıkışları</h3>

          <?php foreach (["ops_out","fin_out","tax_out"] as $b): ?>
            <div style="margin-top:10px; font-weight:950; color:#0f172a;">
              <?= e($groups[$b]["title"]) ?>
            </div>

            <table>
              <thead>
                <tr>
                  <th>Kalem</th>
                  <th>Kaynak</th>
                  <th>Hesap</th>
                  <th>Durum</th>
                  <th class="amt">Tutar</th>
                </tr>
              </thead>
              <tbody>
              <?php if (empty($groups[$b]["items"])): ?>
                <tr><td colspan="5" class="muted">Kayıt yok.</td></tr>
              <?php else: ?>
                <?php foreach ($groups[$b]["items"] as $ev): $sb = status_badge($ev["status"]); ?>
                  <tr>
                    <td><?= e($ev["item"]) ?><div class="muted"><?= e($ev["date"]) ?></div></td>
                    <td><?= e($ev["source"]) ?></td>
                    <td><?= e($ev["account"]) ?></td>
                    <td><span class="badge" style="background:<?= $sb["bg"] ?>; color:<?= $sb["fg"] ?>;"><?= e($sb["text"]) ?></span></td>
                    <td class="amt" style="color:var(--red)"><?= tr_money((float)$ev["amount"]) ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
              </tbody>
            </table>
          <?php endforeach; ?>
        </div>

        <div class="sub">
          <h3>3️⃣ Yatırım Kaynaklı Nakit Hareketleri</h3>

          <table>
            <thead>
              <tr>
                <th>Kalem</th>
                <th>Kaynak</th>
                <th>Hesap</th>
                <th>Durum</th>
                <th class="amt">Tutar</th>
              </tr>
            </thead>
            <tbody>
            <?php if (empty($groups["invest"]["items"])): ?>
              <tr><td colspan="5" class="muted">Kayıt yok.</td></tr>
            <?php else: ?>
              <?php foreach ($groups["invest"]["items"] as $ev): $sb = status_badge($ev["status"]); ?>
                <tr>
                  <td><?= e($ev["item"]) ?><div class="muted"><?= e($ev["date"]) ?></div></td>
                  <td><?= e($ev["source"]) ?></td>
                  <td><?= e($ev["account"]) ?></td>
                  <td><span class="badge" style="background:<?= $sb["bg"] ?>; color:<?= $sb["fg"] ?>;"><?= e($sb["text"]) ?></span></td>
                  <td class="amt" style="color:var(--red)"><?= tr_money((float)$ev["amount"]) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
          </table>
        </div>

        <div class="sub">
          <h3>4️⃣ İç Transferler (Bilgi amaçlı)</h3>

          <table>
            <thead>
              <tr>
                <th>Transfer</th>
                <th>Kaynak</th>
                <th>Hesap</th>
                <th>Durum</th>
                <th class="amt">Tutar</th>
              </tr>
            </thead>
            <tbody>
            <?php if (empty($groups["transfer"]["items"])): ?>
              <tr><td colspan="5" class="muted">Kayıt yok.</td></tr>
            <?php else: ?>
              <?php foreach ($groups["transfer"]["items"] as $ev): $sb = status_badge($ev["status"]); ?>
                <tr>
                  <td><?= e($ev["item"]) ?><div class="muted"><?= e($ev["date"]) ?></div></td>
                  <td><?= e($ev["source"]) ?></td>
                  <td><?= e($ev["account"]) ?></td>
                  <td><span class="badge" style="background:<?= $sb["bg"] ?>; color:<?= $sb["fg"] ?>;"><?= e($sb["text"]) ?></span></td>
                  <td class="amt"><?= tr_money((float)$ev["amount"]) ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
          </table>
        </div>

      </div>

      <!-- SAĞ: Net özet -->
      <aside class="card">
        <h2><i class="bi bi-clipboard-data"></i> Net Nakit Akışı Özeti</h2>

        <div class="summaryRow">
          <div>Toplam Nakit Girişleri</div>
          <div style="color:var(--green)"><?= tr_money($totalIn) ?></div>
        </div>
        <div class="summaryRow">
          <div>Toplam Nakit Çıkışları</div>
          <div style="color:var(--red)"><?= tr_money($totalOut) ?></div>
        </div>
        <div class="summaryRow">
          <div>Net Nakit Akışı</div>
          <div style="color:<?= $net >= 0 ? 'var(--green)' : 'var(--red)' ?>; font-weight:950">
            <?= tr_money($net) ?>
          </div>
        </div>

        <div class="netbox">
          <div class="muted">Tahmini Dönem Sonu Bakiyesi</div>
          <div class="big" style="color:var(--orange)"><?= tr_money($estEndBalance) ?></div>
          <div class="muted" style="margin-top:6px;">Mevcut Bakiye: <?= tr_money($currentBalance) ?></div>
        </div>

        <div class="sub">
          <h3>Süreç Notları</h3>
          <div class="muted" style="line-height:1.7">
            • Nakit akışı manuel girilmez.<br>
            • Fatura, tahsilat, ödeme, kredi ve beyanname modüllerinden beslenir.<br>
            • Her kayıt: Tarih, Tutar, Giriş/Çıkış, Kaynak Modül, Banka/Kasa, Açıklama.<br>
            • Gerçekleşen ve beklenen akışlar ayrı izlenir.<br>
            • İç transferler neti etkilemez (bilgi amaçlı).
          </div>
        </div>

        <div class="sub">
          <h3>Export</h3>
          <div class="muted">PDF / Excel export sonraki adım.</div>
        </div>
      </aside>

    </section>

  </main>
</div>
</body>
</html>
