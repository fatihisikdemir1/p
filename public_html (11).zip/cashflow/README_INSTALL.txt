KURULUM (Cashflow Modülü)
========================
1) Klasörü sunucuya yükle:
   public_html/cashflow/

2) Tarayıcıdan aç:
   https://finansconnect.com/cashflow/dashboard.php

3) (Opsiyonel) DB tabloyu kur:
   cashflow/db/schema.sql

Not:
- Bu sürüm demo veri ile çalışır.
- Entegrasyon aşamasında $events yerine DB'den cash_events veya bir VIEW okunur.
