<?php
declare(strict_types=1);
/**
 * Cashflow Module Bootstrap
 * - Reuses FinansConnect session/login if available
 * - Safe fallbacks for standalone testing
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// If your main app has auth.php at public_html/auth.php, we reuse it.
$rootAuth = realpath(__DIR__ . "/../../auth.php");
if ($rootAuth && file_exists($rootAuth)) {
    require_once $rootAuth;
}

// User context (fallback)
$userName = $_SESSION["user"]["name"] ?? ($_SESSION["user"]["full_name"] ?? "Kullanıcı");
$userRole = $_SESSION["user"]["role"] ?? "user";

function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8"); }
function tr_money(float $n): string { return number_format($n, 0, ",", ".") . " ₺"; }

?>