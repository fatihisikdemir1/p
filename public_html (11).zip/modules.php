<?php
require __DIR__ . "/auth.php";

// Kullanıcı bilgileri
$userName = $_SESSION["user"]["name"] ?? "Kullanıcı";
$userRole = $_SESSION["user"]["role"] ?? "user";

function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8"); }
?>
<?php
$pageTitle = 'FinansConnect • Modüller';
$breadcrumbs = array(array('label' => 'FinansConnect', 'href' => '/dashboard.php'), array('label' => 'Modül Seç', 'href' => null));
$extraHead = '<style>
:root{
      --navy:#0B2A55;
      --bg:#F4F7FB;
      --card:#FFFFFF;
      --muted:#6B7280;
      --shadow:0 10px 30px rgba(16,24,40,.08);
      --radius:18px;
      --btn:#0B2A55;
      --btnHover:#0A2448;
    }
    *{ box-sizing:border-box; }
    body{
      margin:0;
      font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      background: var(--bg);
      color:#0f172a;
    }
    .topbar{
      background: linear-gradient(180deg, #0B2A55 0%, #072245 100%);
      height: 86px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding: 0 26px;
      color:#fff;
    }
    .brand{
      display:flex; flex-direction:column; gap:4px;
    }
    .brand .title{
      font-size:22px; font-weight:800; letter-spacing:.2px;
    }
    .brand .sub{
      font-size:13px; opacity:.85;
    }
    .userbox{
      display:flex; align-items:center; gap:14px;
    }
    .avatar{
      width:44px; height:44px; border-radius:14px;
      background: rgba(255,255,255,.14);
      display:flex; align-items:center; justify-content:center;
      font-weight:900;
    }
    .usertext{
      display:flex; flex-direction:column; line-height:1.1;
      align-items:flex-start;
    }
    .usertext .role{ font-weight:800; }
    .usertext .user{ font-size:13px; opacity:.85; margin-top:4px; }
    .logout{
      border:1px solid rgba(255,255,255,.25);
      background: rgba(255,255,255,.06);
      color:#fff;
      padding: 10px 14px;
      border-radius:12px;
      font-weight:800;
      text-decoration:none;
    }
    .logout:hover{ background: rgba(255,255,255,.12); }

    .wrap{
      max-width: 1180px;
      margin: 0 auto;
      padding: 26px;
    }
    .chips{
      display:flex; gap:10px; flex-wrap:wrap;
      justify-content:center;
      margin: 18px 0 22px;
    }
    .chip{
      background:#E9EEF7;
      color:#334155;
      padding:8px 12px;
      border-radius:999px;
      font-weight:800;
      font-size:12px;
    }
    h2{
      margin: 0 0 14px;
      font-size: 22px;
      font-weight: 900;
      color:#334155;
    }
    .grid{
      display:grid;
      grid-template-columns: repeat(2, minmax(0,1fr));
      gap: 22px;
    }
    .card{
      background: var(--card);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      padding: 22px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      min-height: 124px;
    }
    .left{
      display:flex; align-items:flex-start; gap:16px;
    }
    .ico{
      width:44px; height:44px;
      border-radius: 12px;
      background:#F1F5FF;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:22px;
    }
    .card h3{
      margin:0;
      font-size:18px;
      font-weight:900;
    }
    .card p{
      margin:6px 0 0;
      color: var(--muted);
      font-weight:700;
      font-size: 13px;
    }
    .btn{
      display:inline-flex;
      align-items:center;
      gap:10px;
      background: var(--btn);
      color:#fff;
      padding: 10px 14px;
      border-radius: 14px;
      font-weight:900;
      text-decoration:none;
      min-width: 84px;
      justify-content:center;
    }
    .btn:hover{ background: var(--btnHover); }
    .note{
      margin-top: 14px;
      color:#64748b;
      font-weight:700;
      font-size: 13px;
    }
    @media(max-width: 860px){
      .grid{ grid-template-columns: 1fr; }
      .topbar{ height:auto; padding: 16px; gap:12px; flex-direction:column; align-items:flex-start; }
      .userbox{ width:100%; justify-content:space-between; }
    }
</style>';
require __DIR__ . "/shared/layout_head.php";
require __DIR__ . "/menu.php";
?>
<main class="content">
  <div class="topbar">
    <div class="crumbs">
      <?php
        if (!empty($breadcrumbs)) {
          $last = count($breadcrumbs)-1;
          foreach($breadcrumbs as $i=>$c){
            $lab = $c['label'] ?? '';
            $href = $c['href'] ?? '';
            if ($href) {
              echo '<a href="'.e($href).'">'.e($lab).'</a>';
            } else {
              echo '<span style="font-weight:950">'.e($lab).'</span>';
            }
            if ($i !== $last) echo '<span class="sep">/</span>';
          }
        }
      ?>
    </div>
    <div style="display:flex;gap:10px;align-items:center;flex:1;justify-content:flex-end">
      <form class="search" method="get" action="/task.php" style="max-width:680px">
        <i class="bi bi-search"></i>
        <input name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Arama: görev, proje, kullanıcı…">
      </form>
      <span class="pill"><i class="bi bi-person-circle"></i> <?= e($_SESSION['user']['name'] ?? 'Kullanıcı') ?></span>
    </div>
  </div>

  <div style="height:14px"></div>

  <div class="topbar">
    <div class="brand">
      <div class="title">FinansConnect</div>
      <div class="sub">Kurumsal • Süreç Odaklı • Tek Merkez Finans Platformu</div>
    </div>

    <div class="userbox">
      <div class="avatar"><?= strtoupper(substr($userName,0,1)) ?></div>
      <div class="usertext">
        <div class="role"><?= ($userRole === "super_admin" ? "Super Admin" : e($userRole)) ?></div>
        <div class="user"><?= e($userName) ?></div>
      </div>
      <a class="logout" href="/logout.php">Çıkış</a>
    </div>
  </div>

  <div class="wrap">
    <div class="chips">
      <span class="chip">Tek tıkla modüle giriş</span>
      <span class="chip">Yetkiye göre erişim</span>
      <span class="chip">Audit + raporlama için hazır mimari</span>
    </div>

    <h2>Modül Seç</h2>

    <div class="grid">

      <!-- Finans -->
      <div class="card">
        <div class="left">
          <div class="ico">💼</div>
          <div>
            <h3>Finans</h3>
            <p>Gelir, gider, alacak/borç, nakit akışı ve CFO paneli</p>
          </div>
        </div>
        <a class="btn" href="/finance/dashboard.php">Aç <i class="bi bi-arrow-right"></i></a>
      </div>

      <!-- Muhasebe -->
      <div class="card">
        <div class="left">
          <div class="ico">🧾</div>
          <div>
            <h3>Muhasebe</h3>
            <p>Hesap planı, yevmiye fişleri, faturalar ve KDV izleme</p>
          </div>
        </div>
        <a class="btn" href="/accounting/dashboard.php">Aç <i class="bi bi-arrow-right"></i></a>
      </div>

      <!-- Satın Alma -->
      <div class="card">
        <div class="left">
          <div class="ico">🛒</div>
          <div>
            <h3>Satın Alma</h3>
            <p>PR → RFQ → PO → GRN → Fatura süreç yönetimi</p>
          </div>
        </div>
        <a class="btn" href="/procurement/views/dashboard.php">Aç <i class="bi bi-arrow-right"></i></a>
      </div>

      <!-- İş Takip -->
      <div class="card">
        <div class="left">
          <div class="ico">✅</div>
          <div>
            <h3>İş Takip</h3>
            <p>Projeler, görevler, kullanıcılar ve kontrol paneli</p>
          </div>
        </div>
        <a class="btn" href="/dashboard.php">Aç <i class="bi bi-arrow-right"></i></a>
      </div>

      <!-- ✅ Kredi Takip -->
      <div class="card">
        <div class="left">
          <div class="ico">🏦</div>
          <div>
            <h3>Kredi Takip</h3>
            <p>Kredi listesi, taksit planı, gecikmeler ve risk paneli</p>
          </div>
        </div>
        <a class="btn" href="/credit/dashboard.php">Aç <i class="bi bi-arrow-right"></i></a>
      </div>

      <!-- ✅ Nakit Akışı (EKLENDİ) -->
      <div class="card">
        <div class="left">
          <div class="ico">🔄</div>
          <div>
            <h3>Nakit Akışı</h3>
            <p>Giriş/çıkış, net akış, tahmini bakiye ve kategori bazlı görünüm</p>
          </div>
        </div>
        <a class="btn" href="/cashflow/dashboard.php">Aç <i class="bi bi-arrow-right"></i></a>
      </div>

    </div>

    <div class="note">Not: Eğer bir modül 404 verirse, sadece bu dosyadaki URL’yi güncellememiz yeterli.</div>
  </div>
</main>
<?php require __DIR__ . "/shared/layout_foot.php"; ?>

