<?php
// config/rbac.php

function normalize_role(string $role): string {
    $role = strtolower(trim($role));
    
    $validRoles = ['super_admin', 'company_admin', 'user'];
    
    if (in_array($role, $validRoles)) {
        return $role;
    }
    
    return 'user';
}