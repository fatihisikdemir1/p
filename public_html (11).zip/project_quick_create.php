<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

$role = (string)($_SESSION["user"]["role"] ?? "member");
if ($role === "member") { http_response_code(403); exit("Bu alana erişim yok"); }

$isSuper = in_array($role, ["super_admin","admin"], true);
$companyId = (int)($_SESSION["user"]["company_id"] ?? 0);
$userId = (int)($_SESSION["user"]["id"] ?? 0);

$err = "";

if($_SERVER["REQUEST_METHOD"]==="POST"){
  $name = trim((string)($_POST["name"] ?? ""));
  $desc = trim((string)($_POST["description"] ?? ""));
  $cid  = $isSuper ? (int)($_POST["company_id"] ?? 0) : $companyId;

  if($name===""){ $err="Proje adı zorunlu"; }
  else{
    $pdo->prepare("INSERT INTO projects(company_id,name,description,created_by,created_at) VALUES(?,?,?,?,NOW())")
        ->execute([$cid>0?$cid:null,$name,$desc,$userId]);
    header("Location: projects.php");
    exit;
  }
}

$companies=[];
if($isSuper){
  try{ $companies = $pdo->query("SELECT id,name FROM companies ORDER BY name")->fetchAll(PDO::FETCH_ASSOC); }catch(Throwable $e){ $companies=[]; }
}
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Proje Ekle</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#0b1f4d;color:#fff;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif}
.cardx{background:rgba(255,255,255,.10);border:1px solid rgba(255,255,255,.14);border-radius:18px}
.form-control,.form-select{border-radius:14px !important}
</style>
</head>
<body class="p-3">
<div class="container" style="max-width:860px">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h3 class="m-0">Proje Ekle</h3>
      <div style="opacity:.85">Hızlı proje oluştur</div>
    </div>
    <a class="btn btn-outline-light" style="border-radius:14px;font-weight:800" href="projects.php">Projeler</a>
  </div>

  <?php if($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>

  <div class="cardx p-3">
    <form method="post">
      <?php if($isSuper): ?>
        <div class="mb-3">
          <label class="form-label fw-bold">Firma</label>
          <select class="form-select" name="company_id" required>
            <option value="">Seç</option>
            <?php foreach($companies as $c): ?>
              <option value="<?= (int)$c["id"] ?>"><?= htmlspecialchars((string)$c["name"]) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      <?php endif; ?>

      <div class="mb-3">
        <label class="form-label fw-bold">Proje Adı *</label>
        <input class="form-control" name="name" required>
      </div>

      <div class="mb-3">
        <label class="form-label fw-bold">Açıklama</label>
        <textarea class="form-control" rows="4" name="description"></textarea>
      </div>

      <button class="btn btn-light" style="border-radius:14px;font-weight:900">Kaydet</button>
    </form>
  </div>
</div>
</body>
</html>
