<?php
require "auth.php";
require "db.php";

header("Content-Type: application/json; charset=utf-8");

$userId = (int)($_SESSION["user"]["id"] ?? 0);
$role   = (string)($_SESSION["user"]["role"] ?? "member");

$taskId = (int)($_POST["task_id"] ?? 0);
$text   = trim((string)($_POST["message"] ?? ""));
$taggedUserId = (int)($_POST["tagged_user_id"] ?? 0);

if ($taskId <= 0 || $text === "") {
  echo json_encode(["ok"=>false,"error"=>"Eksik veri"]);
  exit;
}

/* Görev + yetki */
$stmt = $pdo->prepare("SELECT id, assigned_to FROM tasks WHERE id=?");
$stmt->execute([$taskId]);
$task = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$task) {
  echo json_encode(["ok"=>false,"error"=>"Görev yok"]);
  exit;
}

if (in_array($role, ["member","viewer"], true) && (int)$task["assigned_to"] !== $userId) {
  echo json_encode(["ok"=>false,"error"=>"Yetkin yok"]);
  exit;
}
if ($role === "viewer") {
  echo json_encode(["ok"=>false,"error"=>"Gözlemci mesaj gönderemez"]);
  exit;
}

/* Yorum ekle */
try {
  $ins = $pdo->prepare("INSERT INTO task_comments (task_id, user_id, message, tagged_user_id, created_at) VALUES (?, ?, ?, ?, NOW())");
  $ins->execute([$taskId, $userId, $text, $taggedUserId > 0 ? $taggedUserId : null]);
  $commentId = (int)$pdo->lastInsertId();
} catch (Throwable $e) {
  echo json_encode(["ok"=>false,"error"=>"Veritabanı hatası: " . $e->getMessage()]);
  exit;
}

/* User name */
$u = $pdo->prepare("SELECT name FROM users WHERE id=?");
$u->execute([$userId]);
$uName = (string)($u->fetchColumn() ?: "Kullanıcı");

/* Tagged user name if exists */
$taggedName = "";
if ($taggedUserId > 0) {
  $tu = $pdo->prepare("SELECT name FROM users WHERE id=?");
  $tu->execute([$taggedUserId]);
  $taggedName = (string)($tu->fetchColumn() ?: "");
}

$html = '<div class="cm-item">
  <div class="cm-head">
    <div class="cm-name">
      '.htmlspecialchars($uName);
      
if ($taggedName) {
  $html .= ' <span class="cm-tag"><i class="bi bi-at"></i>'.htmlspecialchars($taggedName).'</span>';
}

$html .= '
    </div>
    <div class="cm-time">Şimdi</div>
  </div>
  <div class="cm-msg">'.nl2br(htmlspecialchars($text)).'</div>
</div>';

echo json_encode(["ok"=>true,"html"=>$html]);