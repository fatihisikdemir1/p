<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";
require __DIR__ . "/config/rbac.php";

require_role(["super_admin"]);

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, "UTF-8"); }

$err = "";

// kolon tespiti (companies)
$cCols = [];
try {
  $rs = $pdo->query("DESCRIBE companies");
  foreach ($rs->fetchAll(PDO::FETCH_ASSOC) as $r) $cCols[$r["Field"]] = true;
} catch (Throwable $e) {
  http_response_code(500);
  echo "companies tablosu okunamadı: " . e($e->getMessage());
  exit;
}

// kolon tespiti (users)
$uCols = [];
try {
  $rs = $pdo->query("DESCRIBE users");
  foreach ($rs->fetchAll(PDO::FETCH_ASSOC) as $r) $uCols[$r["Field"]] = true;
} catch (Throwable $e) {
  http_response_code(500);
  echo "users tablosu okunamadı: " . e($e->getMessage());
  exit;
}

$hasCompanyCreated = isset($cCols["created_at"]);
$hasCompanyActive  = isset($cCols["is_active"]);

$hasUserCompany    = isset($uCols["company_id"]);
$hasUserActive     = isset($uCols["is_active"]);
$passCol           = isset($uCols["password_hash"]) ? "password_hash" : (isset($uCols["password"]) ? "password" : null);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $c_name      = trim((string)($_POST["company_name"] ?? ""));
  $tax_office  = trim((string)($_POST["tax_office"] ?? ""));
  $tax_no      = trim((string)($_POST["tax_no"] ?? ""));
  $c_phone     = trim((string)($_POST["company_phone"] ?? ""));
  $c_email     = trim((string)($_POST["company_email"] ?? ""));
  $c_address   = trim((string)($_POST["company_address"] ?? ""));

  $a_name      = trim((string)($_POST["admin_name"] ?? ""));
  $a_surname   = trim((string)($_POST["admin_surname"] ?? ""));
  $a_email     = trim((string)($_POST["admin_email"] ?? ""));
  $a_pass      = (string)($_POST["admin_password"] ?? "");

  if ($c_name === "" || $a_name === "" || $a_surname === "" || $a_email === "" || $a_pass === "") {
    $err = "Zorunlu alanlar boş.";
  } elseif (!$passCol) {
    $err = "users tablosunda password/password_hash kolonu yok.";
  } else {
    try {
      $pdo->beginTransaction();

      // 1) company create (kolon varsa yaz)
      $fields = ["name"];
      $vals   = [":name"];
      $bind   = [":name"=>$c_name];

      if (isset($cCols["tax_office"])) { $fields[]="tax_office"; $vals[]=":tax_office"; $bind[":tax_office"]=($tax_office!==""?$tax_office:null); }
      if (isset($cCols["tax_no"]))     { $fields[]="tax_no";     $vals[]=":tax_no";     $bind[":tax_no"]=($tax_no!==""?$tax_no:null); }
      if (isset($cCols["phone"]))      { $fields[]="phone";      $vals[]=":phone";      $bind[":phone"]=($c_phone!==""?$c_phone:null); }
      if (isset($cCols["email"]))      { $fields[]="email";      $vals[]=":email";      $bind[":email"]=($c_email!==""?$c_email:null); }
      if (isset($cCols["address"]))    { $fields[]="address";    $vals[]=":address";    $bind[":address"]=($c_address!==""?$c_address:null); }

      if ($hasCompanyCreated) { $fields[]="created_at"; $vals[]="NOW()"; }
      if ($hasCompanyActive)  { $fields[]="is_active";  $vals[]="1"; }

      $sql = "INSERT INTO companies (".implode(",",$fields).") VALUES (".implode(",",$vals).")";
      $pdo->prepare($sql)->execute($bind);

      $companyIdNew = (int)$pdo->lastInsertId();

      // 2) email unique kontrol
      $chk = $pdo->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
      $chk->execute([$a_email]);
      if ($chk->fetch()) {
        throw new RuntimeException("Bu e-posta zaten kayıtlı.");
      }

      // 3) create company_admin user
      $fullName = trim($a_name . " " . $a_surname);
      $hash = password_hash($a_pass, PASSWORD_BCRYPT);

      $uFields = ["role","name","email",$passCol];
      $uVals   = [":role",":name",":email",":ph"];
      $uBind   = [
        ":role"=>"company_admin",
        ":name"=>$fullName,
        ":email"=>$a_email,
        ":ph"=>$hash
      ];

      if ($hasUserCompany) { $uFields[]="company_id"; $uVals[]=":cid"; $uBind[":cid"]=$companyIdNew; }
      if ($hasUserActive)  { $uFields[]="is_active";  $uVals[]="1"; }

      $uSql = "INSERT INTO users (".implode(",",$uFields).") VALUES (".implode(",",$uVals).")";
      $pdo->prepare($uSql)->execute($uBind);

      $pdo->commit();

      header("Location: super_company_list.php");
      exit;

    } catch (Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $err = $e->getMessage();
    }
  }
}
?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Super Admin · Firma Ekle</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-3">
<div class="container" style="max-width:980px">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="m-0">Firma Ekle (Super Admin)</h3>
    <a class="btn btn-outline-dark" href="super_company_list.php">Firma Listesi</a>
  </div>

  <?php if($err): ?>
    <div class="alert alert-danger"><?= e($err) ?></div>
  <?php endif; ?>

  <form method="post" class="row g-3">
    <div class="col-12"><h5 class="mt-2">Firma Bilgileri</h5></div>

    <div class="col-md-6">
      <label class="form-label">Firma Adı *</label>
      <input name="company_name" class="form-control" required>
    </div>
    <?php if(isset($cCols["tax_office"])): ?>
      <div class="col-md-3">
        <label class="form-label">Vergi Dairesi</label>
        <input name="tax_office" class="form-control">
      </div>
    <?php endif; ?>
    <?php if(isset($cCols["tax_no"])): ?>
      <div class="col-md-3">
        <label class="form-label">Vergi No</label>
        <input name="tax_no" class="form-control">
      </div>
    <?php endif; ?>
    <?php if(isset($cCols["phone"])): ?>
      <div class="col-md-4">
        <label class="form-label">Telefon</label>
        <input name="company_phone" class="form-control">
      </div>
    <?php endif; ?>
    <?php if(isset($cCols["email"])): ?>
      <div class="col-md-4">
        <label class="form-label">E-posta</label>
        <input name="company_email" class="form-control" type="email">
      </div>
    <?php endif; ?>
    <?php if(isset($cCols["address"])): ?>
      <div class="col-md-4">
        <label class="form-label">Adres</label>
        <input name="company_address" class="form-control">
      </div>
    <?php endif; ?>

    <div class="col-12"><hr></div>
    <div class="col-12"><h5>Company Admin (İlk Yönetici)</h5></div>

    <div class="col-md-3">
      <label class="form-label">Ad *</label>
      <input name="admin_name" class="form-control" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Soyad *</label>
      <input name="admin_surname" class="form-control" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">E-posta *</label>
      <input name="admin_email" class="form-control" type="email" required>
    </div>
    <div class="col-md-3">
      <label class="form-label">Şifre *</label>
      <input name="admin_password" class="form-control" type="password" required>
    </div>

    <div class="col-12">
      <button class="btn btn-primary">Kaydet</button>
    </div>
  </form>
</div>
</body>
</html>
