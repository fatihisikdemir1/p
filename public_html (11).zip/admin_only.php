<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) session_start();

$role = $_SESSION["user"]["role"] ?? "member";

if (!in_array($role, ["admin", "super_admin"], true)) {
    header("Location: dashboard.php?err=yetki");
    exit;
}
