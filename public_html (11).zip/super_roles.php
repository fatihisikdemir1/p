<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require __DIR__ . "/auth.php";

if (!is_super_admin()) {
    die("Bu sayfaya erişim yetkiniz yok.");
}

$msg = "";
$err = "";

// Rol oluşturma
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['create_role'])) {
    try {
        $roleName = trim($_POST['role_name'] ?? "");
        $roleSlug = trim($_POST['role_slug'] ?? "");
        $permissions = $_POST['permissions'] ?? [];
        
        if (empty($roleName) || empty($roleSlug)) {
            throw new Exception("Rol adı ve slug zorunludur");
        }
        
        // Slug kontrolü
        $stmt = $pdo->prepare("SELECT id FROM roles WHERE role_slug = ?");
        $stmt->execute([$roleSlug]);
        if ($stmt->fetch()) {
            throw new Exception("Bu slug zaten kullanılıyor");
        }
        
        $permissionsJson = json_encode($permissions);
        
        $stmt = $pdo->prepare("
            INSERT INTO roles (role_name, role_slug, permissions, created_at)
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$roleName, $roleSlug, $permissionsJson]);
        
        $msg = "✅ Rol başarıyla oluşturuldu!";
        
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Rol düzenleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['edit_role'])) {
    try {
        $roleId = (int)($_POST['role_id'] ?? 0);
        $roleName = trim($_POST['role_name'] ?? "");
        $permissions = $_POST['permissions'] ?? [];
        
        if (empty($roleName)) {
            throw new Exception("Rol adı zorunludur");
        }
        
        $permissionsJson = json_encode($permissions);
        
        $stmt = $pdo->prepare("
            UPDATE roles 
            SET role_name = ?, permissions = ?
            WHERE id = ?
        ");
        $stmt->execute([$roleName, $permissionsJson, $roleId]);
        
        $msg = "✅ Rol güncellendi!";
        
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Rol silme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete_role'])) {
    try {
        $roleId = (int)($_POST['role_id'] ?? 0);
        
        // Kullanıcı kontrolü
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role_id = ?");
        $stmt->execute([$roleId]);
        $userCount = $stmt->fetchColumn();
        
        if ($userCount > 0) {
            throw new Exception("Bu role bağlı $userCount kullanıcı var");
        }
        
        $stmt = $pdo->prepare("DELETE FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        
        $msg = "✅ Rol silindi!";
        
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Rolleri çek
$stmt = $pdo->query("
    SELECT r.*,
           (SELECT COUNT(*) FROM users WHERE role_id = r.id) as user_count
    FROM roles r
    ORDER BY r.role_name
");
$roles = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Tüm yetkiler
$allPermissions = [
    'manage_users' => 'Kullanıcı Yönetimi',
    'manage_roles' => 'Rol Yönetimi',
    'view_all_tasks' => 'Tüm Görevleri Görüntüle',
    'manage_projects' => 'Proje Yönetimi',
    'manage_companies' => 'Firma Yönetimi',
    'view_reports' => 'Raporları Görüntüle',
    'manage_settings' => 'Ayarları Yönet'
];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Rol Yönetimi - Super Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 30px; }
.page-container { max-width: 1200px; margin: 0 auto; }
.header-card { background: white; border-radius: 15px; padding: 20px 30px; margin-bottom: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.content-card { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.role-card { background: white; border: 2px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 15px; transition: all 0.3s; }
.role-card:hover { border-color: #667eea; box-shadow: 0 5px 20px rgba(102, 126, 234, 0.2); }
.permission-badge { background: #eff6ff; color: #2563eb; padding: 6px 12px; border-radius: 20px; font-size: 12px; margin: 4px; display: inline-block; }
</style>
</head>
<body>

<div class="page-container">
    
    <div class="header-card">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h2 class="mb-0" style="color: #667eea;"><i class="bi bi-shield-lock"></i> Rol Yönetimi</h2>
                <small class="text-muted"><?= count($roles) ?> rol</small>
            </div>
            <div class="col-md-4 text-center">
                <span class="badge bg-danger" style="font-size: 14px;">SUPER ADMIN PANEL</span>
            </div>
            <div class="col-md-4 text-end">
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createModal">
                    <i class="bi bi-plus-circle"></i> Yeni Rol
                </button>
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="bi bi-house"></i> Dashboard
                </a>
            </div>
        </div>
    </div>

    <?php if ($msg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $msg ?>
        </div>
    <?php endif; ?>
    
    <?php if ($err): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $err ?>
        </div>
    <?php endif; ?>

    <div class="content-card">
        <h4 class="mb-4"><i class="bi bi-shield-check"></i> Roller ve Yetkiler</h4>

        <?php foreach ($roles as $role): ?>
        <div class="role-card">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <h5 style="color: #667eea;">
                        <i class="bi bi-shield"></i> <?= htmlspecialchars($role['role_name']) ?>
                    </h5>
                    <small class="text-muted">
                        <code><?= htmlspecialchars($role['role_slug']) ?></code>
                    </small><br>
                    <span class="badge bg-info mt-2"><?= (int)$role['user_count'] ?> kullanıcı</span>
                </div>

                <div class="col-md-6">
                    <?php 
                    $perms = json_decode($role['permissions'] ?? '[]', true);
                    if (empty($perms)): 
                    ?>
                        <span class="text-muted">Yetki yok</span>
                    <?php else: ?>
                        <?php foreach ($perms as $perm): ?>
                            <span class="permission-badge">
                                <i class="bi bi-check-circle"></i> <?= $allPermissions[$perm] ?? $perm ?>
                            </span>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div class="col-md-2 text-end">
                    <button class="btn btn-sm btn-warning" onclick='editRole(<?= json_encode($role) ?>)'>
                        <i class="bi bi-pencil"></i>
                    </button>
                    <?php if ((int)$role['user_count'] === 0): ?>
                    <button class="btn btn-sm btn-danger" onclick="confirmDelete(<?= $role['id'] ?>, '<?= htmlspecialchars($role['role_name'], ENT_QUOTES) ?>')">
                        <i class="bi bi-trash"></i>
                    </button>
                    <?php else: ?>
                    <button class="btn btn-sm btn-secondary" disabled title="Kullanıcı var">
                        <i class="bi bi-trash"></i>
                    </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

</div>

<!-- Create Modal -->
<div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
                <h5 class="modal-title"><i class="bi bi-shield-plus"></i> Yeni Rol Oluştur</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Rol Adı *</label>
                            <input type="text" name="role_name" class="form-control" required placeholder="Örn: Proje Yöneticisi">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Slug *</label>
                            <input type="text" name="role_slug" class="form-control" required placeholder="Örn: project_manager">
                            <small class="text-muted">Küçük harf, alt çizgi kullanın</small>
                        </div>
                    </div>

                    <hr>

                    <label class="form-label fw-bold">Yetkiler</label>
                    <div class="row">
                        <?php foreach ($allPermissions as $permSlug => $permName): ?>
                        <div class="col-md-6 mb-2">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="permissions[]" value="<?= $permSlug ?>" id="perm_<?= $permSlug ?>">
                                <label class="form-check-label" for="perm_<?= $permSlug ?>">
                                    <?= $permName ?>
                                </label>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="create_role" class="btn btn-success">
                        <i class="bi bi-check-circle"></i> Oluştur
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Rol Düzenle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="role_id" id="edit_role_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Rol Adı *</label>
                        <input type="text" name="role_name" id="edit_role_name" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Slug</label>
                        <input type="text" id="edit_role_slug" class="form-control" disabled>
                        <small class="text-muted">Slug değiştirilemez</small>
                    </div>

                    <hr>

                    <label class="form-label fw-bold">Yetkiler</label>
                    <div class="row" id="editPermissionsArea">
                        <?php foreach ($allPermissions as $permSlug => $permName): ?>
                        <div class="col-md-6 mb-2">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="permissions[]" value="<?= $permSlug ?>" id="edit_perm_<?= $permSlug ?>">
                                <label class="form-check-label" for="edit_perm_<?= $permSlug ?>">
                                    <?= $permName ?>
                                </label>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="edit_role" class="btn btn-warning">
                        <i class="bi bi-check-circle"></i> Güncelle
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="bi bi-exclamation-triangle"></i> Rolü Sil</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p><strong id="roleNameToDelete"></strong> rolünü silmek istediğinize emin misiniz?</p>
                <p class="text-danger mb-0"><i class="bi bi-exclamation-triangle"></i> Bu işlem geri alınamaz!</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="role_id" id="roleIdToDelete">
                    <button type="submit" name="delete_role" class="btn btn-danger">
                        <i class="bi bi-trash"></i> Evet, Sil
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function editRole(role) {
    document.getElementById('edit_role_id').value = role.id;
    document.getElementById('edit_role_name').value = role.role_name;
    document.getElementById('edit_role_slug').value = role.role_slug;
    
    // Yetkileri işaretle
    const permissions = JSON.parse(role.permissions || '[]');
    document.querySelectorAll('#editPermissionsArea input[type="checkbox"]').forEach(cb => {
        cb.checked = permissions.includes(cb.value);
    });
    
    const modal = new bootstrap.Modal(document.getElementById('editModal'));
    modal.show();
}

function confirmDelete(roleId, roleName) {
    document.getElementById('roleIdToDelete').value = roleId;
    document.getElementById('roleNameToDelete').textContent = roleName;
    
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    modal.show();
}
</script>
</body>
</html>