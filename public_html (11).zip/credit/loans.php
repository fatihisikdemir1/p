<?php
$title = 'Kredi Listesi';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';
require_once __DIR__ . '/inc/services.php';

if (!credit_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);
$userId = (int)($_SESSION['user']['id'] ?? 0);
$msg=null; $err=null;

function audit(PDO $pdo, int $companyId, int $userId, string $action, string $etype, int $eid, $old, $new): void {
  $ip = $_SERVER['REMOTE_ADDR'] ?? null;
  $pdo->prepare("INSERT INTO credit_audit_logs (company_id,user_id,action,entity_type,entity_id,ip,old_json,new_json,created_at)
                 VALUES (?,?,?,?,?,?,?,?,NOW())")
      ->execute([$companyId,$userId,$action,$etype,$eid,$ip,$old?json_encode($old,JSON_UNESCAPED_UNICODE):null,$new?json_encode($new,JSON_UNESCAPED_UNICODE):null]);
}
function export_event(PDO $pdo, int $companyId, int $userId, string $etype, int $eid, array $payload): void {
  $pdo->prepare("INSERT INTO credit_accounting_exports (company_id,entity_type,entity_id,export_status,payload_json,created_by,created_at)
                 VALUES (?,?,?,'pending',?,?,NOW())")
      ->execute([$companyId,$etype,$eid,json_encode($payload,JSON_UNESCAPED_UNICODE),$userId]);
}

if ($_SERVER['REQUEST_METHOD']==='POST' && credit_can_edit()) {
  try{
    $bank = trim((string)($_POST['bank_name'] ?? ''));
    $loan_type = $_POST['loan_type'] ?? 'ticari';
    $principal = (float)($_POST['principal'] ?? 0);
    $annual_rate = (float)($_POST['annual_rate'] ?? 0);
    $term = (int)($_POST['term_months'] ?? 0);
    $payment_type = $_POST['payment_type'] ?? 'equal';
    $start_date = $_POST['start_date'] ?? date('Y-m-d');
    $first_due = $_POST['first_due_date'] ?? date('Y-m-d');
    $desc = trim((string)($_POST['description'] ?? '')) ?: null;

    if ($bank==='') throw new Exception("Banka adı zorunlu.");
    if ($principal<=0) throw new Exception("Kredi tutarı > 0 olmalı.");
    if ($term<=0) throw new Exception("Vade (ay) > 0 olmalı.");

    $monthly = ($payment_type==='equal') ? calc_equal_monthly_installment($principal,$annual_rate,$term) : 0.0;
    $sched = build_schedule($principal,$annual_rate,$term,$payment_type,$first_due);

    $total_interest = 0.0;
    foreach($sched as $s){ $total_interest += (float)$s['interest_part']; }
    $total_interest = round($total_interest, 2);

    $pdo->beginTransaction();
    $pdo->prepare("INSERT INTO credit_loans
      (company_id,bank_name,loan_type,principal,currency,annual_rate,term_months,payment_type,start_date,first_due_date,status,monthly_installment,remaining_principal,total_interest_expected,description,created_by,created_at)
      VALUES (?,?,?,?, 'TRY', ?,?,?,?,?,'ongoing',?,?,?, ?,?,NOW())")
      ->execute([$companyId,$bank,$loan_type,$principal,$annual_rate,$term,$payment_type,$start_date,$first_due,$monthly,$principal,$total_interest,$desc,$userId]);
    $loanId = (int)$pdo->lastInsertId();

    $ins = $pdo->prepare("INSERT INTO credit_installments
      (loan_id,installment_no,due_date,principal_part,interest_part,installment_total,paid_amount,paid_date,status,locked,created_at)
      VALUES (?,?,?,?,?,?,0,NULL,'pending',0,NOW())");
    foreach($sched as $row){
      $ins->execute([$loanId,$row['installment_no'],$row['due_date'],$row['principal_part'],$row['interest_part'],$row['installment_total']]);
    }

    $payload = [
      'title' => 'Kredi Açılışı',
      'loan_id' => $loanId,
      'date' => $start_date,
      'currency' => 'TRY',
      'lines' => [
        ['account'=>'102 Bankalar', 'debit'=>$principal, 'credit'=>0],
        ['account'=>'300 Banka Kredileri', 'debit'=>0, 'credit'=>$principal],
      ]
    ];
    export_event($pdo,$companyId,$userId,'loan_open',$loanId,$payload);
    audit($pdo,$companyId,$userId,'create_loan','credit_loans',$loanId,null,['bank'=>$bank,'principal'=>$principal,'term'=>$term,'rate'=>$annual_rate]);
    $pdo->commit();
    $msg="Kredi oluşturuldu ve taksit planı üretildi.";
  }catch(Exception $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    $err=$e->getMessage();
  }
}

if (isset($_GET['close']) && credit_can_edit()) {
  $id = (int)($_GET['close'] ?? 0);
  if ($id>0) {
    $old = $pdo->query("SELECT * FROM credit_loans WHERE id={$id}")->fetch(PDO::FETCH_ASSOC);
    $pdo->prepare("UPDATE credit_loans SET status='closed', remaining_principal=0, updated_at=NOW() WHERE company_id=? AND id=?")
        ->execute([$companyId,$id]);
    $new = $pdo->query("SELECT * FROM credit_loans WHERE id={$id}")->fetch(PDO::FETCH_ASSOC);
    audit($pdo,$companyId,$userId,'close_loan','credit_loans',$id,$old,$new);
    $msg="Kredi kapatıldı (manuel).";
  }
}

$pdo->prepare("UPDATE credit_installments ci
  JOIN credit_loans cl ON cl.id=ci.loan_id
  SET ci.status='overdue'
  WHERE cl.company_id=? AND ci.status='pending' AND ci.due_date < CURDATE()")->execute([$companyId]);

$list = $pdo->prepare("SELECT
  cl.*,
  (SELECT COALESCE(SUM(ci.principal_part),0) FROM credit_installments ci WHERE ci.loan_id=cl.id AND ci.status='paid') paid_principal,
  (SELECT COUNT(*) FROM credit_installments ci WHERE ci.loan_id=cl.id AND ci.status='overdue') overdue_cnt
  FROM credit_loans cl
  WHERE cl.company_id=?
  ORDER BY cl.created_at DESC, cl.id DESC
  LIMIT 200");
$list->execute([$companyId]);
$rows = $list->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="main">
  <div class="topbar">
    <div><h1>Kredi Listesi</h1><small>Kredi ekle/detay/kapat</small></div>
    <div class="actions"><a class="btn secondary" href="calculator.php">Hesaplama</a><a class="btn" href="schedule.php">Plan</a></div>
  </div>

  <?php if($msg): ?><div class="alert ok"><?php echo e($msg); ?></div><?php endif; ?>
  <?php if($err): ?><div class="alert error"><?php echo e($err); ?></div><?php endif; ?>

  <div class="card">
    <h3>Yeni Kredi</h3>
    <form class="form" method="post">
      <div class="row">
        <div><label>Banka</label><input class="input" name="bank_name" required></div>
        <div><label>Tür</label>
          <select class="input" name="loan_type">
            <option value="ticari">Ticari</option><option value="ihtiyac">İhtiyaç</option><option value="arac">Araç</option><option value="yatirim">Yatırım</option>
          </select>
        </div>
        <div><label>Tutar (₺)</label><input class="input mono" name="principal" type="number" step="0.01" required></div>
        <div><label>Yıllık Faiz (%)</label><input class="input mono" name="annual_rate" type="number" step="0.01" required></div>
      </div>
      <div class="row">
        <div><label>Vade (Ay)</label><input class="input mono" name="term_months" type="number" required></div>
        <div><label>Ödeme Tipi</label>
          <select class="input" name="payment_type"><option value="equal">Eşit</option><option value="decreasing">Azalan</option></select>
        </div>
        <div><label>Başlangıç</label><input class="input" name="start_date" type="date" value="<?php echo e(date('Y-m-d')); ?>"></div>
        <div><label>İlk Vade</label><input class="input" name="first_due_date" type="date" value="<?php echo e(date('Y-m-d')); ?>"></div>
      </div>
      <div><label>Açıklama</label><textarea class="input" name="description"></textarea></div>
      <button class="btn" type="submit" <?php echo credit_can_edit()?'':'disabled'; ?>>Kaydet + Plan</button>
    </form>
  </div>

  <div class="card" style="margin-top:14px;">
    <h3>Kredi Listesi</h3>
    <table class="table">
      <thead><tr><th>Banka</th><th>Tür</th><th>Çekilen</th><th>Kalan Anapara</th><th>Faiz</th><th>Vade</th><th>Aylık</th><th>Durum</th><th></th></tr></thead>
      <tbody>
      <?php foreach($rows as $r):
        $remaining_pr = max(0.0, (float)$r['principal'] - (float)$r['paid_principal']);
        $overdue_cnt = (int)$r['overdue_cnt'];
        $label='Ödeniyor'; $badge='green';
        if((string)$r['status']==='closed'){ $label='Kapandı'; $badge='green'; }
        elseif($overdue_cnt>0 || (string)$r['status']==='overdue'){ $label='Gecikmiş'; $badge='red'; }
      ?>
        <tr>
          <td><strong><?php echo e((string)$r['bank_name']); ?></strong></td>
          <td><?php echo e(loan_type_tr((string)$r['loan_type'])); ?></td>
          <td class="mono"><?php echo tr_money($r['principal']); ?></td>
          <td class="mono"><?php echo tr_money($remaining_pr); ?></td>
          <td class="mono">%<?php echo e((string)$r['annual_rate']); ?></td>
          <td class="mono"><?php echo (int)$r['term_months']; ?> ay</td>
          <td class="mono"><?php echo tr_money($r['monthly_installment']); ?></td>
          <td><span class="badge <?php echo $badge; ?>"><?php echo e($label); ?></span></td>
          <td>
            <a class="btn secondary" href="schedule.php?loan_id=<?php echo (int)$r['id']; ?>">Detay</a>
            <?php if((string)$r['status']!=='closed' && credit_can_edit()): ?>
              <a class="btn danger" href="loans.php?close=<?php echo (int)$r['id']; ?>" onclick="return confirm('Kredi kapatılsın mı?');">Kapat</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if(empty($rows)): ?><tr><td colspan="9"><small>Henüz kredi yok.</small></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
