<?php
// credit/inc/services.php
declare(strict_types=1);

require_once __DIR__ . "/bootstrap.php";

function calc_equal_monthly_installment(float $principal, float $annualRatePct, int $termMonths): float {
  if ($termMonths <= 0) return 0.0;
  $r = ($annualRatePct / 100.0) / 12.0;
  if ($r <= 0) return round($principal / $termMonths, 2);
  $pmt = $principal * ($r * pow(1+$r, $termMonths)) / (pow(1+$r, $termMonths) - 1);
  return round($pmt, 2);
}

function build_schedule(float $principal, float $annualRatePct, int $termMonths, string $paymentType, string $firstDueDate): array {
  $rows = [];
  if ($termMonths <= 0) return $rows;

  $r = ($annualRatePct / 100.0) / 12.0;
  $balance = $principal;
  $monthly = ($paymentType === 'equal') ? calc_equal_monthly_installment($principal, $annualRatePct, $termMonths) : 0.0;

  $due = new DateTime($firstDueDate);

  for ($i=1; $i<=$termMonths; $i++) {
    $interest = round($balance * $r, 2);
    if ($paymentType === 'decreasing') {
      $principalPart = round($principal / $termMonths, 2);
      $total = round($principalPart + $interest, 2);
    } else {
      $total = $monthly;
      $principalPart = round($total - $interest, 2);
      if ($principalPart < 0) $principalPart = 0;
    }
    if ($i === $termMonths) {
      $principalPart = round($balance, 2);
      $total = round($principalPart + $interest, 2);
    }

    $rows[] = [
      'installment_no' => $i,
      'due_date' => $due->format('Y-m-d'),
      'principal_part' => $principalPart,
      'interest_part' => $interest,
      'installment_total' => $total,
    ];

    $balance = round($balance - $principalPart, 2);
    $due->modify('+1 month');
  }
  return $rows;
}

function loan_type_tr(string $t): string {
  return [
    'ticari'=>'Ticari',
    'ihtiyac'=>'İhtiyaç',
    'arac'=>'Araç',
    'yatirim'=>'Yatırım'
  ][$t] ?? $t;
}
