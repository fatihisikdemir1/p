<?php
require_once __DIR__ . "/bootstrap.php";
$uName = $_SESSION['user']['name'] ?? ($_SESSION['user']['full_name'] ?? 'Kullanıcı');
$role  = $_SESSION['user']['role'] ?? 'user';
$initial = mb_strtoupper(mb_substr((string)$uName, 0, 1, 'UTF-8'), 'UTF-8');
?>
<aside class="sidebar">
  <div class="brand">
    <h2>FinansConnect <span class="pill">Kredi</span></h2>
    <small>Kredi Takip Modülü</small>
  </div>

  <nav class="nav">
    <div class="section">Modüller</div>
    <a href="/dashboard.php">🧩 Uygulama (Görev/Proje)</a>
    <a href="/finance/dashboard.php">📈 Finans</a>
    <a href="/procurement/views/dashboard.php">🛒 Satınalma</a>

    <div class="section">Genel</div>
    <a class="<?php echo is_active('/credit/dashboard.php'); ?>" href="dashboard.php">🏠 Ana Sayfa</a>

    <div class="section">Kredi</div>
    <a class="<?php echo is_active('/credit/track.php'); ?>" href="track.php">📌 Kredi Takibi</a>
    <a class="<?php echo is_active('/credit/loans.php'); ?>" href="loans.php">📋 Kredi Listesi</a>
    <a class="<?php echo is_active('/credit/calculator.php'); ?>" href="calculator.php">🧮 Kredi Hesaplama</a>
    <a class="<?php echo is_active('/credit/schedule.php'); ?>" href="schedule.php">📆 Taksit Planı</a>
    <a class="<?php echo is_active('/credit/aging.php'); ?>" href="aging.php">⏳ Yaşlandırma</a>

    <div class="section">Sistem</div>
    <a class="<?php echo is_active('/credit/settings.php'); ?>" href="settings.php">⚙️ Ayarlar</a>
    <a href="/modules.php">↩︎ Modül Seç</a>
  </nav>

  <div class="userbox">
    <div class="avatar"><?php echo e($initial); ?></div>
    <div>
      <div style="font-weight:900;"><?php echo e($uName); ?></div>
      <small><?php echo e($role); ?></small>
    </div>
  </div>
</aside>
