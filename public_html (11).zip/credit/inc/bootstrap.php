<?php
// credit/inc/bootstrap.php
declare(strict_types=1);

require_once __DIR__ . "/../../auth.php"; // root auth.php (session + $pdo + RBAC)

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function tr_money($n): string {
  $v = is_numeric($n) ? (float)$n : 0.0;
  return number_format($v, 2, ',', '.') . " ₺";
}
function current_path(): string { return $_SERVER['PHP_SELF'] ?? ''; }
function is_active(string $needle): string { return (strpos(current_path(), $needle) !== false) ? 'active' : ''; }

function credit_can_view(): bool { return has_permission('credit_view') || is_super_admin(); }
function credit_can_edit(): bool { return has_permission('credit_edit') || is_super_admin(); }
