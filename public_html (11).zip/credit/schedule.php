<?php
$title = 'Taksit Planı';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';
require_once __DIR__ . '/inc/services.php';

if (!credit_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);
$userId = (int)($_SESSION['user']['id'] ?? 0);
$msg=null; $err=null;

function audit2(PDO $pdo, int $companyId, int $userId, string $action, string $etype, int $eid, $old, $new): void {
  $ip = $_SERVER['REMOTE_ADDR'] ?? null;
  $pdo->prepare("INSERT INTO credit_audit_logs (company_id,user_id,action,entity_type,entity_id,ip,old_json,new_json,created_at)
                 VALUES (?,?,?,?,?,?,?,?,NOW())")
      ->execute([$companyId,$userId,$action,$etype,$eid,$ip,$old?json_encode($old,JSON_UNESCAPED_UNICODE):null,$new?json_encode($new,JSON_UNESCAPED_UNICODE):null]);
}
function export2(PDO $pdo, int $companyId, int $userId, string $etype, int $eid, array $payload): void {
  $pdo->prepare("INSERT INTO credit_accounting_exports (company_id,entity_type,entity_id,export_status,payload_json,created_by,created_at)
                 VALUES (?,?,?,'pending',?,?,NOW())")
      ->execute([$companyId,$etype,$eid,json_encode($payload,JSON_UNESCAPED_UNICODE),$userId]);
}

if (isset($_POST['pay_installment']) && credit_can_edit()) {
  try{
    $instId = (int)($_POST['installment_id'] ?? 0);
    $payDate = $_POST['paid_date'] ?? date('Y-m-d');

    $q = $pdo->prepare("SELECT ci.*, cl.company_id, cl.id loan_id FROM credit_installments ci JOIN credit_loans cl ON cl.id=ci.loan_id WHERE ci.id=? AND cl.company_id=?");
    $q->execute([$instId,$companyId]);
    $row = $q->fetch(PDO::FETCH_ASSOC);
    if(!$row) throw new Exception("Taksit bulunamadı.");
    if((int)$row['locked']===1 || $row['status']==='paid') throw new Exception("Ödenen taksit kilitli.");

    $pdo->beginTransaction();
    $pdo->prepare("UPDATE credit_installments SET paid_amount=installment_total, paid_date=?, status='paid', locked=1 WHERE id=?")
        ->execute([$payDate,$instId]);

    $loanId = (int)$row['loan_id'];
    $pdo->prepare("UPDATE credit_loans SET remaining_principal = GREATEST(0, remaining_principal - ?), updated_at=NOW() WHERE id=? AND company_id=?")
        ->execute([(float)$row['principal_part'],$loanId,$companyId]);

    $payload = [
      'title' => 'Kredi Taksit Ödemesi',
      'loan_id' => $loanId,
      'installment_id' => $instId,
      'date' => $payDate,
      'currency' => 'TRY',
      'lines' => [
        ['account'=>'300 Banka Kredileri', 'debit'=>$row['principal_part'], 'credit'=>0],
        ['account'=>'780 Finansman Giderleri (Faiz)', 'debit'=>$row['interest_part'], 'credit'=>0],
        ['account'=>'102 Bankalar', 'debit'=>0, 'credit'=>$row['installment_total']],
      ]
    ];
    export2($pdo,$companyId,$userId,'installment_payment',$instId,$payload);
    $new = $pdo->query("SELECT * FROM credit_installments WHERE id={$instId}")->fetch(PDO::FETCH_ASSOC);
    audit2($pdo,$companyId,$userId,'pay_installment','credit_installments',$instId,$row,$new);

    $pdo->commit();
    $msg="Taksit ödendi işaretlendi. (Export: pending)";
  }catch(Exception $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    $err=$e->getMessage();
  }
}

$loanId = isset($_GET['loan_id']) ? (int)$_GET['loan_id'] : 0;
$loans = $pdo->prepare("SELECT id, bank_name, loan_type, term_months FROM credit_loans WHERE company_id=? ORDER BY created_at DESC");
$loans->execute([$companyId]);
$loanRows = $loans->fetchAll(PDO::FETCH_ASSOC);
if ($loanId<=0 && !empty($loanRows)) $loanId = (int)$loanRows[0]['id'];

$loan = null; $instRows=[];
if ($loanId>0){
  $q=$pdo->prepare("SELECT * FROM credit_loans WHERE company_id=? AND id=?");
  $q->execute([$companyId,$loanId]);
  $loan=$q->fetch(PDO::FETCH_ASSOC);

  if($loan){
    $pdo->prepare("UPDATE credit_installments SET status='overdue' WHERE loan_id=? AND status='pending' AND due_date < CURDATE()")->execute([$loanId]);
    $ins=$pdo->prepare("SELECT * FROM credit_installments WHERE loan_id=? ORDER BY installment_no ASC");
    $ins->execute([$loanId]);
    $instRows=$ins->fetchAll(PDO::FETCH_ASSOC);
  }
}
?>
<div class="main">
  <div class="topbar"><div><h1>Taksit Planı</h1><small>Ödenen taksit kilitlenir.</small></div><div class="actions"><a class="btn secondary" href="loans.php">Krediler</a></div></div>

  <?php if($msg): ?><div class="alert ok"><?php echo e($msg); ?></div><?php endif; ?>
  <?php if($err): ?><div class="alert error"><?php echo e($err); ?></div><?php endif; ?>

  <div class="card">
    <h3>Kredi Seç</h3>
    <form class="form" method="get">
      <div class="row" style="grid-template-columns: 2fr 1fr 1fr 1fr;">
        <div>
          <label>Kredi</label>
          <select class="input" name="loan_id" onchange="this.form.submit()">
            <?php foreach($loanRows as $l): ?>
              <option value="<?php echo (int)$l['id']; ?>" <?php echo ((int)$l['id']===$loanId)?'selected':''; ?>>
                <?php echo e($l['bank_name'].' - '.loan_type_tr($l['loan_type']).' ('.$l['term_months'].' ay)'); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div><label>Çekilen</label><input class="input mono" value="<?php echo $loan?tr_money($loan['principal']):''; ?>" disabled></div>
        <div><label>Faiz</label><input class="input mono" value="<?php echo $loan?('%'.$loan['annual_rate']):''; ?>" disabled></div>
        <div><label>Durum</label><input class="input" value="<?php echo $loan?e($loan['status']):''; ?>" disabled></div>
      </div>
    </form>
  </div>

  <div class="card" style="margin-top:14px;">
    <h3>Taksit Tablosu</h3>
    <table class="table">
      <thead><tr><th>No</th><th>Vade</th><th>Anapara</th><th>Faiz</th><th>Toplam</th><th>Durum</th><th>İşlem</th></tr></thead>
      <tbody>
        <?php foreach($instRows as $r):
          $status=(string)$r['status'];
          $badge='green'; $label='Planlı';
          if($status==='overdue'){ $badge='red'; $label='Gecikmiş'; }
          elseif($status==='pending' && $r['due_date'] <= date('Y-m-d', strtotime('+7 days'))){ $badge='orange'; $label='Yaklaşıyor'; }
          elseif($status==='paid'){ $badge='green'; $label='Ödendi'; }
        ?>
        <tr>
          <td>#<?php echo (int)$r['installment_no']; ?></td>
          <td><strong><?php echo e((string)$r['due_date']); ?></strong></td>
          <td class="mono"><?php echo tr_money($r['principal_part']); ?></td>
          <td class="mono"><?php echo tr_money($r['interest_part']); ?></td>
          <td class="mono"><?php echo tr_money($r['installment_total']); ?></td>
          <td><span class="badge <?php echo $badge; ?>"><?php echo e($label); ?></span></td>
          <td>
            <?php if($status!=='paid' && (int)$r['locked']===0 && credit_can_edit()): ?>
              <form method="post" style="display:flex;gap:8px;align-items:center;">
                <input type="hidden" name="installment_id" value="<?php echo (int)$r['id']; ?>">
                <input class="input" type="date" name="paid_date" value="<?php echo e(date('Y-m-d')); ?>" style="max-width:160px">
                <button class="btn" name="pay_installment" value="1" type="submit" onclick="return confirm('Ödendi işaretle?');">Öde</button>
              </form>
            <?php else: ?><small><?php echo $status==='paid'?'Kilitli':'—'; ?></small><?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($instRows)): ?><tr><td colspan="7"><small>Plan yok.</small></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
