<?php
$title = 'Yaşlandırma';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';
require_once __DIR__ . '/inc/services.php';

if (!credit_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);
$pdo->prepare("UPDATE credit_installments ci
  JOIN credit_loans cl ON cl.id=ci.loan_id
  SET ci.status='overdue'
  WHERE cl.company_id=? AND ci.status='pending' AND ci.due_date < CURDATE()")->execute([$companyId]);

$st = $pdo->prepare("
  SELECT
    SUM(CASE WHEN DATEDIFF(CURDATE(), ci.due_date) BETWEEN 0 AND 30 THEN (ci.installment_total-ci.paid_amount) ELSE 0 END) b0_30,
    SUM(CASE WHEN DATEDIFF(CURDATE(), ci.due_date) BETWEEN 31 AND 60 THEN (ci.installment_total-ci.paid_amount) ELSE 0 END) b31_60,
    SUM(CASE WHEN DATEDIFF(CURDATE(), ci.due_date) BETWEEN 61 AND 90 THEN (ci.installment_total-ci.paid_amount) ELSE 0 END) b61_90,
    SUM(CASE WHEN DATEDIFF(CURDATE(), ci.due_date) >= 91 THEN (ci.installment_total-ci.paid_amount) ELSE 0 END) b90p
  FROM credit_installments ci
  JOIN credit_loans cl ON cl.id=ci.loan_id
  WHERE cl.company_id=? AND ci.status='overdue'
");
$st->execute([$companyId]);
$r = $st->fetch(PDO::FETCH_ASSOC) ?: [];
$b0=(float)($r['b0_30']??0); $b1=(float)($r['b31_60']??0); $b2=(float)($r['b61_90']??0); $b3=(float)($r['b90p']??0);
$total = $b0+$b1+$b2+$b3;
$max = max(1.0, $total);
function pct($v,$m){ return round(($v/$m)*100,2); }
?>
<div class="main">
  <div class="topbar"><div><h1>Yaşlandırma</h1><small>Gecikmiş taksit risk dağılımı</small></div><div class="actions"><a class="btn secondary" href="track.php">Takip</a></div></div>

  <div class="grid" style="grid-template-columns: 1fr 1fr; gap:14px;">
    <div class="card">
      <h3>Toplam Risk</h3>
      <div class="mono" style="font-size:22px;font-weight:900;"><?php echo tr_money($total); ?></div>
      <small>Sadece overdue taksitler.</small>
    </div>

    <div class="card">
      <h3>Bar Grafik</h3>
      <?php foreach([['0–30',$b0],['31–60',$b1],['61–90',$b2],['90+',$b3]] as $x): $p=pct($x[1],$max); ?>
        <div style="margin:8px 0;">
          <div style="display:flex;justify-content:space-between;"><small><strong><?php echo e($x[0]); ?></strong></small><small class="mono"><?php echo tr_money($x[1]); ?></small></div>
          <div style="height:10px;background:rgba(17,24,39,.08);border-radius:999px;overflow:hidden;">
            <div style="height:10px;width:<?php echo $p; ?>%;background:var(--red);"></div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="card" style="margin-top:14px;">
    <h3>Bucket Tablosu</h3>
    <table class="table">
      <thead><tr><th>Bucket</th><th>Risk</th></tr></thead>
      <tbody>
        <tr><td>0–30</td><td class="mono"><?php echo tr_money($b0); ?></td></tr>
        <tr><td>31–60</td><td class="mono"><?php echo tr_money($b1); ?></td></tr>
        <tr><td>61–90</td><td class="mono"><?php echo tr_money($b2); ?></td></tr>
        <tr><td>90+</td><td class="mono"><span class="badge red"><?php echo tr_money($b3); ?></span></td></tr>
      </tbody>
    </table>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
