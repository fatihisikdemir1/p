<?php
$title = 'Ayarlar';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';
require_once __DIR__ . '/inc/services.php';

if (!credit_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);

$exports = $pdo->prepare("SELECT * FROM credit_accounting_exports WHERE company_id=? ORDER BY id DESC LIMIT 50");
$exports->execute([$companyId]);
$expRows = $exports->fetchAll(PDO::FETCH_ASSOC);

$audit = $pdo->prepare("SELECT * FROM credit_audit_logs WHERE company_id=? ORDER BY id DESC LIMIT 50");
$audit->execute([$companyId]);
$audRows = $audit->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="main">
  <div class="topbar"><div><h1>Ayarlar & Loglar</h1><small>Muhasebe export kuyruğu + audit</small></div></div>

  <div class="grid" style="grid-template-columns: 1fr 1fr; gap:14px;">
    <div class="card">
      <h3>Export Kuyruğu</h3>
      <table class="table">
        <thead><tr><th>ID</th><th>Tip</th><th>Entity</th><th>Durum</th><th>Tarih</th></tr></thead>
        <tbody>
          <?php foreach($expRows as $r): ?>
            <tr>
              <td>#<?php echo (int)$r['id']; ?></td>
              <td><?php echo e((string)$r['entity_type']); ?></td>
              <td><?php echo e((string)$r['entity_id']); ?></td>
              <td><span class="badge <?php echo ($r['export_status']==='pending')?'orange':'green'; ?>"><?php echo e((string)$r['export_status']); ?></span></td>
              <td><?php echo e((string)$r['created_at']); ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if(empty($expRows)): ?><tr><td colspan="5"><small>Kayıt yok.</small></td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>

    <div class="card">
      <h3>Audit Log</h3>
      <table class="table">
        <thead><tr><th>ID</th><th>Aksiyon</th><th>Entity</th><th>Kullanıcı</th><th>Tarih</th></tr></thead>
        <tbody>
          <?php foreach($audRows as $r): ?>
            <tr>
              <td>#<?php echo (int)$r['id']; ?></td>
              <td><?php echo e((string)$r['action']); ?></td>
              <td><?php echo e((string)$r['entity_type'])." #".e((string)$r['entity_id']); ?></td>
              <td><?php echo e((string)($r['user_id'] ?? '-')); ?></td>
              <td><?php echo e((string)$r['created_at']); ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if(empty($audRows)): ?><tr><td colspan="5"><small>Kayıt yok.</small></td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card" style="margin-top:14px;">
    <h3>Muhasebe Bağlantısı</h3>
    <small>Bu modül “Kredi açılışı” ve “taksit ödemesi” olaylarında JSON fiş taslağını <strong>credit_accounting_exports</strong> tablosuna yazar. Sonraki adımda accounting modülüne “import/fiş üret” ekranı eklenir.</small>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
