<?php
$title = 'Kredi Takibi';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';
require_once __DIR__ . '/inc/services.php';

if (!credit_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);
$list = $pdo->prepare("
  SELECT cl.id, cl.bank_name, cl.loan_type, cl.principal, cl.annual_rate, cl.term_months, cl.monthly_installment, cl.status,
    (SELECT COALESCE(SUM(ci.installment_total - ci.paid_amount),0) FROM credit_installments ci WHERE ci.loan_id=cl.id AND ci.status='overdue') overdue_amount,
    (SELECT MIN(ci.due_date) FROM credit_installments ci WHERE ci.loan_id=cl.id AND ci.status IN ('pending','overdue')) next_due
  FROM credit_loans cl
  WHERE cl.company_id=? AND cl.status<>'cancelled'
  ORDER BY overdue_amount DESC, cl.created_at DESC
  LIMIT 200
");
$list->execute([$companyId]);
$rows = $list->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="main">
  <div class="topbar">
    <div><h1>Kredi Takibi</h1><small>Risk odaklı izleme</small></div>
    <div class="actions"><a class="btn secondary" href="aging.php">Yaşlandırma</a><a class="btn" href="loans.php">Krediler</a></div>
  </div>

  <div class="card">
    <h3>Risk Tablosu</h3>
    <table class="table">
      <thead><tr><th>Banka</th><th>Tür</th><th>Çekilen</th><th>Faiz</th><th>Vade</th><th>Next Due</th><th>Gecikme</th><th>Durum</th></tr></thead>
      <tbody>
        <?php foreach($rows as $r):
          $over = (float)$r['overdue_amount'];
          $next = $r['next_due'] ? (string)$r['next_due'] : '-';
          $badge='green'; $label='Düzenli';
          if ($over>0) { $badge='red'; $label='Gecikmiş'; }
          elseif ($next !== '-' && $next <= date('Y-m-d', strtotime('+7 days'))) { $badge='orange'; $label='Yaklaşıyor'; }
        ?>
          <tr>
            <td><strong><?php echo e((string)$r['bank_name']); ?></strong></td>
            <td><?php echo e(loan_type_tr((string)$r['loan_type'])); ?></td>
            <td class="mono"><?php echo tr_money($r['principal']); ?></td>
            <td class="mono">%<?php echo e((string)$r['annual_rate']); ?></td>
            <td class="mono"><?php echo (int)$r['term_months']; ?> ay</td>
            <td class="mono"><?php echo e($next); ?></td>
            <td class="mono"><?php echo tr_money($over); ?></td>
            <td><span class="badge <?php echo $badge; ?>"><?php echo e($label); ?></span></td>
          </tr>
        <?php endforeach; ?>
        <?php if(empty($rows)): ?><tr><td colspan="8"><small>Henüz kredi yok.</small></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
