<?php
$title = 'Kredi Hesaplama';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';
require_once __DIR__ . '/inc/services.php';

if (!credit_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$msg=null; $err=null; $result=null;
if ($_SERVER['REQUEST_METHOD']==='POST') {
  try{
    $p=(float)($_POST['principal'] ?? 0);
    $rate=(float)($_POST['annual_rate'] ?? 0);
    $term=(int)($_POST['term_months'] ?? 0);
    $type=$_POST['payment_type'] ?? 'equal';
    if($p<=0||$term<=0) throw new Exception("Kredi tutarı ve vade zorunlu.");
    $sched = build_schedule($p,$rate,$term,$type,date('Y-m-d'));
    $totalPay=0.0; $totalInt=0.0;
    foreach($sched as $s){ $totalPay += (float)$s['installment_total']; $totalInt += (float)$s['interest_part']; }
    $monthly = ($type==='equal') ? calc_equal_monthly_installment($p,$rate,$term) : 0.0;
    $result = ['monthly'=>$monthly,'total'=>$totalPay,'interest'=>$totalInt,'type'=>$type];
    $msg="Hesaplama yapıldı.";
  }catch(Exception $e){ $err=$e->getMessage(); }
}
?>
<div class="main">
  <div class="topbar"><div><h1>Kredi Hesaplama</h1><small>Eşit taksit / azalan</small></div></div>

  <?php if($msg): ?><div class="alert ok"><?php echo e($msg); ?></div><?php endif; ?>
  <?php if($err): ?><div class="alert error"><?php echo e($err); ?></div><?php endif; ?>

  <div class="card">
    <h3>Girdi</h3>
    <form class="form" method="post">
      <div class="row">
        <div><label>Kredi (₺)</label><input class="input mono" name="principal" type="number" step="0.01" required></div>
        <div><label>Yıllık Faiz (%)</label><input class="input mono" name="annual_rate" type="number" step="0.01" required></div>
        <div><label>Vade (Ay)</label><input class="input mono" name="term_months" type="number" required></div>
        <div><label>Ödeme Tipi</label>
          <select class="input" name="payment_type"><option value="equal">Eşit</option><option value="decreasing">Azalan</option></select>
        </div>
      </div>
      <button class="btn" type="submit">HESAPLA</button>
    </form>
  </div>

  <?php if($result): ?>
  <div class="card" style="margin-top:14px;">
    <h3>Çıktı</h3>
    <table class="table">
      <tbody>
        <tr><th>Aylık Taksit</th><td class="mono"><?php echo tr_money($result['monthly']); ?></td></tr>
        <tr><th>Toplam Geri Ödeme</th><td class="mono"><?php echo tr_money($result['total']); ?></td></tr>
        <tr><th>Toplam Faiz</th><td class="mono"><?php echo tr_money($result['interest']); ?></td></tr>
      </tbody>
    </table>
    <small>Azalan ödemede aylık taksit sabit değildir.</small>
  </div>
  <?php endif; ?>
</div>


require_once __DIR__ . '/inc/footer.php';
