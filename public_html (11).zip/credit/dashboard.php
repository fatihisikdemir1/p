<?php
$title = 'Kredi Dashboard';
require_once __DIR__ . '/inc/header.php';
require_once __DIR__ . '/inc/sidebar.php';
require_once __DIR__ . '/inc/services.php';

if (!credit_can_view()) {
  http_response_code(403);
  echo "<div class='main'><div class='alert error'>Bu modülü görüntüleme yetkiniz yok.</div></div>";
  require_once __DIR__ . '/inc/footer.php';
  exit;
}


$companyId = (int)($_SESSION['user']['company_id'] ?? 0);

$pdo->prepare("UPDATE credit_installments ci
  JOIN credit_loans cl ON cl.id=ci.loan_id
  SET ci.status='overdue'
  WHERE cl.company_id=? AND ci.status='pending' AND ci.due_date < CURDATE()")->execute([$companyId]);

$pdo->prepare("UPDATE credit_loans cl SET cl.status='overdue'
  WHERE cl.company_id=? AND cl.status='ongoing' AND EXISTS(
     SELECT 1 FROM credit_installments ci WHERE ci.loan_id=cl.id AND ci.status='overdue'
  )")->execute([$companyId]);

$total_principal = (float)$pdo->query("SELECT COALESCE(SUM(principal),0) FROM credit_loans WHERE company_id={$companyId} AND status<>'cancelled'")->fetchColumn();
$total_interest_expected = (float)$pdo->query("SELECT COALESCE(SUM(total_interest_expected),0) FROM credit_loans WHERE company_id={$companyId} AND status IN ('ongoing','overdue')")->fetchColumn();

$sum_pending = $pdo->prepare("SELECT COALESCE(SUM(installment_total - paid_amount),0) FROM credit_installments ci
  JOIN credit_loans cl ON cl.id=ci.loan_id
  WHERE cl.company_id=? AND ci.status IN ('pending','overdue')");
$sum_pending->execute([$companyId]);
$pending_installments_total = (float)$sum_pending->fetchColumn();

$sum_overdue = $pdo->prepare("SELECT COALESCE(SUM(installment_total - paid_amount),0) FROM credit_installments ci
  JOIN credit_loans cl ON cl.id=ci.loan_id
  WHERE cl.company_id=? AND ci.status='overdue'");
$sum_overdue->execute([$companyId]);
$overdue_total = (float)$sum_overdue->fetchColumn();

$q = $pdo->prepare("SELECT ci.*, cl.bank_name, cl.loan_type
  FROM credit_installments ci
  JOIN credit_loans cl ON cl.id=ci.loan_id
  WHERE cl.company_id=? AND ci.status IN ('pending','overdue')
  ORDER BY ci.due_date ASC
  LIMIT 10");
$q->execute([$companyId]);
$rows = $q->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="main">
  <div class="topbar">
    <div><h1>Kredi Dashboard</h1><small>Toplam kredi yükü, taksitler ve risk göstergeleri</small></div>
    <div class="actions">
      <a class="btn secondary" href="loans.php">+ Kredi Ekle</a>
      <a class="btn" href="schedule.php">Taksit Planı</a>
    </div>
  </div>

  <div class="grid kpis">
    <div class="card kpi"><h3>Toplam Kredi Tutarı</h3><div class="value mono"><?php echo tr_money($total_principal); ?></div><div class="hint">Anapara toplamı</div></div>
    <div class="card kpi"><h3>Ödenecek Taksitler</h3><div class="value mono"><?php echo tr_money($pending_installments_total); ?></div><div class="hint">Bekleyen + gecikmiş</div></div>
    <div class="card kpi"><h3>Geciken Taksitler</h3><div class="value mono" style="color:var(--red)"><?php echo tr_money($overdue_total); ?></div><div class="hint">Kritik risk</div></div>
    <div class="card kpi"><h3>Toplam Ödenecek Faiz</h3><div class="value mono"><?php echo tr_money($total_interest_expected); ?></div><div class="hint">Açık krediler</div></div>
  </div>

  <div class="card" style="margin-top:14px;">
    <h3>Yaklaşan / Gecikmiş Taksitler</h3>
    <table class="table">
      <thead><tr><th>Vade</th><th>Banka</th><th>Tür</th><th>No</th><th>Kalan</th><th>Durum</th></tr></thead>
      <tbody>
        <?php foreach($rows as $r):
          $left = (float)$r['installment_total'] - (float)$r['paid_amount'];
          $due = (string)$r['due_date'];
          $isSoon = ($r['status']==='pending' && $due <= date('Y-m-d', strtotime('+7 days')));
        ?>
        <tr>
          <td><strong><?php echo e($due); ?></strong></td>
          <td><?php echo e((string)$r['bank_name']); ?></td>
          <td><?php echo e(loan_type_tr((string)$r['loan_type'])); ?></td>
          <td>#<?php echo (int)$r['installment_no']; ?></td>
          <td class="mono"><?php echo tr_money($left); ?></td>
          <td>
            <?php if($r['status']==='overdue'): ?><span class="badge red">Gecikmiş</span>
            <?php elseif($isSoon): ?><span class="badge orange">Yaklaşıyor</span>
            <?php else: ?><span class="badge green">Planlı</span><?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($rows)): ?><tr><td colspan="6"><small>Bekleyen taksit yok.</small></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>


require_once __DIR__ . '/inc/footer.php';
