<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";
require __DIR__ . "/config/rbac.php";

require_role(["super_admin","company_admin"]);

$title = trim((string)($_POST["title"] ?? ""));
$desc  = trim((string)($_POST["description"] ?? ""));
$pri   = trim((string)($_POST["priority"] ?? "medium"));
$due   = trim((string)($_POST["due_date"] ?? ""));
$assignedTo = (int)($_SESSION["user"]["id"] ?? 0);

if ($title === "") {
  header("Location: dashboard.php");
  exit;
}

/* kolon tespiti */
$taskCols = [];
$rs = $pdo->query("DESCRIBE tasks");
foreach ($rs->fetchAll(PDO::FETCH_ASSOC) as $r) $taskCols[$r["Field"]] = true;

$hasTaskCompany = isset($taskCols["company_id"]);
$hasTaskCreated = isset($taskCols["created_at"]);

$fields = ["title","description","status","priority","assigned_to","due_date"];
$vals   = [":t",":d","'todo'",":p",":a",":due"];
$bind   = [
  ":t"=>$title,
  ":d"=>$desc,
  ":p"=>$pri,
  ":a"=>$assignedTo,
  ":due"=>($due!=="" ? $due : null),
];

if ($hasTaskCompany) {
  $companyId = (int)($_SESSION["user"]["company_id"] ?? 0);
  $fields[] = "company_id";
  $vals[]   = ":cid";
  $bind[":cid"] = ($companyId > 0 ? $companyId : null);
}
if ($hasTaskCreated) {
  $fields[] = "created_at";
  $vals[]   = "NOW()";
}

$sql = "INSERT INTO tasks (".implode(",",$fields).") VALUES (".implode(",",$vals).")";
$pdo->prepare($sql)->execute($bind);

header("Location: dashboard.php");
exit;
