<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";
require __DIR__ . "/config/rbac.php";

require_role(["company_admin","super_admin"]);

$u = $_SESSION["user"];
$myCompanyId = (int)($u["company_id"] ?? 0);
if (($u["role"] ?? "") !== "super_admin" && $myCompanyId <= 0) {
  exit("Company Admin için company_id zorunlu");
}

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, "UTF-8"); }

$err = "";
$ok  = "";

/* create user */
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "create") {
  $name  = trim((string)($_POST["name"] ?? ""));
  $email = trim((string)($_POST["email"] ?? ""));
  $role  = trim((string)($_POST["role"] ?? "user"));
  $pass  = (string)($_POST["password"] ?? "");

  if ($name==="" || $email==="" || $pass==="") {
    $err = "Ad, e-posta, şifre zorunlu.";
  } elseif (!in_array($role, ["user","company_admin"], true)) {
    $err = "Geçersiz rol.";
  } else {
    try {
      // email unique check
      $chk = $pdo->prepare("SELECT id FROM users WHERE email=? LIMIT 1");
      $chk->execute([$email]);
      if ($chk->fetch()) throw new RuntimeException("Bu e-posta zaten kayıtlı.");

      $hash = password_hash($pass, PASSWORD_BCRYPT);

      $stmt = $pdo->prepare("
        INSERT INTO users (company_id, role, name, email, password_hash, is_active)
        VALUES (:cid, :role, :name, :email, :ph, 1)
      ");
      $stmt->execute([
        ":cid" => $myCompanyId,
        ":role" => $role,
        ":name" => $name,
        ":email" => $email,
        ":ph" => $hash,
      ]);

      $ok = "Kullanıcı eklendi.";
    } catch (Throwable $e) {
      $err = $e->getMessage();
    }
  }
}

/* update role / active */
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "update") {
  $id = (int)($_POST["id"] ?? 0);
  $newRole = trim((string)($_POST["role"] ?? "user"));
  $active  = (int)($_POST["is_active"] ?? 1);

  if ($id<=0) $err = "Geçersiz kullanıcı.";
  elseif (!in_array($newRole, ["user","company_admin"], true)) $err = "Geçersiz rol.";
  else {
    try {
      // SCOPE: sadece kendi firması
      $stmt = $pdo->prepare("
        UPDATE users
        SET role=:r, is_active=:a
        WHERE id=:id AND company_id=:cid
        LIMIT 1
      ");
      $stmt->execute([
        ":r"=>$newRole,
        ":a"=>$active ? 1 : 0,
        ":id"=>$id,
        ":cid"=>$myCompanyId
      ]);
      $ok = "Güncellendi.";
    } catch (Throwable $e) {
      $err = $e->getMessage();
    }
  }
}

/* list */
$list = $pdo->prepare("
  SELECT id, name, email, role, is_active
  FROM users
  WHERE company_id=?
  ORDER BY id DESC
  LIMIT 500
");
$list->execute([$myCompanyId]);
$users = $list->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Firma Kullanıcıları</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-3">
<div class="container" style="max-width:1100px">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="m-0">Kullanıcı Yönetimi</h3>
    <a class="btn btn-outline-dark" href="dashboard.php">Dashboard</a>
  </div>

  <?php if($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
  <?php if($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>

  <div class="card p-3 mb-3">
    <h5 class="mb-3">Yeni Kullanıcı Ekle</h5>
    <form method="post" class="row g-2">
      <input type="hidden" name="action" value="create">
      <div class="col-md-4">
        <label class="form-label">Ad Soyad</label>
        <input name="name" class="form-control" required>
      </div>
      <div class="col-md-3">
        <label class="form-label">E-posta</label>
        <input name="email" type="email" class="form-control" required>
      </div>
      <div class="col-md-2">
        <label class="form-label">Rol</label>
        <select name="role" class="form-select">
          <option value="user">User</option>
          <option value="company_admin">Company Admin</option>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label">Şifre</label>
        <input name="password" type="password" class="form-control" required>
      </div>
      <div class="col-md-1 d-flex align-items-end">
        <button class="btn btn-primary w-100">Ekle</button>
      </div>
    </form>
  </div>

  <div class="card p-3">
    <h5 class="mb-3">Mevcut Kullanıcılar</h5>
    <div class="table-responsive">
      <table class="table table-striped align-middle">
        <thead>
          <tr>
            <th>ID</th><th>Ad</th><th>E-posta</th><th>Rol</th><th>Durum</th><th>İşlem</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach($users as $x): ?>
          <tr>
            <td><?= (int)$x["id"] ?></td>
            <td><?= e((string)$x["name"]) ?></td>
            <td><?= e((string)$x["email"]) ?></td>
            <td>
              <form method="post" class="d-flex gap-2">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="<?= (int)$x["id"] ?>">
                <select name="role" class="form-select form-select-sm" style="max-width:170px">
                  <option value="user" <?= ($x["role"]==="user"?"selected":"") ?>>user</option>
                  <option value="company_admin" <?= ($x["role"]==="company_admin"?"selected":"") ?>>company_admin</option>
                </select>
            </td>
            <td>
                <select name="is_active" class="form-select form-select-sm" style="max-width:140px">
                  <option value="1" <?= ((int)$x["is_active"]===1?"selected":"") ?>>Aktif</option>
                  <option value="0" <?= ((int)$x["is_active"]===0?"selected":"") ?>>Pasif</option>
                </select>
            </td>
            <td>
                <button class="btn btn-sm btn-primary">Kaydet</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>
</body>
</html>
