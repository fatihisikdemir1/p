<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$msg = "";
$err = "";

// Kullanıcı bilgilerini al
$stmt = $pdo->prepare("
    SELECT u.*, r.role_name, c.name as company_name
    FROM users u
    LEFT JOIN roles r ON u.role_id = r.id
    LEFT JOIN companies c ON u.company_id = c.id
    WHERE u.id = ?
");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Profil güncelleme
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    $department = trim($_POST["department"] ?? "");
    $position = trim($_POST["position"] ?? "");
    $currentPassword = trim($_POST["current_password"] ?? "");
    $newPassword = trim($_POST["new_password"] ?? "");
    
    try {
        if ($name === "" || $email === "") {
            throw new Exception("Ad ve email zorunludur");
        }
        
        // Email benzersizlik kontrolü
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $userId]);
        if ($stmt->fetch()) {
            throw new Exception("Bu email başka bir kullanıcıya ait");
        }
        
        // Şifre değişikliği
        if ($newPassword !== "") {
            if ($currentPassword === "") {
                throw new Exception("Mevcut şifrenizi girmelisiniz");
            }
            
            if (!password_verify($currentPassword, $user['password'])) {
                throw new Exception("Mevcut şifre yanlış");
            }
            
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("
                UPDATE users SET 
                    name = ?, email = ?, phone = ?, department = ?, position = ?,
                    password = ?, password_changed_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$name, $email, $phone, $department, $position, $hashedPassword, $userId]);
        } else {
            $stmt = $pdo->prepare("
                UPDATE users SET 
                    name = ?, email = ?, phone = ?, department = ?, position = ?
                WHERE id = ?
            ");
            $stmt->execute([$name, $email, $phone, $department, $position, $userId]);
        }
        
        $msg = "Profiliniz güncellendi!";
        
        // Güncel bilgileri yeniden çek
        $stmt = $pdo->prepare("
            SELECT u.*, r.role_name, c.name as company_name
            FROM users u
            LEFT JOIN roles r ON u.role_id = r.id
            LEFT JOIN companies c ON u.company_id = c.id
            WHERE u.id = ?
        ");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        $err = "Hata: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Profilim</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>

<div class="container-fluid p-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-person-circle"></i> Profilim</h2>
        </div>
        <div class="col-auto">
            <a href="dashboard.php" class="btn btn-secondary">
                <i class="bi bi-house"></i> Dashboard
            </a>
        </div>
    </div>

    <?php if($msg): ?>
        <div class="alert alert-success"><?= e($msg) ?></div>
    <?php endif; ?>
    
    <?php if($err): ?>
        <div class="alert alert-danger"><?= e($err) ?></div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <div class="user-avatar bg-primary text-white rounded-circle mx-auto mb-3"
                         style="width: 100px; height: 100px; display: flex; align-items: center; justify-content: center; font-size: 48px; font-weight: bold;">
                        <?= strtoupper(substr($user['name'], 0, 1)) ?>
                    </div>
                    <h4><?= e($user['name']) ?></h4>
                    <p class="text-muted"><?= e($user['email']) ?></p>
                    <hr>
                    <div class="text-start">
                        <p><strong>Rol:</strong> <?= e($user['role_name'] ?? $user['role']) ?></p>
                        <p><strong>Şirket:</strong> <?= e($user['company_name'] ?? '-') ?></p>
                        <p><strong>Kayıt:</strong> <?= date('d.m.Y', strtotime($user['created_at'])) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Profil Bilgileri</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Ad Soyad *</label>
                                <input type="text" name="name" class="form-control" 
                                       value="<?= e($user['name']) ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email *</label>
                                <input type="email" name="email" class="form-control" 
                                       value="<?= e($user['email']) ?>" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Telefon</label>
                                <input type="text" name="phone" class="form-control" 
                                       value="<?= e($user['phone'] ?? '') ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Departman</label>
                                <input type="text" name="department" class="form-control" 
                                       value="<?= e($user['department'] ?? '') ?>">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Pozisyon</label>
                            <input type="text" name="position" class="form-control" 
                                   value="<?= e($user['position'] ?? '') ?>">
                        </div>

                        <hr>

                        <h6>Şifre Değiştir (Opsiyonel)</h6>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Mevcut Şifre</label>
                                <input type="password" name="current_password" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Yeni Şifre</label>
                                <input type="password" name="new_password" class="form-control">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-circle"></i> Güncelle
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>