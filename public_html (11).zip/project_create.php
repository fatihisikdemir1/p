<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require __DIR__ . "/auth.php";

$msg = "";
$err = "";

// Proje oluşturma
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['create_project'])) {
    try {
        $name = trim($_POST['name'] ?? "");
        $description = trim($_POST['description'] ?? "");
        $projectCompanyId = is_super_admin() ? ((int)($_POST['company_id'] ?? 0)) : $companyId;
        $members = $_POST['members'] ?? []; // Çoklu seçim
        
        if (empty($name)) {
            throw new Exception("Proje adı zorunludur");
        }
        
        if ($projectCompanyId === 0) {
            throw new Exception("Firma seçimi zorunludur");
        }
        
        // Projeyi oluştur
        $stmt = $pdo->prepare("
            INSERT INTO projects (name, description, company_id, created_by, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$name, $description, $projectCompanyId, $userId]);
        
        $projectId = $pdo->lastInsertId();
        
        // Proje üyelerini ekle
        if (!empty($members)) {
            $stmt = $pdo->prepare("
                INSERT INTO project_members (project_id, user_id, role, joined_at)
                VALUES (?, ?, 'member', NOW())
            ");
            
            foreach ($members as $memberId) {
                $memberId = (int)$memberId;
                if ($memberId > 0) {
                    try {
                        $stmt->execute([$projectId, $memberId]);
                    } catch (Exception $e) {
                        // Duplicate ise geç
                    }
                }
            }
        }
        
        // Oluşturanı da üye olarak ekle
        try {
            $stmt = $pdo->prepare("
                INSERT INTO project_members (project_id, user_id, role, joined_at)
                VALUES (?, ?, 'owner', NOW())
            ");
            $stmt->execute([$projectId, $userId]);
        } catch (Exception $e) {}
        
        header("Location: projects.php?msg=created");
        exit;
        
    } catch (Exception $e) {
        $err = $e->getMessage();
    }
}

// Kullanıcıları çek
if (is_super_admin()) {
    $users = $pdo->query("SELECT id, name, email, company_id FROM users ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
    $companies = $pdo->query("SELECT * FROM companies ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("SELECT id, name, email FROM users WHERE company_id = ? ORDER BY name");
    $stmt->execute([$companyId]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $companies = [];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Yeni Proje Oluştur</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
<style>
body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 30px; }
.form-container { max-width: 800px; margin: 0 auto; background: white; border-radius: 20px; padding: 40px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); }
.form-header { border-bottom: 3px solid #667eea; padding-bottom: 20px; margin-bottom: 30px; }
.form-section { background: #f8fafc; border-radius: 15px; padding: 25px; margin-bottom: 25px; }
.section-title { color: #667eea; font-weight: 700; margin-bottom: 20px; font-size: 18px; }
</style>
</head>
<body>

<div class="form-container">
    <div class="form-header">
        <h2 style="color: #667eea;"><i class="bi bi-folder-plus"></i> Yeni Proje Oluştur</h2>
        <p class="text-muted mb-0">Çoklu üye ataması ile proje</p>
    </div>

    <?php if ($err): ?>
        <div class="alert alert-danger">
            <i class="bi bi-exclamation-triangle"></i> <?= $err ?>
        </div>
    <?php endif; ?>

    <form method="post">
        
        <!-- Temel Bilgiler -->
        <div class="form-section">
            <div class="section-title"><i class="bi bi-info-circle"></i> Proje Bilgileri</div>
            
            <div class="mb-3">
                <label class="form-label fw-bold">Proje Adı *</label>
                <input type="text" name="name" class="form-control form-control-lg" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-bold">Açıklama</label>
                <textarea name="description" class="form-control" rows="4"></textarea>
            </div>

            <?php if (is_super_admin() && !empty($companies)): ?>
            <div class="mb-3">
                <label class="form-label fw-bold">Firma *</label>
                <select name="company_id" class="form-select" required>
                    <option value="">Seçiniz...</option>
                    <?php foreach ($companies as $company): ?>
                        <option value="<?= $company['id'] ?>"><?= htmlspecialchars($company['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
        </div>

        <!-- Çoklu Üye Atama -->
        <div class="form-section">
            <div class="section-title"><i class="bi bi-people-fill"></i> Proje Üyeleri (Çoklu Seçim)</div>
            
            <div class="mb-3">
                <label class="form-label fw-bold">Proje Üyeleri</label>
                <select name="members[]" id="projectMembers" class="form-select" multiple>
                    <?php foreach ($users as $user): ?>
                        <option value="<?= $user['id'] ?>">
                            <?= htmlspecialchars($user['name']) ?> (<?= htmlspecialchars($user['email']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <small class="text-muted">
                    <i class="bi bi-info-circle"></i> 
                    Ctrl/Cmd tuşu ile birden fazla üye seçebilirsiniz. Siz otomatik olarak proje sahibi olarak ekleneceksiniz.
                </small>
            </div>
        </div>

        <div class="d-flex gap-2">
            <button type="submit" name="create_project" class="btn btn-primary btn-lg flex-fill">
                <i class="bi bi-check-circle"></i> Projeyi Oluştur
            </button>
            <a href="projects.php" class="btn btn-secondary btn-lg">
                <i class="bi bi-x-circle"></i> İptal
            </a>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() {
    $('#projectMembers').select2({
        theme: 'bootstrap-5',
        placeholder: 'Üyeleri seçin...',
        allowClear: true,
        width: '100%'
    });
});
</script>

</body>
</html>