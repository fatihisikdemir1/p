<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/db.php";
require __DIR__ . "/config/rbac.php";

header("Content-Type: application/json; charset=UTF-8");

function out(bool $ok, array $arr = []): void {
  echo json_encode(array_merge(["ok" => $ok], $arr), JSON_UNESCAPED_UNICODE);
  exit;
}

$role = current_user_role();

if (($_SERVER["REQUEST_METHOD"] ?? "") !== "POST") out(false, ["error" => "Invalid method"]);
if ($role === "user") out(false, ["error" => "Silme yetkin yok"]);

$taskId = (int)($_POST["task_id"] ?? 0);
if ($taskId <= 0) out(false, ["error" => "task_id eksik/hatali"]);

try {
  $st = $pdo->prepare("SELECT id FROM tasks WHERE id=? LIMIT 1");
  $st->execute([$taskId]);
  if (!$st->fetchColumn()) out(false, ["error" => "Görev bulunamadı"]);

  $del = $pdo->prepare("DELETE FROM tasks WHERE id=? LIMIT 1");
  $del->execute([$taskId]);

  out(true, ["task_id" => $taskId]);

} catch (Throwable $e) {
  out(false, ["error" => "Silme hatası", "detail"=>$e->getMessage()]);
}
