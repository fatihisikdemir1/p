<?php
require __DIR__ . "/auth.php";

// Projeler çek
$projects = [];
if (is_super_admin()) {
    $stmt = $pdo->query("SELECT p.*, (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count FROM projects p ORDER BY p.created_at DESC");
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
} elseif ($userRole === 'company_admin') {
    $stmt = $pdo->prepare("SELECT p.*, (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count FROM projects p WHERE p.company_id = ? ORDER BY p.created_at DESC");
    $stmt->execute([$companyId]);
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("SELECT p.*, (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count FROM projects p WHERE p.company_id = ? AND p.created_by = ? ORDER BY p.created_at DESC");
    $stmt->execute([$companyId, $userId]);
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Her proje için görevleri + dosyaları çek
foreach ($projects as &$project) {
    if ($userRole === 'user') {
        $stmt = $pdo->prepare("SELECT t.* FROM tasks t WHERE t.project_id = ? AND (t.assigned_to = ? OR t.created_by = ?)");
        $stmt->execute([$project['id'], $userId, $userId]);
    } else {
        $stmt = $pdo->prepare("SELECT t.* FROM tasks t WHERE t.project_id = ?");
        $stmt->execute([$project['id']]);
    }
    $project['tasks'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Dosyaları çek
    foreach ($project['tasks'] as &$task) {
        $stmt = $pdo->prepare("SELECT file_name, file_path, file_size FROM task_files WHERE task_id = ?");
        $stmt->execute([$task['id']]);
        $task['files'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Debug Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-5">
<div class="container">
<h1>🔍 Dashboard Debug</h1>

<?php foreach ($projects as $project): ?>
<div class="card mb-3">
    <div class="card-header">
        <h3><?= htmlspecialchars($project['name']) ?> (<?= count($project['tasks']) ?> görev)</h3>
    </div>
    <div class="card-body">
        <?php if (empty($project['tasks'])): ?>
            <p class="text-muted">Bu projede görev yok</p>
        <?php else: ?>
            <?php foreach ($project['tasks'] as $task): ?>
            <div class="border p-3 mb-2">
                <h5>Task ID: <?= $task['id'] ?> - <?= htmlspecialchars($task['title']) ?></h5>
                <p><strong>Dosya Sayısı:</strong> <?= count($task['files']) ?></p>
                
                <?php if (!empty($task['files'])): ?>
                <ul>
                    <?php foreach ($task['files'] as $file): ?>
                    <li>
                        📄 <?= htmlspecialchars($file['file_name']) ?>
                        (<?= number_format($file['file_size'] / 1024, 1) ?> KB)
                        <br>
                        <small class="text-muted">Yol: <?= htmlspecialchars($file['file_path']) ?></small>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php else: ?>
                <p class="text-danger">❌ Bu görevde dosya YOK</p>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; ?>

<?php if (empty($projects)): ?>
<div class="alert alert-warning">Hiç proje yok</div>
<?php endif; ?>

</div>
</body>
</html>