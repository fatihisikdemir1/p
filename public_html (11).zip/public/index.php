<?php
declare(strict_types=1);

// public/ klasörü yanlış include'lar yüzünden hata üretiyor.
// En güvenlisi root entrypoint'e yönlendirmek.
header('Location: ../index.php');
exit;

