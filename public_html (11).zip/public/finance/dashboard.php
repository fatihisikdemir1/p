<?php
declare(strict_types=1);

/**
 * Buraya kendi sistemindeki bootstrap/auth dosyalarını koy:
 * örn: require __DIR__ . "/../../app/config.php";
 * örn: require __DIR__ . "/../../app/auth.php";
 */
// require __DIR__ . "/../../app/config.php";
// require __DIR__ . "/../../app/auth.php";

$pageTitle = "Finans Dashboard";

// Mevcut login sisteminden çek
$currentUserName = $currentUserName ?? "Ahmet Bey";

/** Demo datalar (sonra DB’den dolduracağız) */
$kpi = [
  "kasa" => 25000,
  "banka" => 150000,
  "bekleyen" => 24000,
  "alacak" => 45000,
  "toplam" => 45000
];

$odemeler = [
  ["durum"=>"Onay Bekleye", "firma"=>"XYZ Hizmet AŞ", "tutar"=>8500, "vade"=>"12.03.2026"],
  ["durum"=>"Onay Bekleye", "firma"=>"ACME Ltd.", "tutar"=>12000, "vade"=>"15.05.2026"],
  ["durum"=>"Onay Bekleye", "firma"=>"ABC Teknoloji AŞ", "tutar"=>5000, "vade"=>"12.05.2026"],
  ["durum"=>"Onay Bekleye", "firma"=>"NetBilgi Ltd.", "tutar"=>17500, "vade"=>"15.05.2026"],
];

$islemGecmisi = [
  ["tarih"=>"19.09.2026", "firma"=>"ACME Ltd.", "islem"=>"Proje Ödemesi", "tutar"=>-12000],
  ["tarih"=>"14.09.2026", "firma"=>"ABC Teknoloji AŞ", "islem"=>"Ürün Alımı", "tutar"=>-6000],
  ["tarih"=>"17.09.2026", "firma"=>"NetBilgi Ltd.", "islem"=>"Hizmet Ekturası", "tutar"=>-7500],
];

require __DIR__ . "/_layout_top.php";
?>

<div class="fy-content">

  <div class="d-flex align-items-center justify-content-between gap-3 mb-3">
    <h3 class="fy-page-title mb-0">Finans Dashboard</h3>
    <a class="btn fy-btn-success" href="#">
      <i class="fa-solid fa-plus me-2"></i> Yeni Ödeme Talebi
    </a>
  </div>

  <!-- KPI CARDS -->
  <div class="row g-3 mb-3">
    <div class="col-12 col-md-6 col-xl">
      <div class="fy-card kpi">
        <div class="kpi-ico"><i class="fa-solid fa-wallet"></i></div>
        <div class="kpi-meta">
          <div class="kpi-title">Kasa Bakiyesi</div>
          <div class="kpi-val"><?= number_format($kpi["kasa"], 0, ",", ".") ?> ₺</div>
        </div>
        <button class="fy-kpi-more" type="button"><i class="fa-solid fa-ellipsis"></i></button>
      </div>
    </div>

    <div class="col-12 col-md-6 col-xl">
      <div class="fy-card kpi">
        <div class="kpi-ico"><i class="fa-solid fa-building-columns"></i></div>
        <div class="kpi-meta">
          <div class="kpi-title">Banka Bakiyesi</div>
          <div class="kpi-val"><?= number_format($kpi["banka"], 0, ",", ".") ?> ₺</div>
        </div>
        <button class="fy-kpi-more" type="button"><i class="fa-solid fa-ellipsis"></i></button>
      </div>
    </div>

    <div class="col-12 col-md-6 col-xl">
      <div class="fy-card kpi">
        <div class="kpi-ico warn"><i class="fa-regular fa-clock"></i></div>
        <div class="kpi-meta">
          <div class="kpi-title">Bekleyen Ödemeler</div>
          <div class="kpi-val text-warning"><?= number_format($kpi["bekleyen"], 0, ",", ".") ?> ₺</div>
        </div>
        <button class="fy-kpi-more" type="button"><i class="fa-solid fa-ellipsis"></i></button>
      </div>
    </div>

    <div class="col-12 col-md-6 col-xl">
      <div class="fy-card kpi">
        <div class="kpi-ico good"><i class="fa-solid fa-arrow-trend-up"></i></div>
        <div class="kpi-meta">
          <div class="kpi-title">Alacak Bakiyesi</div>
          <div class="kpi-val text-success"><?= number_format($kpi["alacak"], 0, ",", ".") ?> ₺</div>
        </div>
        <button class="fy-kpi-more" type="button"><i class="fa-solid fa-ellipsis"></i></button>
      </div>
    </div>

    <div class="col-12 col-md-6 col-xl">
      <div class="fy-card kpi">
        <div class="kpi-ico home"><i class="fa-solid fa-house-chimney"></i></div>
        <div class="kpi-meta">
          <div class="kpi-title">Toplan-4um</div>
          <div class="kpi-val"><?= number_format($kpi["toplam"], 0, ",", ".") ?> ₺</div>
        </div>
        <button class="fy-kpi-more" type="button"><i class="fa-solid fa-ellipsis"></i></button>
      </div>
    </div>
  </div>

  <div class="row g-3">
    <!-- LEFT (chart + tables) -->
    <div class="col-12 col-xl-8">

      <!-- CHART -->
      <div class="fy-card mb-3">
        <div class="fy-card-head">
          <div class="fy-card-title">Cari Bakiyesi</div>
          <div class="fy-card-tools">
            <button class="fy-toolbtn" type="button" title="Yazı boyutu"><i class="fa-solid fa-font"></i></button>
            <button class="fy-toolbtn" type="button" title="Tablo"><i class="fa-solid fa-table"></i></button>
            <button class="fy-toolbtn" type="button" title="Grafik"><i class="fa-solid fa-chart-column"></i></button>
          </div>
        </div>
        <div class="fy-card-body">
          <canvas id="cariChart" height="110"></canvas>
        </div>
      </div>

      <!-- ÖDEME TALEPLERİ -->
      <div class="fy-card mb-3">
        <div class="fy-card-head">
          <div class="fy-card-title">Ödeme Talepleri</div>
          <div class="fy-card-sub">Son 90 dk. içinde</div>
        </div>

        <div class="table-responsive">
          <table class="table fy-table align-middle mb-0">
            <thead>
              <tr>
                <th style="width:140px">Durum</th>
                <th>Firma</th>
                <th style="width:140px">Tutar</th>
                <th style="width:140px">Vade</th>
                <th style="width:200px">İşlem</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($odemeler as $o): ?>
              <tr>
                <td><span class="fy-status"><?= htmlspecialchars($o["durum"], ENT_QUOTES, 'UTF-8') ?></span></td>
                <td><?= htmlspecialchars($o["firma"], ENT_QUOTES, 'UTF-8') ?></td>
                <td class="fw-semibold"><?= number_format((float)$o["tutar"], 0, ",", ".") ?> ₺</td>
                <td class="text-muted"><?= htmlspecialchars($o["vade"], ENT_QUOTES, 'UTF-8') ?></td>
                <td class="text-end">
                  <a class="btn btn-sm fy-btn-primary" href="#"><i class="fa-solid fa-magnifying-glass me-1"></i> İNCELE</a>
                  <a class="btn btn-sm fy-btn-secondary" href="#"><i class="fa-solid fa-credit-card me-1"></i> ÖDE</a>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- İŞLEM GEÇMİŞİ -->
      <div class="fy-card">
        <div class="fy-card-head">
          <div class="fy-card-title">İşlem Geçmişi</div>
          <div class="fy-card-sub">Son 90 dk. içinde</div>
        </div>

        <div class="table-responsive">
          <table class="table fy-table align-middle mb-0">
            <thead>
              <tr>
                <th style="width:140px">Tarih</th>
                <th>Firma</th>
                <th>İşlem</th>
                <th style="width:160px" class="text-end">Tutar</th>
                <th style="width:190px" class="text-end">İşlemler</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($islemGecmisi as $x): ?>
              <tr>
                <td class="text-muted"><?= htmlspecialchars($x["tarih"], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($x["firma"], ENT_QUOTES, 'UTF-8') ?></td>
                <td><?= htmlspecialchars($x["islem"], ENT_QUOTES, 'UTF-8') ?></td>
                <td class="text-end fw-semibold <?= ($x["tutar"] < 0 ? "text-danger" : "text-success") ?>">
                  <?= number_format((float)$x["tutar"], 0, ",", ".") ?> ₺
                </td>
                <td class="text-end">
                  <a class="btn btn-sm fy-btn-primary" href="#">İNCELE</a>
                  <a class="btn btn-sm fy-btn-secondary" href="#">ÖDE</a>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>

    <!-- RIGHT widgets -->
    <div class="col-12 col-xl-4">

      <div class="fy-card mb-3">
        <div class="fy-card-head">
          <div class="fy-card-title">Banka &amp; Kasa</div>
          <button class="fy-toolbtn" type="button"><i class="fa-solid fa-ellipsis"></i></button>
        </div>
        <div class="fy-list">
          <div class="fy-list-row"><span>İş Bankası (TRY)</span><strong>120.000 ₺</strong></div>
          <div class="fy-list-row"><span>Garanti Bankası (USD)</span><strong>4,200 $</strong></div>
          <div class="fy-list-row"><span>Kasa</span><strong>25.000 ₺</strong></div>
        </div>
      </div>

      <div class="fy-card mb-3">
        <div class="fy-card-head">
          <div class="fy-card-title">Krediler</div>
          <button class="fy-toolbtn" type="button"><i class="fa-solid fa-ellipsis"></i></button>
        </div>
        <div class="fy-list">
          <div class="fy-list-row">
            <span>Kredibilitesi <span class="fy-star">★</span> A (iyi)</span>
            <strong>25.000 ₺</strong>
          </div>
          <div class="fy-list-row"><span>Vakıfbank</span><span class="text-muted">Duru 15.08.2024</span></div>
          <div class="fy-list-row"><span>Akbank</span><span class="text-muted">Duru 20.05.2024</span></div>
        </div>
      </div>

      <div class="fy-card">
        <div class="fy-card-head">
          <div class="fy-card-title">Analiz &amp; Raporlama</div>
          <button class="fy-toolbtn" type="button"><i class="fa-solid fa-ellipsis"></i></button>
        </div>
        <div class="fy-card-body">
          <div class="fw-semibold mb-2">Alacak &amp; Borç Grafiği</div>
          <canvas id="donutChart" height="170"></canvas>

          <hr class="fy-hr">

          <div class="fw-semibold mb-2">Top Tedarikçilere Göre Giderler</div>
          <div class="fy-bars">
            <div class="fy-bar"><span>NetBilgi</span><div class="fy-barline"><i style="width:55%"></i></div><strong>12.000 ₺</strong></div>
            <div class="fy-bar"><span>XYZ Hizmet AŞ</span><div class="fy-barline"><i style="width:75%"></i></div><strong>18.000 ₺</strong></div>
            <div class="fy-bar"><span>ABC Teknoloji</span><div class="fy-barline"><i style="width:70%"></i></div><strong>18.000 ₺</strong></div>
          </div>
        </div>
      </div>

    </div>
  </div>

</div>

<script>
  // Chart datası (örnek)
  window.__FY_CHARTS__ = {
    cari: {
      labels: ["Oca","Şub","Mar","Nis","May","Haz"],
      alacak: [38, 32, 41, 45, 52, 49],
      borc:   [34, 36, 35, 37, 41, 33]
    },
    donut: {
      labels: ["Alacak", "Borç"],
      values: [45, 55]
    }
  };
</script>

<?php require __DIR__ . "/_layout_bottom.php"; ?>
