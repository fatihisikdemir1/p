<?php
// Layout TOP: head + navbar + sidebar açılış
// Kullanım: require __DIR__."/_layout_top.php";  (dashboard.php içinde)
?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle ?? "Finans Yönetim Sistemi", ENT_QUOTES, 'UTF-8') ?></title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <link href="/assets/finance.css?v=1" rel="stylesheet">
</head>
<body>

<div class="fy-app">
  <!-- TOP NAV -->
  <header class="fy-topbar">
    <div class="fy-top-left">
      <button class="fy-iconbtn" id="btnSidebar" type="button" aria-label="Menü">
        <i class="fa-solid fa-bars"></i>
      </button>
      <div class="fy-brand">
        <span class="fy-brand-strong">Finans</span> <span class="fy-brand-soft">Yönetim Sistemi</span>
      </div>
    </div>

    <nav class="fy-topnav d-none d-lg-flex">
      <a class="fy-toplink active" href="/finance/dashboard.php"><i class="fa-solid fa-gauge"></i> Dashboard</a>
      <a class="fy-toplink" href="#"><i class="fa-solid fa-cart-shopping"></i> Satın Alma</a>
      <a class="fy-toplink" href="#"><i class="fa-solid fa-calculator"></i> Muhasebe</a>
      <a class="fy-toplink" href="#"><i class="fa-regular fa-file-lines"></i> Raporlar</a>
      <a class="fy-toplink" href="#"><i class="fa-solid fa-gear"></i> Ayarlar</a>
    </nav>

    <div class="fy-top-right">
      <button class="fy-iconbtn position-relative" type="button" aria-label="Bildirimler">
        <i class="fa-regular fa-bell"></i>
        <span class="fy-badge-dot">2</span>
      </button>

      <div class="fy-user">
        <img class="fy-avatar" src="https://i.pravatar.cc/40?img=12" alt="avatar">
        <div class="fy-usertext">
          <div class="fy-userhello">Hoşgeldiniz,</div>
          <div class="fy-username"><?= htmlspecialchars($currentUserName ?? "Ahmet Bey", ENT_QUOTES, 'UTF-8') ?></div>
        </div>
      </div>
    </div>
  </header>

  <div class="fy-body">
    <!-- SIDEBAR -->
    <aside class="fy-sidebar" id="sidebar">
      <div class="fy-side-section">
        <div class="fy-side-title"><i class="fa-solid fa-chart-line"></i> Finans Dashboard</div>

        <a class="fy-side-item active" href="/finance/dashboard.php"><i class="fa-solid fa-house"></i> Finans Dashboard</a>

        <a class="fy-side-item" href="#">
          <i class="fa-solid fa-file-invoice-dollar"></i> Ödeme Talepleri
          <span class="fy-pill">5</span>
        </a>

        <a class="fy-side-item" href="#"><i class="fa-solid fa-people-arrows"></i> Cari İşlemler</a>
        <a class="fy-side-item" href="#"><i class="fa-solid fa-building-columns"></i> Banka &amp; Kasa</a>
        <a class="fy-side-item" href="#"><i class="fa-solid fa-receipt"></i> Fatura Yönetimi</a>
        <a class="fy-side-item" href="#"><i class="fa-solid fa-list-check"></i> Ekstreler</a>
        <a class="fy-side-item" href="#"><i class="fa-solid fa-chart-pie"></i> Bütçe Raporları</a>
      </div>

      <div class="fy-side-section">
        <div class="fy-side-title"><i class="fa-solid fa-bolt"></i> Hızlı Erişim</div>
        <a class="fy-side-quick" href="#"><i class="fa-solid fa-plus"></i> Yeni Ödeme Talebi</a>
        <a class="fy-side-quick" href="#"><i class="fa-solid fa-user-plus"></i> Cari Ekle</a>
      </div>

      <div class="fy-side-section fy-side-summary">
        <div class="fy-side-title"><i class="fa-solid fa-wallet"></i> Finans Durumu</div>
        <div class="fy-kv"><span>Finallar</span><strong class="text-success">275.000 ₺</strong></div>
        <div class="fy-kv"><span>Giderler</span><strong class="text-danger">125.000 ₺</strong></div>
        <div class="fy-kv"><span>Banka Bakiyesi</span><strong>150.000 ₺</strong></div>
        <div class="fy-kv"><span>Krediler</span><strong>40.000 ₺</strong></div>
      </div>
    </aside>

    <!-- MAIN -->
    <main class="fy-main" id="main">
