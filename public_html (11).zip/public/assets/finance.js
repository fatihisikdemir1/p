(function () {
  // Sidebar toggle
  const btn = document.getElementById("btnSidebar");
  const sidebar = document.getElementById("sidebar");

  if (btn && sidebar) {
    btn.addEventListener("click", () => {
      sidebar.classList.toggle("is-collapsed");
    });
  }

  // Charts
  const data = window.__FY_CHARTS__ || {};
  const cariEl = document.getElementById("cariChart");
  if (cariEl && data.cari) {
    new Chart(cariEl, {
      type: "bar",
      data: {
        labels: data.cari.labels,
        datasets: [
          { label: "Alacak", data: data.cari.alacak },
          { label: "Borç", data: data.cari.borc }
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "bottom" } },
        scales: {
          x: { grid: { display: false } },
          y: { grid: { color: "rgba(0,0,0,0.06)" } }
        }
      }
    });
  }

  const donutEl = document.getElementById("donutChart");
  if (donutEl && data.donut) {
    new Chart(donutEl, {
      type: "doughnut",
      data: {
        labels: data.donut.labels,
        datasets: [{ data: data.donut.values }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "right" } },
        cutout: "62%"
      }
    });
  }
})();
