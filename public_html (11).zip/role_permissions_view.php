<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

if (!can_manage_roles()) {
    die("Yetkiniz yok");
}

$roleId = (int)($_GET["role_id"] ?? 0);

// Rol bilgisini al
$stmt = $pdo->prepare("SELECT * FROM roles WHERE id = ?");
$stmt->execute([$roleId]);
$role = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$role) {
    die("Rol bulunamadı");
}

// Rol yetkilerini al
$stmt = $pdo->prepare("
    SELECT permission_key, permission_value 
    FROM role_permissions 
    WHERE role_id = ?
");
$stmt->execute([$roleId]);
$permissions = $stmt->fetchAll(PDO::FETCH_ASSOC);

$allPermissions = get_all_permissions();
$activePerms = array_column($permissions, 'permission_key');
?>

<div class="mb-3">
    <h6>Rol: <strong><?= htmlspecialchars($role['role_name']) ?></strong></h6>
    <p class="text-muted">Slug: <?= htmlspecialchars($role['role_slug']) ?></p>
</div>

<div class="table-responsive">
    <table class="table table-sm table-bordered">
        <thead>
            <tr>
                <th>Yetki</th>
                <th style="width:100px" class="text-center">Durum</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($allPermissions as $key => $label): ?>
            <tr>
                <td>
                    <strong><?= htmlspecialchars($label) ?></strong><br>
                    <small class="text-muted"><?= htmlspecialchars($key) ?></small>
                </td>
                <td class="text-center">
                    <?php if (in_array($key, $activePerms)): ?>
                        <span class="badge bg-success">✓ Aktif</span>
                    <?php else: ?>
                        <span class="badge bg-secondary">✗ Pasif</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<div class="alert alert-info">
    <strong>Toplam:</strong> <?= count($activePerms) ?> / <?= count($allPermissions) ?> yetki aktif
</div>