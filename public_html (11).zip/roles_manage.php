<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

if (!can_manage_roles()) {
    http_response_code(403);
    die("Bu sayfaya erişim yetkiniz yok.");
}

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$msg = "";
$err = "";

// Yeni rol oluştur
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "create_role") {
    $roleName = trim($_POST["role_name"] ?? "");
    $permissions = $_POST["permissions"] ?? [];
    
    if ($roleName === "") {
        $err = "Rol adı gerekli";
    } else {
        try {
            $roleSlug = strtolower(str_replace(' ', '_', $roleName));
            
            if ($roleSlug === 'super_admin' && !can_create_super_admin()) {
                throw new Exception("Super Admin rolü oluşturamazsınız!");
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO roles (company_id, role_name, role_slug, is_system, created_by, created_at)
                VALUES (?, ?, ?, 0, ?, NOW())
            ");
            $stmt->execute([$companyId, $roleName, $roleSlug, $userId]);
            $roleId = (int)$pdo->lastInsertId();
            
            if ($permissions) {
                $stmt = $pdo->prepare("
                    INSERT INTO role_permissions (role_id, permission_key, permission_value)
                    VALUES (?, ?, 1)
                ");
                foreach ($permissions as $perm) {
                    $stmt->execute([$roleId, $perm]);
                }
            }
            
            $msg = "Rol başarıyla oluşturuldu!";
            
        } catch (Exception $e) {
            $err = "Hata: " . $e->getMessage();
        }
    }
}

// Rol sil - SUPER ADMIN HER ŞEYİ SİLEBİLİR
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "delete_role") {
    $roleId = (int)($_POST["role_id"] ?? 0);
    
    try {
        $stmt = $pdo->prepare("SELECT is_system, role_slug, role_name FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        $role = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$role) {
            throw new Exception("Rol bulunamadı!");
        }
        
        // Sadece super admin sistem rollerini silebilir
        if ((int)$role['is_system'] === 1 && !is_super_admin()) {
            throw new Exception("Sadece Super Admin sistem rollerini silebilir!");
        }
        
        // Kullanıcı sayısını kontrol et
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role_id = ?");
        $stmt->execute([$roleId]);
        $userCount = (int)$stmt->fetchColumn();
        
        // Kullanıcıları otomatik "user" rolüne ata
        if ($userCount > 0) {
            // Silinecek rol "user" ise, başka bir role ata
            if ($role['role_slug'] === 'user') {
                // "user" rolü siliniyorsa, company_admin'e ata
                $stmt = $pdo->prepare("SELECT id FROM roles WHERE role_slug = 'company_admin' AND is_system = 1 LIMIT 1");
                $stmt->execute();
                $fallbackRoleId = (int)$stmt->fetchColumn();
                $fallbackSlug = 'company_admin';
            } else {
                // Diğer roller için "user"a ata
                $stmt = $pdo->prepare("SELECT id FROM roles WHERE role_slug = 'user' AND is_system = 1 LIMIT 1");
                $stmt->execute();
                $fallbackRoleId = (int)$stmt->fetchColumn();
                $fallbackSlug = 'user';
            }
            
            if (!$fallbackRoleId) {
                throw new Exception("Kullanıcıları atamak için uygun rol bulunamadı!");
            }
            
            $stmt = $pdo->prepare("UPDATE users SET role_id = ?, role = ? WHERE role_id = ?");
            $stmt->execute([$fallbackRoleId, $fallbackSlug, $roleId]);
        }
        
        // Yetkileri sil
        $pdo->prepare("DELETE FROM role_permissions WHERE role_id = ?")->execute([$roleId]);
        
        // Rolü sil
        $pdo->prepare("DELETE FROM roles WHERE id = ?")->execute([$roleId]);
        
        if ($userCount > 0) {
            $msg = "'{$role['role_name']}' rolü silindi! {$userCount} kullanıcı '{$fallbackSlug}' rolüne atandı.";
        } else {
            $msg = "'{$role['role_name']}' rolü silindi!";
        }
        
    } catch (Exception $e) {
        $err = "Hata: " . $e->getMessage();
    }
}

// Rol düzenle
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "edit_role") {
    $roleId = (int)($_POST["role_id"] ?? 0);
    $roleName = trim($_POST["role_name"] ?? "");
    $permissions = $_POST["permissions"] ?? [];
    
    try {
        $stmt = $pdo->prepare("SELECT is_system FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        $isSystem = (int)$stmt->fetchColumn();
        
        // Sadece super admin sistem rollerini düzenleyebilir
        if ($isSystem && !is_super_admin()) {
            throw new Exception("Sadece Super Admin sistem rollerini düzenleyebilir!");
        }
        
        $roleSlug = strtolower(str_replace(' ', '_', $roleName));
        
        $stmt = $pdo->prepare("UPDATE roles SET role_name = ?, role_slug = ? WHERE id = ?");
        $stmt->execute([$roleName, $roleSlug, $roleId]);
        
        $pdo->prepare("DELETE FROM role_permissions WHERE role_id = ?")->execute([$roleId]);
        
        if ($permissions) {
            $stmt = $pdo->prepare("
                INSERT INTO role_permissions (role_id, permission_key, permission_value)
                VALUES (?, ?, 1)
            ");
            foreach ($permissions as $perm) {
                $stmt->execute([$roleId, $perm]);
            }
        }
        
        $msg = "Rol güncellendi!";
        
    } catch (Exception $e) {
        $err = "Hata: " . $e->getMessage();
    }
}

// Rolleri listele
$whereClause = is_super_admin() ? "" : "WHERE (company_id = ? OR company_id IS NULL)";
$params = is_super_admin() ? [] : [$companyId];

$stmt = $pdo->prepare("
    SELECT r.*, 
           COUNT(DISTINCT rp.id) as perm_count,
           COUNT(DISTINCT u.id) as user_count,
           creator.name as creator_name
    FROM roles r
    LEFT JOIN role_permissions rp ON r.id = rp.role_id
    LEFT JOIN users u ON r.id = u.role_id
    LEFT JOIN users creator ON r.created_by = creator.id
    {$whereClause}
    GROUP BY r.id
    ORDER BY r.is_system DESC, r.created_at DESC
");
$stmt->execute($params);
$roles = $stmt->fetchAll(PDO::FETCH_ASSOC);

$allPermissions = get_all_permissions();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Rol Yönetimi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
.role-badge { padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }
.badge-system { background: #667eea; color: white; }
.badge-custom { background: #f59e0b; color: white; }
.perm-list { max-height: 400px; overflow-y: auto; border: 1px solid #dee2e6; border-radius: 4px; padding: 10px; }
</style>
</head>
<body>

<div class="container-fluid p-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-shield-check"></i> Rol Yönetimi</h2>
            <p class="text-muted">Rolleri yönetin ve yetkileri düzenleyin</p>
        </div>
        <div class="col-auto">
            <a href="dashboard.php" class="btn btn-secondary">
                <i class="bi bi-house"></i> Dashboard
            </a>
        </div>
    </div>

    <?php if($msg): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= e($msg) ?>
        </div>
    <?php endif; ?>
    
    <?php if($err): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= e($err) ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-list-ul"></i> Mevcut Roller</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Rol</th>
                                    <th>Kullanıcı</th>
                                    <th>Yetki</th>
                                    <th>Tip</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($roles as $role): ?>
                                <tr>
                                    <td>
                                        <strong><?= e($role['role_name']) ?></strong><br>
                                        <small class="text-muted"><?= e($role['role_slug']) ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-info"><?= (int)$role['user_count'] ?> kişi</span>
                                    </td>
                                    <td><?= (int)$role['perm_count'] ?> yetki</td>
                                    <td>
                                        <?php if ($role['is_system']): ?>
                                            <span class="role-badge badge-system">Sistem</span>
                                        <?php else: ?>
                                            <span class="role-badge badge-custom">Özel</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-info" 
                                                onclick="viewRolePermissions(<?= (int)$role['id'] ?>)">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        
                                        <?php 
                                        // Super admin her şeyi düzenleyebilir/silebilir
                                        // Company admin sadece özel rolleri düzenleyebilir/silebilir
                                        $canModify = is_super_admin() || (!$role['is_system']);
                                        ?>
                                        
                                        <?php if ($canModify): ?>
                                        <button class="btn btn-sm btn-warning" 
                                                onclick="editRole(<?= (int)$role['id'] ?>, '<?= e($role['role_name']) ?>')">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        
                                        <form method="post" style="display:inline" 
                                              onsubmit="return confirm('<?= e($role['role_name']) ?> rolünü silmek istediğinize emin misiniz?\n\n<?= (int)$role['user_count'] ?> kullanıcı başka role atanacak.')">
                                            <input type="hidden" name="action" value="delete_role">
                                            <input type="hidden" name="role_id" value="<?= (int)$role['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="bi bi-plus-circle"></i> Yeni Rol Oluştur</h5>
                </div>
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="action" value="create_role">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Rol Adı *</label>
                            <input type="text" name="role_name" class="form-control" 
                                   placeholder="örn: Proje Yöneticisi" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Yetkiler</label>
                            <div class="perm-list">
                                <?php foreach ($allPermissions as $key => $label): ?>
                                    <?php if ($key === 'create_super_admin' && !is_super_admin()) continue; ?>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" 
                                               name="permissions[]" value="<?= e($key) ?>" 
                                               id="perm_<?= e($key) ?>">
                                        <label class="form-check-label" for="perm_<?= e($key) ?>">
                                            <strong><?= e($label) ?></strong>
                                            <br><small class="text-muted"><?= e($key) ?></small>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success w-100">
                            <i class="bi bi-plus-circle"></i> Rol Oluştur
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="alert alert-warning mt-3">
                <strong><i class="bi bi-shield-exclamation"></i> Yetkiler:</strong><br>
                <?php if (is_super_admin()): ?>
                    <span class="badge bg-danger">Super Admin</span><br>
                    • Tüm rolleri düzenleyebilir<br>
                    • Tüm rolleri silebilir<br>
                    • Sistem rollerini yönetebilir
                <?php else: ?>
                    <span class="badge bg-primary">Company Admin</span><br>
                    • Sadece özel rolleri düzenleyebilir<br>
                    • Sadece özel rolleri silebilir<br>
                    • Sistem rollerine dokunamaz
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modals -->
<div class="modal fade" id="permissionsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Rol Yetkileri</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="permissionsContent">
                <div class="text-center"><div class="spinner-border"></div></div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editRoleModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Rol Düzenle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body" id="editRoleContent">
                    <div class="text-center"><div class="spinner-border"></div></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function viewRolePermissions(roleId) {
    const modal = new bootstrap.Modal(document.getElementById('permissionsModal'));
    modal.show();
    
    fetch(`role_permissions_view.php?role_id=${roleId}`)
        .then(r => r.text())
        .then(html => {
            document.getElementById('permissionsContent').innerHTML = html;
        })
        .catch(err => {
            document.getElementById('permissionsContent').innerHTML = 
                '<div class="alert alert-danger">Yüklenemedi</div>';
        });
}

function editRole(roleId, roleName) {
    const modal = new bootstrap.Modal(document.getElementById('editRoleModal'));
    modal.show();
    
    fetch(`role_edit_form.php?role_id=${roleId}`)
        .then(r => r.text())
        .then(html => {
            document.getElementById('editRoleContent').innerHTML = html;
        })
        .catch(err => {
            document.getElementById('editRoleContent').innerHTML = 
                '<div class="alert alert-danger">Yüklenemedi</div>';
        });
}
</script>

</body>
</html>