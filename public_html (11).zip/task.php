<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require __DIR__ . "/auth.php";

$view = $_GET['view'] ?? $_COOKIE['tasks_view'] ?? 'card';
if (isset($_GET['view'])) {
    setcookie('tasks_view', $view, time() + 86400 * 30, '/');
}

$activeTaskId = (int)($_GET['task'] ?? 0);

// Görevleri çek
if (is_super_admin()) {
    $stmt = $pdo->query("SELECT t.*, p.name as project_name, u1.name as assigned_user_name, u2.name as creator_name FROM tasks t LEFT JOIN projects p ON t.project_id = p.id LEFT JOIN users u1 ON t.assigned_to = u1.id LEFT JOIN users u2 ON t.created_by = u2.id ORDER BY t.created_at DESC");
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} elseif (has_permission('view_all_tasks')) {
    $stmt = $pdo->prepare("SELECT t.*, p.name as project_name, u1.name as assigned_user_name, u2.name as creator_name FROM tasks t LEFT JOIN projects p ON t.project_id = p.id LEFT JOIN users u1 ON t.assigned_to = u1.id LEFT JOIN users u2 ON t.created_by = u2.id WHERE p.company_id = ? ORDER BY t.created_at DESC");
    $stmt->execute([$companyId]);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("SELECT t.*, p.name as project_name, u1.name as assigned_user_name, u2.name as creator_name FROM tasks t LEFT JOIN projects p ON t.project_id = p.id LEFT JOIN users u1 ON t.assigned_to = u1.id LEFT JOIN users u2 ON t.created_by = u2.id WHERE p.company_id = ? AND (t.assigned_to = ? OR t.created_by = ?) ORDER BY t.created_at DESC");
    $stmt->execute([$companyId, $userId, $userId]);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Aktif görev detayları
$activeTask = null;
$taskComments = [];
$taskFiles = [];
if ($activeTaskId > 0) {
    $stmt = $pdo->prepare("SELECT t.*, p.name as project_name FROM tasks t LEFT JOIN projects p ON t.project_id = p.id WHERE t.id = ?");
    $stmt->execute([$activeTaskId]);
    $activeTask = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($activeTask) {
        try {
            $stmt = $pdo->prepare("SELECT c.*, u.name as user_name FROM task_comments c LEFT JOIN users u ON c.user_id = u.id WHERE c.task_id = ? ORDER BY c.created_at ASC");
            $stmt->execute([$activeTaskId]);
            $taskComments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $stmt = $pdo->prepare("SELECT f.*, u.name as uploader_name FROM task_files f LEFT JOIN users u ON f.uploaded_by = u.id WHERE f.task_id = ? ORDER BY f.uploaded_at DESC");
            $stmt->execute([$activeTaskId]);
            $taskFiles = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {}
    }
}

// Yorum ekleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_comment']) && $activeTaskId > 0) {
    try {
        $comment = trim($_POST['comment'] ?? "");
        if (!empty($comment)) {
            preg_match_all('/@(\w+)/', $comment, $matches);
            $mentions = array_unique($matches[1]);
            
            $stmt = $pdo->prepare("INSERT INTO task_comments (task_id, user_id, comment, mentions, created_at) VALUES (?, ?, ?, ?, NOW())");
            $mentionsJson = !empty($mentions) ? json_encode($mentions) : null;
            $stmt->execute([$activeTaskId, $userId, $comment, $mentionsJson]);
            
            header("Location: tasks.php?task=$activeTaskId&msg=comment_added");
            exit;
        }
    } catch (Exception $e) {}
}

$statusColors = ['pending' => 'warning', 'in_progress' => 'info', 'completed' => 'success'];
$priorityColors = ['low' => 'success', 'medium' => 'warning', 'high' => 'danger'];
?>
<?php
$pageTitle = 'FinansConnect • Görevler';
$breadcrumbs = array(array('label' => 'FinansConnect', 'href' => '/dashboard.php'), array('label' => 'Görevler', 'href' => null));
$extraHead = '<style>
body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 30px; }
.page-container { max-width: 1600px; margin: 0 auto; }
.header-card { background: white; border-radius: 20px; padding: 25px 35px; margin-bottom: 25px; box-shadow: 0 8px 32px rgba(0,0,0,0.12); border: 2px solid rgba(255,255,255,0.8); }
.view-toggle { background: linear-gradient(135deg, #f8fafc, #e2e8f0); border-radius: 12px; padding: 6px; display: inline-flex; box-shadow: inset 0 2px 8px rgba(0,0,0,0.06); }
.view-toggle .btn { border: none; border-radius: 10px; padding: 10px 24px; font-weight: 600; transition: all 0.3s; }
.view-toggle .btn.active { background: linear-gradient(135deg, #667eea, #764ba2); color: white; box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4); transform: translateY(-2px); }

.task-card { background: white; border-radius: 16px; padding: 24px; margin-bottom: 20px; transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); cursor: pointer; box-shadow: 0 4px 16px rgba(0,0,0,0.08); border: 2px solid transparent; position: relative; overflow: hidden; }
.task-card::before { content: \'\'; position: absolute; top: 0; left: 0; width: 5px; height: 100%; background: var(--card-color, linear-gradient(135deg, #667eea, #764ba2)); }
.task-card:hover { transform: translateY(-8px); box-shadow: 0 12px 40px rgba(0,0,0,0.15); border-color: var(--card-color-solid, #667eea); }
.task-card.active { border: 3px solid var(--card-color-solid, #667eea); box-shadow: 0 12px 40px rgba(102, 126, 234, 0.3); }
.task-card.priority-high { --card-color: linear-gradient(135deg, #f43f5e, #dc2626); --card-color-solid: #f43f5e; }
.task-card.priority-medium { --card-color: linear-gradient(135deg, #f59e0b, #d97706); --card-color-solid: #f59e0b; }
.task-card.priority-low { --card-color: linear-gradient(135deg, #10b981, #059669); --card-color-solid: #10b981; }

.task-card-title { font-size: 20px; font-weight: 700; margin-bottom: 12px; color: #1e293b; line-height: 1.4; }
.task-badge { padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-block; margin: 4px; }
.task-detail-panel { background: white; border-radius: 20px; padding: 35px; margin-top: 25px; box-shadow: 0 8px 32px rgba(0,0,0,0.12); display: none; border: 2px solid rgba(102, 126, 234, 0.2); }
.task-detail-panel.active { display: block; animation: slideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
@keyframes slideIn { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
.comment-item { background: linear-gradient(135deg, #f8fafc, #f1f5f9); border-radius: 12px; padding: 18px; margin-bottom: 14px; border-left: 4px solid #cbd5e1; }
.comment-item.own { background: linear-gradient(135deg, #dbeafe, #bfdbfe); border-left-color: #667eea; }
</style>';
require __DIR__ . "/shared/layout_head.php";
require __DIR__ . "/menu.php";
?>
<main class="content">
  <div class="topbar">
    <div class="crumbs">
      <?php
        if (!empty($breadcrumbs)) {
          $last = count($breadcrumbs)-1;
          foreach($breadcrumbs as $i=>$c){
            $lab = $c['label'] ?? '';
            $href = $c['href'] ?? '';
            if ($href) {
              echo '<a href="'.e($href).'">'.e($lab).'</a>';
            } else {
              echo '<span style="font-weight:950">'.e($lab).'</span>';
            }
            if ($i !== $last) echo '<span class="sep">/</span>';
          }
        }
      ?>
    </div>
    <div style="display:flex;gap:10px;align-items:center;flex:1;justify-content:flex-end">
      <form class="search" method="get" action="/task.php" style="max-width:680px">
        <i class="bi bi-search"></i>
        <input name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Arama: görev, proje, kullanıcı…">
      </form>
      <span class="pill"><i class="bi bi-person-circle"></i> <?= e($_SESSION['user']['name'] ?? 'Kullanıcı') ?></span>
    </div>
  </div>

  <div style="height:14px"></div>

  <div class="page-container">
    <div class="header-card">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h2 class="mb-0" style="background: linear-gradient(135deg, #667eea, #764ba2); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                    <i class="bi bi-check-square"></i> Görevlerim
                </h2>
                <small class="text-muted fw-bold"><?= count($tasks) ?> görev</small>
            </div>
            <div class="col-md-4 text-center">
                <div class="view-toggle">
                    <a href="?view=card<?= $activeTaskId > 0 ? '&task=' . $activeTaskId : '' ?>" class="btn <?= $view === 'card' ? 'active' : '' ?>">
                        <i class="bi bi-grid-3x3"></i> Kart
                    </a>
                    <a href="?view=list<?= $activeTaskId > 0 ? '&task=' . $activeTaskId : '' ?>" class="btn <?= $view === 'list' ? 'active' : '' ?>">
                        <i class="bi bi-list-ul"></i> Liste
                    </a>
                </div>
            </div>
            <div class="col-md-4 text-end">
                <a href="task_create.php" class="btn btn-success btn-lg"><i class="bi bi-plus-circle"></i> Yeni Görev</a>
                <a href="dashboard.php" class="btn btn-secondary btn-lg"><i class="bi bi-house"></i> Dashboard</a>
            </div>
        </div>
    </div>

    <?php if (empty($tasks)): ?>
        <div class="card"><div class="card-body text-center py-5">
            <i class="bi bi-inbox" style="font-size: 64px; color: #cbd5e1;"></i>
            <h4 class="mt-3 text-muted">Henüz görev yok</h4>
        </div></div>
    <?php else: ?>
        <?php if ($view === 'card'): ?>
            <div class="row">
                <?php foreach ($tasks as $task): ?>
                <div class="col-md-4">
                    <div class="task-card priority-<?= $task['priority'] ?> <?= $activeTaskId === (int)$task['id'] ? 'active' : '' ?>" 
                         ondblclick="window.location.href='task_detail.php?id=<?= $task['id'] ?>';"
                         style="cursor: pointer;">
                        <div class="task-card-title"><?= htmlspecialchars($task['title']) ?></div>
                        <div class="mb-3">
                            <span class="task-badge bg-<?= $statusColors[$task['status']] ?>"><?= ucfirst($task['status']) ?></span>
                            <span class="task-badge bg-<?= $priorityColors[$task['priority']] ?>"><?= ucfirst($task['priority']) ?></span>
                        </div>
                        <div class="task-card-meta">
                            <small><i class="bi bi-folder"></i> <?= htmlspecialchars($task['project_name']) ?></small> • 
                            <small><i class="bi bi-calendar"></i> <?= date('d.m.Y', strtotime($task['due_date'])) ?></small>
                        </div>
                        <small class="text-muted d-block mt-2"><i class="bi bi-mouse"></i> Çift tıkla: Detay sayfası</small>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="card"><div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr><th>Görev</th><th>Proje</th><th>Durum</th><th>Öncelik</th><th>Bitiş</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tasks as $task): ?>
                        <tr ondblclick="window.location.href='task_detail.php?id=<?= $task['id'] ?>';" style="cursor: pointer;">
                            <td><strong><?= htmlspecialchars($task['title']) ?></strong></td>
                            <td><small><?= htmlspecialchars($task['project_name']) ?></small></td>
                            <td><span class="badge bg-<?= $statusColors[$task['status']] ?>"><?= $task['status'] ?></span></td>
                            <td><span class="badge bg-<?= $priorityColors[$task['priority']] ?>"><?= $task['priority'] ?></span></td>
                            <td><small><?= date('d.m.Y', strtotime($task['due_date'])) ?></small></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div></div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ($activeTask): ?>
    <div class="task-detail-panel active">
        <div class="detail-header" style="border-bottom: 3px solid #f1f5f9; padding-bottom: 25px; margin-bottom: 25px;">
            <h3 style="color: #667eea;"><?= htmlspecialchars($activeTask['title']) ?></h3>
            <p class="text-muted"><?= htmlspecialchars($activeTask['project_name']) ?></p>
        </div>
        
        <div class="row">
            <div class="col-md-8">
                <h5>Açıklama</h5>
                <p><?= nl2br(htmlspecialchars($activeTask['description'] ?? 'Yok')) ?></p>
                
                <h5 class="mt-4">Yorumlar (<?= count($taskComments) ?>)</h5>
                <?php foreach ($taskComments as $comment): ?>
                <div class="comment-item <?= (int)$comment['user_id'] === $userId ? 'own' : '' ?>">
                    <strong><?= htmlspecialchars($comment['user_name']) ?></strong>
                    <small class="text-muted"><?= date('d.m.Y H:i', strtotime($comment['created_at'])) ?></small>
                    <p class="mt-2 mb-0"><?= nl2br(htmlspecialchars($comment['comment'])) ?></p>
                </div>
                <?php endforeach; ?>
                
                <form method="post" class="mt-3">
                    <div class="input-group">
                        <input type="text" name="comment" class="form-control" placeholder="@kullanıcı ile etiketle..." required>
                        <button type="submit" name="add_comment" class="btn btn-primary">Gönder</button>
                    </div>
                </form>
            </div>
            
            <div class="col-md-4">
                <h5>Dosyalar (<?= count($taskFiles) ?>)</h5>
                <?php foreach ($taskFiles as $file): ?>
                <div class="mb-2 p-2 bg-light rounded">
                    <i class="bi bi-file"></i> <?= htmlspecialchars($file['file_name']) ?>
                    <?php
                    $filePath = ltrim($file['file_path'], '/');
                    if (strpos($filePath, 'uploads/') !== 0) {
                        $filePath = 'uploads/tasks/' . basename($filePath);
                    }
                    ?>
                    <a href="<?= htmlspecialchars($filePath) ?>" class="btn btn-sm btn-primary float-end" download>İndir</a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
console.log('Tasks page loaded');

// Çift tıklama testi
document.addEventListener('DOMContentLoaded', function() {
    const taskCards = document.querySelectorAll('.task-card');
    console.log('Found ' + taskCards.length + ' task cards');
    
    taskCards.forEach(function(card) {
        card.addEventListener('dblclick', function() {
            console.log('Double click detected!');
        });
    });
});
</script>
</main>
<?php require __DIR__ . "/shared/layout_foot.php"; ?>

