<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";
require __DIR__ . "/config/rbac.php";

require_role(["super_admin"]);

function e(string $s): string { return htmlspecialchars($s, ENT_QUOTES, "UTF-8"); }

// kolon tespiti
$cCols = [];
try {
  $rs = $pdo->query("DESCRIBE companies");
  foreach ($rs->fetchAll(PDO::FETCH_ASSOC) as $r) $cCols[$r["Field"]] = true;
} catch (Throwable $e) {
  http_response_code(500);
  echo "companies tablosu okunamadı: " . e($e->getMessage());
  exit;
}

$hasCreated = isset($cCols["created_at"]);
$hasActive  = isset($cCols["is_active"]);
$hasTaxOffice = isset($cCols["tax_office"]);
$hasTaxNo     = isset($cCols["tax_no"]);
$hasEmail     = isset($cCols["email"]);
$hasPhone     = isset($cCols["phone"]);

// users.company_id var mı?
$uCols = [];
$hasUserCompany = false;
try {
  $rs = $pdo->query("DESCRIBE users");
  foreach ($rs->fetchAll(PDO::FETCH_ASSOC) as $r) $uCols[$r["Field"]] = true;
  $hasUserCompany = isset($uCols["company_id"]);
} catch (Throwable $e) {}

$order = $hasCreated ? "ORDER BY c.created_at DESC" : "ORDER BY c.id DESC";

$select = ["c.*"];
if ($hasUserCompany) {
  $select[] = "(SELECT COUNT(*) FROM users u WHERE u.company_id=c.id) AS user_cnt";
} else {
  $select[] = "0 AS user_cnt";
}

$sql = "SELECT ".implode(", ",$select)." FROM companies c {$order} LIMIT 200";
$companies = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Super Admin · Firmalar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-3">
<div class="container" style="max-width:1100px">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="m-0">Firmalar</h3>
    <a class="btn btn-primary" href="super_company_create.php">+ Firma Ekle</a>
  </div>

  <div class="table-responsive">
    <table class="table table-striped align-middle">
      <thead>
        <tr>
          <th>ID</th><th>Firma</th>
          <th>Vergi</th><th>İletişim</th><th>Kullanıcı</th>
          <?php if($hasActive): ?><th>Durum</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
      <?php foreach($companies as $c): ?>
        <tr>
          <td><?= (int)$c["id"] ?></td>
          <td><?= e((string)($c["name"] ?? "")) ?></td>
          <td>
            <?php
              $tax = [];
              if ($hasTaxOffice) $tax[] = (string)($c["tax_office"] ?? "");
              if ($hasTaxNo) $tax[] = (string)($c["tax_no"] ?? "");
              echo e(trim(implode(" ", array_filter($tax))));
            ?>
          </td>
          <td>
            <?php
              $contact = [];
              if ($hasEmail) $contact[] = (string)($c["email"] ?? "");
              if ($hasPhone) $contact[] = (string)($c["phone"] ?? "");
              echo e(trim(implode(" · ", array_filter($contact))));
            ?>
          </td>
          <td><?= (int)($c["user_cnt"] ?? 0) ?></td>
          <?php if($hasActive): ?>
            <td><?= ((int)($c["is_active"] ?? 1)===1) ? "Aktif" : "Pasif" ?></td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
