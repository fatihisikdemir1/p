<?php
declare(strict_types=1);

ini_set('display_errors','0');
error_reporting(E_ALL);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

header("Content-Type: application/json; charset=utf-8");

if (($_SERVER["REQUEST_METHOD"] ?? "") !== "POST") {
  http_response_code(405);
  echo json_encode(["ok"=>false,"error"=>"Method not allowed"]);
  exit;
}

$taskId = (int)($_POST["task_id"] ?? 0);

// Dosya kontrolü - files[] array olarak gelir
if ($taskId <= 0) {
  echo json_encode(["ok"=>false,"error"=>"Geçersiz task_id"]);
  exit;
}

if (empty($_FILES["files"])) {
  echo json_encode(["ok"=>false,"error"=>"Dosya seçilmedi"]);
  exit;
}

const MAX_FILE_BYTES = 20 * 1024 * 1024; // 20MB
$ALLOWED_EXT = ["pdf","doc","docx","xls","xlsx","png","jpg","jpeg","zip","txt"];

function safe_name(string $name): string {
  $name = basename($name);
  $name = preg_replace('/[^\pL\pN\.\-\_\s]+/u', '', $name);
  $name = trim($name);
  return $name !== "" ? $name : "dosya";
}

try {
  $uploadDir = __DIR__ . "/uploads";
  if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true)) {
    throw new RuntimeException("uploads klasörü oluşturulamadı.");
  }
  if (!is_writable($uploadDir)) {
    throw new RuntimeException("uploads yazılabilir değil (755/775 yap).");
  }

  // task_files kolonlarını tespit et (url/size varsa kullan)
  $cols = [];
  $rs = $pdo->query("DESCRIBE task_files");
  foreach ($rs->fetchAll(PDO::FETCH_ASSOC) as $r) $cols[$r["Field"]] = true;

  $hasUrl  = isset($cols["url"]);
  $hasSize = isset($cols["size_bytes"]);
  $hasCreated = isset($cols["uploaded_at"]);

  // Multiple file upload handling
  $names = $_FILES["files"]["name"] ?? [];
  $tmps  = $_FILES["files"]["tmp_name"] ?? [];
  $sizes = $_FILES["files"]["size"] ?? [];
  $errs  = $_FILES["files"]["error"] ?? [];

  // Single file ise array yap
  if (!is_array($names)) {
    $names = [$names];
    $tmps = [$tmps];
    $sizes = [$sizes];
    $errs = [$errs];
  }

  $count = 0;

  foreach ($tmps as $i => $tmp) {
    $orig = (string)($names[$i] ?? "");
    $err  = (int)($errs[$i] ?? UPLOAD_ERR_NO_FILE);
    $size = (int)($sizes[$i] ?? 0);

    if ($err === UPLOAD_ERR_NO_FILE) continue;
    if ($err !== UPLOAD_ERR_OK) {
      throw new RuntimeException("Upload hatası: {$orig} (kod {$err})");
    }
    if (!is_uploaded_file($tmp)) {
      throw new RuntimeException("Geçersiz upload: {$orig}");
    }

    if ($size > MAX_FILE_BYTES) {
      throw new RuntimeException("Dosya çok büyük: {$orig} (Max 20MB)");
    }

    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    if ($ext === "" || !in_array($ext, $ALLOWED_EXT, true)) {
      throw new RuntimeException("İzinli uzantı değil: {$orig} (İzinli: " . implode(", ", $ALLOWED_EXT) . ")");
    }

    $safeOrig = safe_name($orig);
    $newName = "task_" . $taskId . "_" . bin2hex(random_bytes(8)) . "." . $ext;
    $dest = $uploadDir . "/" . $newName;

    if (!move_uploaded_file($tmp, $dest)) {
      throw new RuntimeException("Dosya taşınamadı: {$orig}");
    }
    @chmod($dest, 0644);

    // Insert
    if ($hasUrl || $hasSize || $hasCreated) {
      $fields = ["task_id","filename","original_name"];
      $vals   = [":task_id",":filename",":original_name"];
      $bind   = [
        ":task_id"=>$taskId,
        ":filename"=>$newName,
        ":original_name"=>$safeOrig
      ];
      if ($hasSize) { $fields[]="size_bytes"; $vals[]=":size"; $bind[":size"]=$size; }
      if ($hasUrl)  { $fields[]="url";        $vals[]=":url";  $bind[":url"]="uploads/".$newName; }
      if ($hasCreated) { $fields[]="uploaded_at"; $vals[]="NOW()"; }

      $sql = "INSERT INTO task_files (".implode(",",$fields).") VALUES (".implode(",",$vals).")";
      $pdo->prepare($sql)->execute($bind);
    } else {
      $pdo->prepare("INSERT INTO task_files (task_id, filename, original_name, uploaded_at) VALUES (?, ?, ?, NOW())")
          ->execute([$taskId, $newName, $safeOrig]);
    }

    $count++;
  }

  if ($count === 0) {
    echo json_encode(["ok"=>false,"error"=>"Hiç dosya yüklenmedi"]);
  } else {
    echo json_encode(["ok"=>true,"uploaded"=>$count,"message"=>"{$count} dosya yüklendi"]);
  }

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(["ok"=>false,"error"=>$e->getMessage(),"detail"=>"Upload hatası"]);
}