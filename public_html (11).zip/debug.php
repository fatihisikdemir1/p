<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Debug</title></head><body>";
echo "<h1>🔍 SYSTEM DEBUG</h1>";
echo "<hr>";

echo "<h2>1. PHP Çalışıyor mu?</h2>";
echo "✅ Evet! PHP Version: " . phpversion() . "<br><br>";

echo "<h2>2. Dosya Yolu</h2>";
echo "Current Dir: " . __DIR__ . "<br>";
echo "File: " . __FILE__ . "<br><br>";

echo "<h2>3. config/db.php Var mı?</h2>";
$configPath = __DIR__ . "/config/db.php";
if (file_exists($configPath)) {
    echo "✅ Dosya mevcut: $configPath<br><br>";
} else {
    echo "❌ Dosya bulunamadı: $configPath<br>";
    echo "Lütfen kontrol edin!<br><br>";
    die();
}

echo "<h2>4. Database Bağlantısı</h2>";
try {
    require $configPath;
    echo "✅ Database bağlantısı başarılı!<br>";
    echo "PDO Object: " . (isset($pdo) ? "var" : "yok") . "<br><br>";
} catch (Exception $e) {
    echo "❌ HATA: " . $e->getMessage() . "<br><br>";
    die();
}

echo "<h2>5. Tables Check</h2>";
try {
    $tables = ['users', 'companies', 'roles', 'projects', 'tasks'];
    foreach ($tables as $table) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
        $count = $stmt->fetchColumn();
        echo "✅ $table: $count kayıt<br>";
    }
    echo "<br>";
} catch (Exception $e) {
    echo "❌ Tablo hatası: " . $e->getMessage() . "<br><br>";
}

echo "<h2>6. Users Listesi</h2>";
try {
    $stmt = $pdo->query("SELECT id, name, email, role, company_id FROM users LIMIT 5");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Company ID</th></tr>";
    foreach ($users as $u) {
        echo "<tr>";
        echo "<td>{$u['id']}</td>";
        echo "<td>{$u['name']}</td>";
        echo "<td>{$u['email']}</td>";
        echo "<td>{$u['role']}</td>";
        echo "<td>{$u['company_id']}</td>";
        echo "</tr>";
    }
    echo "</table><br>";
} catch (Exception $e) {
    echo "❌ Users hatası: " . $e->getMessage() . "<br><br>";
}

echo "<h2>7. Companies Listesi</h2>";
try {
    $stmt = $pdo->query("SELECT id, name FROM companies");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Name</th></tr>";
    foreach ($companies as $c) {
        echo "<tr><td>{$c['id']}</td><td>{$c['name']}</td></tr>";
    }
    echo "</table><br>";
} catch (Exception $e) {
    echo "❌ Companies hatası: " . $e->getMessage() . "<br><br>";
}

echo "<h2>8. Roles Listesi</h2>";
try {
    $stmt = $pdo->query("SELECT id, role_name, role_slug FROM roles");
    $roles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Name</th><th>Slug</th></tr>";
    foreach ($roles as $r) {
        echo "<tr><td>{$r['id']}</td><td>{$r['role_name']}</td><td>{$r['role_slug']}</td></tr>";
    }
    echo "</table><br>";
} catch (Exception $e) {
    echo "❌ Roles hatası: " . $e->getMessage() . "<br><br>";
}

echo "<h2>9. User 9 Detay</h2>";
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = 9");
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        echo "<pre>";
        print_r($user);
        echo "</pre>";
    } else {
        echo "❌ User 9 bulunamadı<br>";
    }
    echo "<br>";
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage() . "<br><br>";
}

echo "<h2>10. Company 4 Detay</h2>";
try {
    $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = 4");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($company) {
        echo "<pre>";
        print_r($company);
        echo "</pre>";
    } else {
        echo "❌ Company 4 bulunamadı<br>";
    }
    echo "<br>";
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage() . "<br><br>";
}

echo "<h2>11. Role Permissions Check</h2>";
try {
    $stmt = $pdo->query("
        SELECT r.role_name, rp.permission_key, rp.permission_value
        FROM role_permissions rp
        JOIN roles r ON rp.role_id = r.id
        WHERE r.role_slug = 'company_admin'
        ORDER BY rp.permission_key
    ");
    $perms = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($perms)) {
        echo "❌ Company admin'in hiç yetkisi yok!<br>";
    } else {
        echo "✅ Company admin yetkileri (" . count($perms) . " adet):<br>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Permission</th><th>Value</th></tr>";
        foreach ($perms as $p) {
            echo "<tr><td>{$p['permission_key']}</td><td>{$p['permission_value']}</td></tr>";
        }
        echo "</table>";
    }
    echo "<br>";
} catch (Exception $e) {
    echo "❌ Permission hatası: " . $e->getMessage() . "<br><br>";
}

echo "<hr>";
echo "<h2 style='color: green;'>✅ DEBUG TAMAMLANDI!</h2>";

echo "</body></html>";
?>