<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require __DIR__ . "/auth.php";

// Super admin kontrolü
if (!is_super_admin()) {
    die("Bu sayfaya erişim yetkiniz yok.");
}

$msg = "";
$err = "";

// Firma oluşturma
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['create_company'])) {
    try {
        $name = trim($_POST['name'] ?? "");
        $email = trim($_POST['email'] ?? "");
        $phone = trim($_POST['phone'] ?? "");
        $address = trim($_POST['address'] ?? "");
        
        if (empty($name)) {
            throw new Exception("Firma adı zorunludur");
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO companies (name, email, phone, address, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$name, $email, $phone, $address]);
        
        $msg = "✅ Firma başarıyla oluşturuldu!";
        
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Firma düzenleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['edit_company'])) {
    try {
        $companyId = (int)($_POST['company_id'] ?? 0);
        $name = trim($_POST['name'] ?? "");
        $email = trim($_POST['email'] ?? "");
        $phone = trim($_POST['phone'] ?? "");
        $address = trim($_POST['address'] ?? "");
        
        if (empty($name)) {
            throw new Exception("Firma adı zorunludur");
        }
        
        $stmt = $pdo->prepare("
            UPDATE companies 
            SET name = ?, email = ?, phone = ?, address = ?
            WHERE id = ?
        ");
        $stmt->execute([$name, $email, $phone, $address, $companyId]);
        
        $msg = "✅ Firma güncellendi!";
        
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Firma silme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete_company'])) {
    try {
        $companyId = (int)($_POST['company_id'] ?? 0);
        
        // Kullanıcı kontrolü
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE company_id = ?");
        $stmt->execute([$companyId]);
        $userCount = $stmt->fetchColumn();
        
        if ($userCount > 0) {
            throw new Exception("Bu firmaya bağlı $userCount kullanıcı var. Önce kullanıcıları silin veya başka firmaya taşıyın.");
        }
        
        // Proje kontrolü
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE company_id = ?");
        $stmt->execute([$companyId]);
        $projectCount = $stmt->fetchColumn();
        
        if ($projectCount > 0) {
            throw new Exception("Bu firmaya bağlı $projectCount proje var.");
        }
        
        $stmt = $pdo->prepare("DELETE FROM companies WHERE id = ?");
        $stmt->execute([$companyId]);
        
        $msg = "✅ Firma silindi!";
        
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Firmaları çek
$stmt = $pdo->query("
    SELECT c.*,
           (SELECT COUNT(*) FROM users WHERE company_id = c.id) as user_count,
           (SELECT COUNT(*) FROM projects WHERE company_id = c.id) as project_count
    FROM companies c
    ORDER BY c.name
");
$companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Firma Yönetimi - Super Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 30px; }
.page-container { max-width: 1400px; margin: 0 auto; }
.header-card { background: white; border-radius: 15px; padding: 20px 30px; margin-bottom: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.content-card { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.company-card { background: white; border-radius: 12px; padding: 20px; margin-bottom: 15px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); transition: all 0.3s; border-left: 4px solid #667eea; }
.company-card:hover { transform: translateY(-3px); box-shadow: 0 5px 20px rgba(0,0,0,0.15); }
</style>
</head>
<body>

<div class="page-container">
    
    <div class="header-card">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h2 class="mb-0" style="color: #667eea;"><i class="bi bi-building"></i> Firma Yönetimi</h2>
                <small class="text-muted"><?= count($companies) ?> firma</small>
            </div>
            <div class="col-md-4 text-center">
                <span class="badge bg-danger" style="font-size: 14px;">SUPER ADMIN PANEL</span>
            </div>
            <div class="col-md-4 text-end">
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createModal">
                    <i class="bi bi-plus-circle"></i> Yeni Firma
                </button>
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="bi bi-house"></i> Dashboard
                </a>
            </div>
        </div>
    </div>

    <?php if ($msg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $msg ?>
        </div>
    <?php endif; ?>
    
    <?php if ($err): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $err ?>
        </div>
    <?php endif; ?>

    <div class="content-card">
        <h4 class="mb-4"><i class="bi bi-building-fill"></i> Firmalar</h4>

        <?php if (empty($companies)): ?>
            <div class="text-center py-5">
                <i class="bi bi-building-x" style="font-size: 64px; color: #cbd5e1;"></i>
                <h4 class="mt-3 text-muted">Henüz firma yok</h4>
                <p class="text-muted">Yeni bir firma oluşturarak başlayın</p>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($companies as $company): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="company-card">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 style="color: #667eea;">
                                <i class="bi bi-building"></i> <?= htmlspecialchars($company['name']) ?>
                            </h5>
                        </div>

                        <?php if ($company['email']): ?>
                        <p class="mb-1 small">
                            <i class="bi bi-envelope"></i> <?= htmlspecialchars($company['email']) ?>
                        </p>
                        <?php endif; ?>

                        <?php if ($company['phone']): ?>
                        <p class="mb-1 small">
                            <i class="bi bi-telephone"></i> <?= htmlspecialchars($company['phone']) ?>
                        </p>
                        <?php endif; ?>

                        <hr>

                        <div class="row text-center mb-3">
                            <div class="col-6">
                                <strong style="color: #667eea;"><?= (int)$company['user_count'] ?></strong><br>
                                <small class="text-muted">Kullanıcı</small>
                            </div>
                            <div class="col-6">
                                <strong style="color: #667eea;"><?= (int)$company['project_count'] ?></strong><br>
                                <small class="text-muted">Proje</small>
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button class="btn btn-sm btn-primary flex-fill" onclick='viewCompany(<?= json_encode($company) ?>)'>
                                <i class="bi bi-eye"></i> Detay
                            </button>
                            <button class="btn btn-sm btn-warning" onclick='editCompany(<?= json_encode($company) ?>)'>
                                <i class="bi bi-pencil"></i>
                            </button>
                            <?php if ((int)$company['user_count'] === 0 && (int)$company['project_count'] === 0): ?>
                            <button class="btn btn-sm btn-danger" onclick="confirmDelete(<?= $company['id'] ?>, '<?= htmlspecialchars($company['name'], ENT_QUOTES) ?>')">
                                <i class="bi bi-trash"></i>
                            </button>
                            <?php else: ?>
                            <button class="btn btn-sm btn-secondary" disabled title="Kullanıcı veya proje var">
                                <i class="bi bi-trash"></i>
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- Create Modal -->
<div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
                <h5 class="modal-title"><i class="bi bi-building-add"></i> Yeni Firma Oluştur</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Firma Adı *</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Telefon</label>
                        <input type="text" name="phone" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Adres</label>
                        <textarea name="address" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="create_company" class="btn btn-success">
                        <i class="bi bi-check-circle"></i> Oluştur
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Firma Düzenle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="company_id" id="edit_company_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Firma Adı *</label>
                        <input type="text" name="name" id="edit_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" id="edit_email" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Telefon</label>
                        <input type="text" name="phone" id="edit_phone" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Adres</label>
                        <textarea name="address" id="edit_address" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="edit_company" class="btn btn-warning">
                        <i class="bi bi-check-circle"></i> Güncelle
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Modal -->
<div class="modal fade" id="viewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
                <h5 class="modal-title"><i class="bi bi-info-circle"></i> Firma Detayları</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <h5 id="view_name" style="color: #667eea;"></h5>
                <hr>
                <p><strong>Email:</strong> <span id="view_email"></span></p>
                <p><strong>Telefon:</strong> <span id="view_phone"></span></p>
                <p><strong>Adres:</strong> <span id="view_address"></span></p>
                <p><strong>Kullanıcı Sayısı:</strong> <span id="view_user_count"></span></p>
                <p><strong>Proje Sayısı:</strong> <span id="view_project_count"></span></p>
                <p><strong>Oluşturma Tarihi:</strong> <span id="view_created_at"></span></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="bi bi-exclamation-triangle"></i> Firmayı Sil</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p><strong id="companyNameToDelete"></strong> firmasını silmek istediğinize emin misiniz?</p>
                <p class="text-danger mb-0"><i class="bi bi-exclamation-triangle"></i> Bu işlem geri alınamaz!</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="company_id" id="companyIdToDelete">
                    <button type="submit" name="delete_company" class="btn btn-danger">
                        <i class="bi bi-trash"></i> Evet, Sil
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function editCompany(company) {
    document.getElementById('edit_company_id').value = company.id;
    document.getElementById('edit_name').value = company.name;
    document.getElementById('edit_email').value = company.email || '';
    document.getElementById('edit_phone').value = company.phone || '';
    document.getElementById('edit_address').value = company.address || '';
    
    const modal = new bootstrap.Modal(document.getElementById('editModal'));
    modal.show();
}

function viewCompany(company) {
    document.getElementById('view_name').textContent = company.name;
    document.getElementById('view_email').textContent = company.email || '-';
    document.getElementById('view_phone').textContent = company.phone || '-';
    document.getElementById('view_address').textContent = company.address || '-';
    document.getElementById('view_user_count').textContent = company.user_count;
    document.getElementById('view_project_count').textContent = company.project_count;
    document.getElementById('view_created_at').textContent = company.created_at;
    
    const modal = new bootstrap.Modal(document.getElementById('viewModal'));
    modal.show();
}

function confirmDelete(companyId, companyName) {
    document.getElementById('companyIdToDelete').value = companyId;
    document.getElementById('companyNameToDelete').textContent = companyName;
    
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    modal.show();
}
</script>
</body>
</html>