<?php
require "auth.php";
require "config/db.php";

$taskId = (int)($_POST["task_id"] ?? 0);
$status = $_POST["status"] ?? "";

$allowed = ["todo","doing","done"];
if (!$taskId || !in_array($status, $allowed)) {
    http_response_code(400);
    exit("Geçersiz istek");
}

// Görevi çek
$stmt = $pdo->prepare("SELECT assigned_to FROM tasks WHERE id = ?");
$stmt->execute([$taskId]);
$task = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$task) {
    http_response_code(404);
    exit("Görev bulunamadı");
}

// Yetki kontrolü
$role = $_SESSION["user"]["role"];
$userId = $_SESSION["user"]["id"];

if ($role === "member" && (int)$task["assigned_to"] !== $userId) {
    http_response_code(403);
    exit("Yetkin yok");
}

// Güncelle
$upd = $pdo->prepare("UPDATE tasks SET status = ? WHERE id = ?");
$upd->execute([$status, $taskId]);

echo "OK";
