<?php
require __DIR__ . "/auth.php";

if (!has_permission('manage_users')) {
    die("Bu sayfaya erişim yetkiniz yok.");
}

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$msg = "";
$err = "";

// Firma bilgisi
$companyName = "";
if (!is_super_admin() && $companyId > 0) {
    $stmt = $pdo->prepare("SELECT name FROM companies WHERE id = ?");
    $stmt->execute([$companyId]);
    $companyName = $stmt->fetchColumn() ?: "";
}

// Kullanıcı ekle
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_user"])) {
    try {
        $name = trim($_POST["name"] ?? "");
        $email = trim($_POST["email"] ?? "");
        $password = trim($_POST["password"] ?? "");
        $roleId = (int)($_POST["role_id"] ?? 0);
        
        $newCompanyId = is_super_admin() ? ((int)($_POST["company_id"] ?? 0)) : $companyId;
        
        if (empty($name) || empty($email) || empty($password) || $roleId === 0) {
            throw new Exception("Tüm alanları doldurun!");
        }
        
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            throw new Exception("Bu email zaten kayıtlı!");
        }
        
        $stmt = $pdo->prepare("SELECT role_slug FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        $roleSlug = $stmt->fetchColumn();
        
        if (!$roleSlug) {
            throw new Exception("Geçersiz rol!");
        }
        
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("
            INSERT INTO users (company_id, name, email, password, role_id, role, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $newCompanyId > 0 ? $newCompanyId : null, 
            $name, 
            $email, 
            $hashedPassword, 
            $roleId, 
            $roleSlug
        ]);
        
        $msg = "✅ Kullanıcı başarıyla eklendi!";
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Kullanıcı düzenle
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["edit_user"])) {
    try {
        $editUserId = (int)($_POST["user_id"] ?? 0);
        $name = trim($_POST["name"] ?? "");
        $email = trim($_POST["email"] ?? "");
        $roleId = (int)($_POST["role_id"] ?? 0);
        $newPassword = trim($_POST["new_password"] ?? "");
        
        if (empty($name) || empty($email)) {
            throw new Exception("Ad ve email zorunludur");
        }
        
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $editUserId]);
        if ($stmt->fetch()) {
            throw new Exception("Bu email başka bir kullanıcıya ait!");
        }
        
        $stmt = $pdo->prepare("SELECT role_slug FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        $roleSlug = $stmt->fetchColumn();
        
        if (!empty($newPassword)) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, password = ?, role_id = ?, role = ? WHERE id = ?");
            $stmt->execute([$name, $email, $hashedPassword, $roleId, $roleSlug, $editUserId]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, role_id = ?, role = ? WHERE id = ?");
            $stmt->execute([$name, $email, $roleId, $roleSlug, $editUserId]);
        }
        
        $msg = "✅ Kullanıcı güncellendi!";
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Kullanıcı sil
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete_user"])) {
    $delUserId = (int)($_POST["user_id"] ?? 0);
    
    try {
        if ($delUserId === $userId) {
            throw new Exception("Kendi hesabınızı silemezsiniz!");
        }
        
        $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
        $stmt->execute([$delUserId]);
        $userEmail = $stmt->fetchColumn();
        
        if ($userEmail === 'superadmin@finansconnect.com') {
            throw new Exception("Ana Super Admin hesabı silinemez!");
        }
        
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$delUserId]);
        
        $msg = "✅ Kullanıcı silindi!";
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Kullanıcıları listele
try {
    if (is_super_admin()) {
        $stmt = $pdo->query("
            SELECT u.*, c.name as company_name, r.role_name 
            FROM users u 
            LEFT JOIN companies c ON u.company_id = c.id 
            LEFT JOIN roles r ON u.role_id = r.id 
            ORDER BY u.id DESC
        ");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $stmt = $pdo->prepare("
            SELECT u.*, c.name as company_name, r.role_name 
            FROM users u 
            LEFT JOIN companies c ON u.company_id = c.id 
            LEFT JOIN roles r ON u.role_id = r.id 
            WHERE u.company_id = ? 
            ORDER BY u.id DESC
        ");
        $stmt->execute([$companyId]);
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $users = [];
    $err = "Kullanıcılar listelenemedi: " . $e->getMessage();
}

// Roller
try {
    if (is_super_admin()) {
        $stmt = $pdo->query("SELECT * FROM roles ORDER BY role_name");
        $roles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $stmt = $pdo->prepare("SELECT * FROM roles WHERE company_id = ? OR company_id IS NULL ORDER BY role_name");
        $stmt->execute([$companyId]);
        $roles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $roles = [];
}

// Şirketler
$companies = [];
if (is_super_admin()) {
    try {
        $stmt = $pdo->query("SELECT * FROM companies ORDER BY name");
        $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $companies = [];
    }
}
?>
<?php
$pageTitle = 'FinansConnect • Kullanıcılar';
$breadcrumbs = array(array('label' => 'FinansConnect', 'href' => '/dashboard.php'), array('label' => 'Kullanıcılar', 'href' => null));
require __DIR__ . "/shared/layout_head.php";
require __DIR__ . "/menu.php";
?>
<main class="content">
  <div class="topbar">
    <div class="crumbs">
      <?php
        if (!empty($breadcrumbs)) {
          $last = count($breadcrumbs)-1;
          foreach($breadcrumbs as $i=>$c){
            $lab = $c['label'] ?? '';
            $href = $c['href'] ?? '';
            if ($href) {
              echo '<a href="'.e($href).'">'.e($lab).'</a>';
            } else {
              echo '<span style="font-weight:950">'.e($lab).'</span>';
            }
            if ($i !== $last) echo '<span class="sep">/</span>';
          }
        }
      ?>
    </div>
    <div style="display:flex;gap:10px;align-items:center;flex:1;justify-content:flex-end">
      <form class="search" method="get" action="/task.php" style="max-width:680px">
        <i class="bi bi-search"></i>
        <input name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Arama: görev, proje, kullanıcı…">
      </form>
      <span class="pill"><i class="bi bi-person-circle"></i> <?= e($_SESSION['user']['name'] ?? 'Kullanıcı') ?></span>
    </div>
  </div>

  <div style="height:14px"></div>

  <div class="page-container">
    
    <!-- Header -->
    <div class="header-card">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h3 class="mb-0">
                    <i class="bi bi-people-fill" style="color: #1e3a8a;"></i>
                    <?= $companyName ? e($companyName) : "Tüm Şirketler" ?>
                </h3>
            </div>
            <div class="col-md-4 text-center">
                <h5 class="mb-0 text-muted">Kullanıcı Yönetimi</h5>
            </div>
            <div class="col-md-4 text-end">
                <a href="dashboard.php" class="btn btn-outline-primary">
                    <i class="bi bi-house"></i> Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Messages -->
    <?php if ($msg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $msg ?>
        </div>
    <?php endif; ?>
    
    <?php if ($err): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $err ?>
        </div>
    <?php endif; ?>

    <!-- Content -->
    <div class="content-card">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="mb-0">
                <i class="bi bi-person-lines-fill"></i> 
                Kullanıcılar <span class="badge bg-primary"><?= count($users) ?></span>
            </h4>
            <button class="btn btn-add-user" data-bs-toggle="modal" data-bs-target="#addModal">
                <i class="bi bi-person-plus-fill"></i> Yeni Kullanıcı Ekle
            </button>
        </div>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Kullanıcı</th>
                        <th>Email</th>
                        <th>Rol</th>
                        <?php if (is_super_admin()): ?>
                            <th>Şirket</th>
                        <?php endif; ?>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="<?= is_super_admin() ? 5 : 4 ?>" class="text-center py-4 text-muted">
                                <i class="bi bi-inbox" style="font-size: 48px;"></i><br>
                                Kullanıcı bulunamadı
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="user-avatar">
                                        <?= strtoupper(substr($user['name'], 0, 1)) ?>
                                    </div>
                                    <div>
                                        <strong><?= e($user['name']) ?></strong>
                                        <?php if ((int)$user['id'] === $userId): ?>
                                            <span class="badge bg-info ms-1">Siz</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td><?= e($user['email']) ?></td>
                            <td>
                                <span class="badge bg-primary">
                                    <?= e($user['role_name'] ?? $user['role'] ?? 'N/A') ?>
                                </span>
                            </td>
                            <?php if (is_super_admin()): ?>
                                <td><?= e($user['company_name'] ?? '-') ?></td>
                            <?php endif; ?>
                            <td>
                                <button class="btn btn-sm btn-warning" onclick='editUser(<?= json_encode($user) ?>)'>
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <?php if ((int)$user['id'] !== $userId && $user['email'] !== 'superadmin@finansconnect.com'): ?>
                                <form method="post" style="display:inline;" onsubmit="return confirm('Silmek istediğinize emin misiniz?')">
                                    <input type="hidden" name="user_id" value="<?= (int)$user['id'] ?>">
                                    <button type="submit" name="delete_user" class="btn btn-sm btn-danger">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color: white;">
                <h5 class="modal-title"><i class="bi bi-person-plus-fill"></i> Yeni Kullanıcı Ekle</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Ad Soyad *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email *</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Şifre *</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Rol *</label>
                            <select name="role_id" class="form-select" required>
                                <option value="">Seçiniz...</option>
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?= (int)$role['id'] ?>">
                                        <?= e($role['role_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <?php if (is_super_admin() && !empty($companies)): ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Şirket</label>
                        <select name="company_id" class="form-select">
                            <option value="0">Seçiniz...</option>
                            <?php foreach ($companies as $company): ?>
                                <option value="<?= (int)$company['id'] ?>">
                                    <?= e($company['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="add_user" class="btn btn-add-user">
                        <i class="bi bi-check-circle"></i> Kullanıcı Oluştur
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Kullanıcı Düzenle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="user_id" id="edit_user_id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Ad Soyad *</label>
                            <input type="text" name="name" id="edit_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email *</label>
                            <input type="email" name="email" id="edit_email" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Yeni Şifre</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Boş bırakın (değiştirmek istemiyorsanız)">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Rol *</label>
                            <select name="role_id" id="edit_role_id" class="form-select" required>
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?= (int)$role['id'] ?>">
                                        <?= e($role['role_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="edit_user" class="btn btn-warning">
                        <i class="bi bi-check-circle"></i> Güncelle
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function editUser(user) {
    document.getElementById('edit_user_id').value = user.id;
    document.getElementById('edit_name').value = user.name;
    document.getElementById('edit_email').value = user.email;
    document.getElementById('edit_role_id').value = user.role_id;
    
    const modal = new bootstrap.Modal(document.getElementById('editModal'));
    modal.show();
}
</script>
</main>
<?php require __DIR__ . "/shared/layout_foot.php"; ?>

