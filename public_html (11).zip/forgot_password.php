<?php
declare(strict_types=1);
require __DIR__ . "/config/db.php";

$msg = "";
$err = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    
    if ($email === "") {
        $err = "Email adresi gerekli";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id, name FROM users WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user) {
                $token = bin2hex(random_bytes(32));
                $expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));
                
                $stmt = $pdo->prepare("INSERT INTO password_reset_tokens (user_id, token, expires_at, used) VALUES (?, ?, ?, 0)");
                $stmt->execute([$user['id'], $token, $expiresAt]);
                
                $resetLink = "http://" . $_SERVER['HTTP_HOST'] . "/reset_password.php?token=" . $token;
                
                $subject = "Sifre Sifirlama";
                $message = "Merhaba " . $user['name'] . ",\n\nSifrenizi sifirlamak icin:\n" . $resetLink . "\n\nLink 1 saat gecerlidir.";
                
                mail($email, $subject, $message, "From: noreply@finansconnect.com");
            }
            
            $msg = "Eger bu email kayitliysa, sifre sifirlama linki gonderildi.";
            
        } catch (Exception $e) {
            $err = "Bir hata olustu.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Sifremi Unuttum</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-body p-4">
                    <h3 class="text-center mb-4">Sifremi Unuttum</h3>
                    
                    <?php if($msg): ?>
                        <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
                        <a href="login.php" class="btn btn-secondary w-100">Giris Sayfasina Don</a>
                    <?php else: ?>
                        <?php if($err): ?>
                            <div class="alert alert-danger"><?= htmlspecialchars($err) ?></div>
                        <?php endif; ?>
                        
                        <form method="post">
                            <div class="mb-3">
                                <label>Email Adresi</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Sifre Sifirlama Linki Gonder</button>
                        </form>
                        
                        <div class="text-center mt-3">
                            <a href="login.php">Girise Don</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>