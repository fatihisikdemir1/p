<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require __DIR__ . "/auth.php";

if (!is_super_admin()) {
    die("Bu sayfaya erişim yetkiniz yok.");
}

$msg = "";
$err = "";

// Kullanıcı oluşturma
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['create_user'])) {
    try {
        $name = trim($_POST['name'] ?? "");
        $email = trim($_POST['email'] ?? "");
        $password = trim($_POST['password'] ?? "");
        $roleId = (int)($_POST['role_id'] ?? 0);
        $companyId = (int)($_POST['company_id'] ?? 0);
        
        if (empty($name) || empty($email) || empty($password) || $roleId === 0) {
            throw new Exception("Tüm alanlar zorunludur");
        }
        
        // Email kontrolü
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            throw new Exception("Bu email zaten kayıtlı");
        }
        
        // Rol bilgisi
        $stmt = $pdo->prepare("SELECT role_slug FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        $roleSlug = $stmt->fetchColumn();
        
        if (!$roleSlug) {
            throw new Exception("Geçersiz rol");
        }
        
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("
            INSERT INTO users (company_id, name, email, password, role_id, role, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $companyId > 0 ? $companyId : null,
            $name,
            $email,
            $hashedPassword,
            $roleId,
            $roleSlug
        ]);
        
        $msg = "✅ Kullanıcı oluşturuldu!";
        
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Kullanıcı düzenleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['edit_user'])) {
    try {
        $userId = (int)($_POST['user_id'] ?? 0);
        $name = trim($_POST['name'] ?? "");
        $email = trim($_POST['email'] ?? "");
        $roleId = (int)($_POST['role_id'] ?? 0);
        $companyId = (int)($_POST['company_id'] ?? 0);
        $newPassword = trim($_POST['new_password'] ?? "");
        
        if (empty($name) || empty($email)) {
            throw new Exception("Ad ve email zorunludur");
        }
        
        // Email kontrolü
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $userId]);
        if ($stmt->fetch()) {
            throw new Exception("Bu email başka bir kullanıcıya ait");
        }
        
        // Rol bilgisi
        $stmt = $pdo->prepare("SELECT role_slug FROM roles WHERE id = ?");
        $stmt->execute([$roleId]);
        $roleSlug = $stmt->fetchColumn();
        
        if (!empty($newPassword)) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("
                UPDATE users 
                SET name = ?, email = ?, password = ?, role_id = ?, role = ?, company_id = ?
                WHERE id = ?
            ");
            $stmt->execute([$name, $email, $hashedPassword, $roleId, $roleSlug, $companyId > 0 ? $companyId : null, $userId]);
        } else {
            $stmt = $pdo->prepare("
                UPDATE users 
                SET name = ?, email = ?, role_id = ?, role = ?, company_id = ?
                WHERE id = ?
            ");
            $stmt->execute([$name, $email, $roleId, $roleSlug, $companyId > 0 ? $companyId : null, $userId]);
        }
        
        $msg = "✅ Kullanıcı güncellendi!";
        
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Kullanıcı silme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete_user'])) {
    try {
        $userId = (int)($_POST['user_id'] ?? 0);
        
        // Ana super admin kontrolü
        $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $userEmail = $stmt->fetchColumn();
        
        if ($userEmail === 'superadmin@finansconnect.com') {
            throw new Exception("Ana Super Admin silinemez!");
        }
        
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        
        $msg = "✅ Kullanıcı silindi!";
        
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Filtreler
$filterCompany = (int)($_GET['company'] ?? 0);
$filterRole = (int)($_GET['role'] ?? 0);

// Kullanıcıları çek
$query = "
    SELECT u.*, c.name as company_name, r.role_name
    FROM users u
    LEFT JOIN companies c ON u.company_id = c.id
    LEFT JOIN roles r ON u.role_id = r.id
    WHERE 1=1
";

$params = [];

if ($filterCompany > 0) {
    $query .= " AND u.company_id = ?";
    $params[] = $filterCompany;
}

if ($filterRole > 0) {
    $query .= " AND u.role_id = ?";
    $params[] = $filterRole;
}

$query .= " ORDER BY u.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Roller
$roles = $pdo->query("SELECT * FROM roles ORDER BY role_name")->fetchAll(PDO::FETCH_ASSOC);

// Firmalar
$companies = $pdo->query("SELECT * FROM companies ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Kullanıcı Yönetimi - Super Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 30px; }
.page-container { max-width: 1600px; margin: 0 auto; }
.header-card { background: white; border-radius: 15px; padding: 20px 30px; margin-bottom: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.content-card { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.user-avatar { width: 45px; height: 45px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 18px; }
</style>
</head>
<body>

<div class="page-container">
    
    <div class="header-card">
        <div class="row align-items-center">
            <div class="col-md-3">
                <h2 class="mb-0" style="color: #667eea;"><i class="bi bi-people-fill"></i> Kullanıcı Yönetimi</h2>
                <small class="text-muted"><?= count($users) ?> kullanıcı</small>
            </div>
            <div class="col-md-2">
                <span class="badge bg-danger w-100" style="font-size: 14px;">SUPER ADMIN</span>
            </div>
            <div class="col-md-7 text-end">
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#createModal">
                    <i class="bi bi-person-plus"></i> Yeni Kullanıcı
                </button>
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="bi bi-house"></i> Dashboard
                </a>
            </div>
        </div>
    </div>

    <?php if ($msg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $msg ?>
        </div>
    <?php endif; ?>
    
    <?php if ($err): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $err ?>
        </div>
    <?php endif; ?>

    <!-- Filtreler -->
    <div class="content-card mb-3">
        <form method="get" class="row g-3">
            <div class="col-md-5">
                <label class="form-label">Firmaya Göre Filtrele</label>
                <select name="company" class="form-select" onchange="this.form.submit()">
                    <option value="0">Tüm Firmalar</option>
                    <?php foreach ($companies as $company): ?>
                        <option value="<?= $company['id'] ?>" <?= $filterCompany === (int)$company['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($company['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-5">
                <label class="form-label">Role Göre Filtrele</label>
                <select name="role" class="form-select" onchange="this.form.submit()">
                    <option value="0">Tüm Roller</option>
                    <?php foreach ($roles as $role): ?>
                        <option value="<?= $role['id'] ?>" <?= $filterRole === (int)$role['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($role['role_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <a href="?" class="btn btn-secondary w-100">Temizle</a>
            </div>
        </form>
    </div>

    <!-- Kullanıcı Listesi -->
    <div class="content-card">
        <h4 class="mb-4"><i class="bi bi-person-lines-fill"></i> Kullanıcılar</h4>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Kullanıcı</th>
                        <th>Email</th>
                        <th>Firma</th>
                        <th>Rol</th>
                        <th>Oluşturma</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="user-avatar">
                                    <?= strtoupper(substr($user['name'], 0, 1)) ?>
                                </div>
                                <strong><?= htmlspecialchars($user['name']) ?></strong>
                            </div>
                        </td>
                        <td><?= htmlspecialchars($user['email']) ?></td>
                        <td>
                            <?php if ($user['company_name']): ?>
                                <span class="badge bg-info"><?= htmlspecialchars($user['company_name']) ?></span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-primary"><?= htmlspecialchars($user['role_name'] ?? $user['role']) ?></span>
                        </td>
                        <td><small><?= date('d.m.Y', strtotime($user['created_at'])) ?></small></td>
                        <td>
                            <button class="btn btn-sm btn-warning" onclick='editUser(<?= json_encode($user) ?>)'>
                                <i class="bi bi-pencil"></i>
                            </button>
                            <?php if ($user['email'] !== 'superadmin@finansconnect.com'): ?>
                            <button class="btn btn-sm btn-danger" onclick="confirmDelete(<?= $user['id'] ?>, '<?= htmlspecialchars($user['name'], ENT_QUOTES) ?>')">
                                <i class="bi bi-trash"></i>
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- Create Modal -->
<div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
                <h5 class="modal-title"><i class="bi bi-person-plus-fill"></i> Yeni Kullanıcı Oluştur</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Ad Soyad *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email *</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Şifre *</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Rol *</label>
                            <select name="role_id" class="form-select" required>
                                <option value="">Seçiniz...</option>
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?= $role['id'] ?>"><?= htmlspecialchars($role['role_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Firma (Opsiyonel)</label>
                        <select name="company_id" class="form-select">
                            <option value="0">Firma Yok</option>
                            <?php foreach ($companies as $company): ?>
                                <option value="<?= $company['id'] ?>"><?= htmlspecialchars($company['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <small class="text-muted">Company Admin için firma ataması zorunludur</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="create_user" class="btn btn-success">
                        <i class="bi bi-check-circle"></i> Oluştur
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning">
                <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Kullanıcı Düzenle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="user_id" id="edit_user_id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Ad Soyad *</label>
                            <input type="text" name="name" id="edit_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Email *</label>
                            <input type="email" name="email" id="edit_email" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Yeni Şifre</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Boş bırakın">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Rol *</label>
                            <select name="role_id" id="edit_role_id" class="form-select" required>
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?= $role['id'] ?>"><?= htmlspecialchars($role['role_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Firma</label>
                        <select name="company_id" id="edit_company_id" class="form-select">
                            <option value="0">Firma Yok</option>
                            <?php foreach ($companies as $company): ?>
                                <option value="<?= $company['id'] ?>"><?= htmlspecialchars($company['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" name="edit_user" class="btn btn-warning">
                        <i class="bi bi-check-circle"></i> Güncelle
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="bi bi-exclamation-triangle"></i> Kullanıcıyı Sil</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p><strong id="userNameToDelete"></strong> kullanıcısını silmek istediğinize emin misiniz?</p>
                <p class="text-danger mb-0"><i class="bi bi-exclamation-triangle"></i> Bu işlem geri alınamaz!</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="user_id" id="userIdToDelete">
                    <button type="submit" name="delete_user" class="btn btn-danger">
                        <i class="bi bi-trash"></i> Evet, Sil
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function editUser(user) {
    document.getElementById('edit_user_id').value = user.id;
    document.getElementById('edit_name').value = user.name;
    document.getElementById('edit_email').value = user.email;
    document.getElementById('edit_role_id').value = user.role_id;
    document.getElementById('edit_company_id').value = user.company_id || 0;
    
    const modal = new bootstrap.Modal(document.getElementById('editModal'));
    modal.show();
}

function confirmDelete(userId, userName) {
    document.getElementById('userIdToDelete').value = userId;
    document.getElementById('userNameToDelete').textContent = userName;
    
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    modal.show();
}
</script>
</body>
</html>