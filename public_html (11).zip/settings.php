<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?>
<?php
$pageTitle = 'FinansConnect • Ayarlar';
$breadcrumbs = array(array('label' => 'FinansConnect', 'href' => '/dashboard.php'), array('label' => 'Ayarlar', 'href' => null));
require __DIR__ . "/shared/layout_head.php";
require __DIR__ . "/menu.php";
?>
<main class="content">
  <div class="topbar">
    <div class="crumbs">
      <?php
        if (!empty($breadcrumbs)) {
          $last = count($breadcrumbs)-1;
          foreach($breadcrumbs as $i=>$c){
            $lab = $c['label'] ?? '';
            $href = $c['href'] ?? '';
            if ($href) {
              echo '<a href="'.e($href).'">'.e($lab).'</a>';
            } else {
              echo '<span style="font-weight:950">'.e($lab).'</span>';
            }
            if ($i !== $last) echo '<span class="sep">/</span>';
          }
        }
      ?>
    </div>
    <div style="display:flex;gap:10px;align-items:center;flex:1;justify-content:flex-end">
      <form class="search" method="get" action="/task.php" style="max-width:680px">
        <i class="bi bi-search"></i>
        <input name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Arama: görev, proje, kullanıcı…">
      </form>
      <span class="pill"><i class="bi bi-person-circle"></i> <?= e($_SESSION['user']['name'] ?? 'Kullanıcı') ?></span>
    </div>
  </div>

  <div style="height:14px"></div>

  <div class="container-fluid p-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-gear"></i> Ayarlar</h2>
        </div>
        <div class="col-auto">
            <a href="dashboard.php" class="btn btn-secondary">
                <i class="bi bi-house"></i> Dashboard
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-3">
            <div class="list-group">
                <a href="#general" class="list-group-item list-group-item-action active">
                    <i class="bi bi-gear"></i> Genel
                </a>
                <a href="#notifications" class="list-group-item list-group-item-action">
                    <i class="bi bi-bell"></i> Bildirimler
                </a>
                <a href="#security" class="list-group-item list-group-item-action">
                    <i class="bi bi-shield-check"></i> Güvenlik
                </a>
                <?php if (is_super_admin()): ?>
                <a href="#system" class="list-group-item list-group-item-action">
                    <i class="bi bi-server"></i> Sistem
                </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Genel Ayarlar</h5>
                </div>
                <div class="card-body">
                    <form>
                        <div class="mb-3">
                            <label class="form-label">Dil</label>
                            <select class="form-select">
                                <option selected>Türkçe</option>
                                <option>English</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Saat Dilimi</label>
                            <select class="form-select">
                                <option selected>GMT+3 (İstanbul)</option>
                                <option>GMT+0 (UTC)</option>
                            </select>
                        </div>

                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="emailNotif">
                            <label class="form-check-label" for="emailNotif">
                                Email bildirimleri
                            </label>
                        </div>

                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="taskNotif" checked>
                            <label class="form-check-label" for="taskNotif">
                                Görev atandığında bildir
                            </label>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-circle"></i> Kaydet
                        </button>
                    </form>
                </div>
            </div>

            <div class="alert alert-info mt-3">
                <i class="bi bi-info-circle"></i> 
                <strong>Not:</strong> Ayarlar henüz geliştirme aşamasındadır.
            </div>
        </div>
    </div>
</div>
</main>
<?php require __DIR__ . "/shared/layout_foot.php"; ?>

