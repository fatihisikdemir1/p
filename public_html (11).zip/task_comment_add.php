<?php
declare(strict_types=1);

ini_set('display_errors','0');
error_reporting(E_ALL);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";
require __DIR__ . "/config/rbac.php";

header("Content-Type: application/json; charset=utf-8");

if (($_SERVER["REQUEST_METHOD"] ?? "") !== "POST") {
  http_response_code(405);
  echo json_encode(["ok"=>false,"error"=>"Method not allowed"]);
  exit;
}

$userId = (int)($_SESSION["user"]["id"] ?? 0);
$role   = normalize_role((string)($_SESSION["user"]["role"] ?? "user"));

$taskId = (int)($_POST["task_id"] ?? 0);
$message = trim((string)($_POST["message"] ?? ($_POST["comment"] ?? "")));
$taggedUserId = (int)($_POST["tagged_user_id"] ?? 0);

if ($taskId <= 0 || $message === "") {
  echo json_encode(["ok"=>false,"error"=>"Eksik veri"]);
  exit;
}

/* Görev + yetki */
$st = $pdo->prepare("SELECT id, assigned_to, company_id FROM tasks WHERE id=? LIMIT 1");
$st->execute([$taskId]);
$task = $st->fetch(PDO::FETCH_ASSOC);

if (!$task) {
  echo json_encode(["ok"=>false,"error"=>"Görev yok"]);
  exit;
}

if (in_array($role, ["user","viewer"], true) && (int)$task["assigned_to"] !== $userId) {
  echo json_encode(["ok"=>false,"error"=>"Yetkin yok"]);
  exit;
}
if ($role === "viewer") {
  echo json_encode(["ok"=>false,"error"=>"Gözlemci mesaj gönderemez"]);
  exit;
}

// company_admin mesaj atıyorsa (tasks.company_id varsa) kendi şirketinde olmalı
if ($role === "company_admin" && isset($task["company_id"])) {
  if ((int)$task["company_id"] !== (int)$companyId) {
    echo json_encode(["ok"=>false,"error"=>"Bu görev sizin firmanıza ait değil"]);
    exit;
  }
}

try {
  // task_comments kolonları
  $cCols = [];
  $rs = $pdo->query("DESCRIBE task_comments");
  foreach ($rs->fetchAll(PDO::FETCH_ASSOC) as $r) $cCols[$r["Field"]] = true;

  $msgCol = isset($cCols["message"]) ? "message" : (isset($cCols["comment"]) ? "comment" : null);
  if (!$msgCol) {
    echo json_encode(["ok"=>false,"error"=>"task_comments tablosunda message/comment kolonu yok"]);
    exit;
  }

  $hasTagged = isset($cCols["tagged_user_id"]);
  $hasCreated = isset($cCols["created_at"]);

  // insert
  $fields = ["task_id","user_id",$msgCol];
  $vals   = [":task_id",":user_id",":msg"];
  $bind   = [
    ":task_id"=>$taskId,
    ":user_id"=>$userId,
    ":msg"=>$message
  ];

  if ($hasTagged) { $fields[]="tagged_user_id"; $vals[]=":tag"; $bind[":tag"]=($taggedUserId>0?$taggedUserId:null); }
  if ($hasCreated) { $fields[]="created_at"; $vals[]="NOW()"; }

  $sql = "INSERT INTO task_comments (".implode(",",$fields).") VALUES (".implode(",",$vals).")";
  $pdo->prepare($sql)->execute($bind);

  echo json_encode(["ok"=>true]);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(["ok"=>false,"error"=>"Mesaj kaydı hatası","detail"=>$e->getMessage()]);
}
