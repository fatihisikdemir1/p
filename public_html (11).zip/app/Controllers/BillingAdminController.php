<?php
declare(strict_types=1);

final class BillingAdminController
{
    public static function index(): void
    {
        // Swap these to your existing auth helpers if different
        TaskController::requireLogin();
        self::requireSuperAdmin();

        $pdo = DB::pdo();

        $tenants = $pdo->query("SELECT id,name,slug,status FROM tenants ORDER BY id DESC")
            ->fetchAll(PDO::FETCH_ASSOC);

        $plans   = $pdo->query("SELECT id,code,name,interval FROM plans ORDER BY id DESC")
            ->fetchAll(PDO::FETCH_ASSOC);

        View::render('admin/billing.php', [
            'tenants' => $tenants,
            'plans'   => $plans,
        ]);
    }

    public static function saveSubscription(): void
    {
        TaskController::requireLogin();
        self::requireSuperAdmin();

        $tenantId = (int)($_POST['tenant_id'] ?? 0);
        $planId   = (int)($_POST['plan_id'] ?? 0);
        $status   = (string)($_POST['status'] ?? 'trial');

        if ($tenantId <= 0 || $planId <= 0) {
            http_response_code(422);
            echo "Bad input";
            exit;
        }

        $pdo = DB::pdo();
        $pdo->beginTransaction();
        try {
            // upsert subscription
            $st = $pdo->prepare("SELECT id FROM subscriptions WHERE tenant_id=? LIMIT 1");
            $st->execute([$tenantId]);
            $subId = (int)($st->fetchColumn() ?: 0);

            if ($subId > 0) {
                $u = $pdo->prepare("UPDATE subscriptions SET plan_id=?, status=? WHERE id=?");
                $u->execute([$planId, $status, $subId]);
            } else {
                $i = $pdo->prepare("INSERT INTO subscriptions (tenant_id, plan_id, status) VALUES (?,?,?)");
                $i->execute([$tenantId, $planId, $status]);
                $subId = (int)$pdo->lastInsertId();
            }

            // default module rows (safe default: disabled)
            $default = ['finance','treasury','operations','procurement','governance'];
            $ins = $pdo->prepare("
                INSERT INTO subscription_modules (subscription_id, module_key, status)
                VALUES (?,?,?)
                ON DUPLICATE KEY UPDATE status = status
            ");
            foreach ($default as $m) {
                $ins->execute([$subId, $m, 'disabled']);
            }

            $pdo->commit();

            FeatureGate::resetTenant($tenantId);

            header("Location: /admin/billing");
            exit;
        } catch (Throwable $e) {
            $pdo->rollBack();
            http_response_code(500);
            echo "Error: " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
            exit;
        }
    }

    public static function toggleModule(): void
    {
        TaskController::requireLogin();
        self::requireSuperAdmin();

        $tenantId  = (int)($_POST['tenant_id'] ?? 0);
        $moduleKey = (string)($_POST['module_key'] ?? '');
        $status    = (string)($_POST['status'] ?? 'disabled');

        if ($tenantId <= 0 || $moduleKey === '') {
            http_response_code(422);
            echo "Bad input";
            exit;
        }

        $pdo = DB::pdo();

        $sub = $pdo->prepare("SELECT id FROM subscriptions WHERE tenant_id=? LIMIT 1");
        $sub->execute([$tenantId]);
        $subId = (int)($sub->fetchColumn() ?: 0);

        if ($subId <= 0) {
            http_response_code(404);
            echo "No subscription";
            exit;
        }

        $st = $pdo->prepare("
            INSERT INTO subscription_modules (subscription_id, module_key, status)
            VALUES (?,?,?)
            ON DUPLICATE KEY UPDATE status=VALUES(status)
        ");
        $st->execute([$subId, $moduleKey, $status]);

        FeatureGate::resetTenant($tenantId);

        header("Location: /admin/billing");
        exit;
    }

    private static function requireSuperAdmin(): void
    {
        $role = (string)($_SESSION['role'] ?? '');
        if ($role !== 'super_admin') {
            http_response_code(403);
            echo "Forbidden";
            exit;
        }
    }
}
