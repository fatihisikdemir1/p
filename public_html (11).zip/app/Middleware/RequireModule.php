<?php
declare(strict_types=1);

final class RequireModule
{
    /**
     * Guard access to a module.
     * Requires $_SESSION['tenant_id'] to be set in your login flow.
     */
    public static function check(string $moduleKey): void
    {
        $tenantId = (int)($_SESSION['tenant_id'] ?? 0);
        if ($tenantId <= 0) {
            http_response_code(401);
            echo "Unauthorized";
            exit;
        }

        if (!FeatureGate::moduleEnabled($tenantId, $moduleKey)) {
            http_response_code(403);
            echo "Module disabled: " . htmlspecialchars($moduleKey, ENT_QUOTES, 'UTF-8');
            exit;
        }
    }
}
