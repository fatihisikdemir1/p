<?php
declare(strict_types=1);

final class FeatureGate
{
    private static array $cache = []; // tenantId => entitlements

    /**
     * Module check.
     * Example: FeatureGate::moduleEnabled($tenantId, 'finance')
     */
    public static function moduleEnabled(int $tenantId, string $moduleKey): bool
    {
        $ent = self::entitlements($tenantId);
        return !empty($ent['modules'][$moduleKey]) && $ent['modules'][$moduleKey] === true;
    }

    /**
     * Feature value lookup.
     * Example: FeatureGate::featureValue($tenantId, 'limit.entities.max')
     * Returns string value or null.
     */
    public static function featureValue(int $tenantId, string $featureKey): ?string
    {
        $ent = self::entitlements($tenantId);
        return $ent['features'][$featureKey] ?? null;
    }

    /**
     * Feature boolean gate (treats "0,false,no,off" as false).
     */
    public static function has(int $tenantId, string $featureKey): bool
    {
        $v = self::featureValue($tenantId, $featureKey);
        if ($v === null) return false;
        return !in_array(strtolower($v), ['0','false','no','off'], true);
    }

    public static function resetTenant(int $tenantId): void
    {
        unset(self::$cache[$tenantId]);
    }

    private static function entitlements(int $tenantId): array
    {
        if (isset(self::$cache[$tenantId])) return self::$cache[$tenantId];

        $pdo = DB::pdo();

        // subscription + plan
        $sub = self::fetchRow($pdo, "
            SELECT s.id AS sub_id, s.status, s.plan_id
            FROM subscriptions s
            WHERE s.tenant_id = ?
            LIMIT 1
        ", [$tenantId]);

        if (!$sub) {
            return self::$cache[$tenantId] = [
                'sub' => null,
                'modules' => [],
                'features' => [],
            ];
        }

        $modules = self::fetchPairs($pdo, "
            SELECT module_key, status
            FROM subscription_modules
            WHERE subscription_id = ?
        ", [(int)$sub['sub_id']]);

        $enabledModules = [];
        foreach ($modules as $k => $st) {
            $enabledModules[$k] = ($st === 'enabled');
        }

        $features = self::fetchPairs($pdo, "
            SELECT feature_key, feature_value
            FROM plan_features
            WHERE plan_id = ?
        ", [(int)$sub['plan_id']]);

        return self::$cache[$tenantId] = [
            'sub' => $sub,
            'modules' => $enabledModules,
            'features' => $features,
        ];
    }

    private static function fetchRow(PDO $pdo, string $sql, array $params): ?array
    {
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    private static function fetchPairs(PDO $pdo, string $sql, array $params): array
    {
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $out = [];
        while ($r = $st->fetch(PDO::FETCH_NUM)) {
            $out[(string)$r[0]] = $r[1] !== null ? (string)$r[1] : null;
        }
        return $out;
    }
}
