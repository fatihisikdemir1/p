<?php declare(strict_types=1); ?>
<h1 style="margin:0 0 16px 0;">Billing / Entitlements</h1>

<section style="padding:12px;border:1px solid rgba(255,255,255,.12);border-radius:12px;margin-bottom:16px;">
  <h3 style="margin:0 0 10px 0;">Assign Plan to Tenant</h3>

  <form method="post" action="/admin/billing/save-subscription" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;">
    <div>
      <label>Tenant</label><br>
      <select name="tenant_id" required>
        <?php foreach(($tenants ?? []) as $t): ?>
          <option value="<?= (int)$t['id'] ?>"><?= htmlspecialchars((string)$t['name']) ?> (<?= htmlspecialchars((string)$t['status']) ?>)</option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label>Plan</label><br>
      <select name="plan_id" required>
        <?php foreach(($plans ?? []) as $p): ?>
          <option value="<?= (int)$p['id'] ?>"><?= htmlspecialchars((string)$p['code']) ?> — <?= htmlspecialchars((string)$p['name']) ?> (<?= htmlspecialchars((string)$p['interval']) ?>)</option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label>Status</label><br>
      <select name="status">
        <option value="trial">trial</option>
        <option value="active">active</option>
        <option value="past_due">past_due</option>
        <option value="cancelled">cancelled</option>
      </select>
    </div>

    <button type="submit">Save</button>
  </form>
</section>

<section style="padding:12px;border:1px solid rgba(255,255,255,.12);border-radius:12px;">
  <h3 style="margin:0 0 10px 0;">Toggle Modules</h3>

  <form method="post" action="/admin/billing/toggle-module" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;">
    <div>
      <label>Tenant</label><br>
      <select name="tenant_id" required>
        <?php foreach(($tenants ?? []) as $t): ?>
          <option value="<?= (int)$t['id'] ?>"><?= htmlspecialchars((string)$t['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label>Module</label><br>
      <select name="module_key" required>
        <option value="finance">finance</option>
        <option value="treasury">treasury</option>
        <option value="operations">operations</option>
        <option value="procurement">procurement</option>
        <option value="governance">governance</option>
      </select>
    </div>

    <div>
      <label>Status</label><br>
      <select name="status">
        <option value="enabled">enabled</option>
        <option value="disabled">disabled</option>
      </select>
    </div>

    <button type="submit">Apply</button>
  </form>
</section>
