<?php
require __DIR__ . "/auth.php";
require __DIR__ . "/db.php";

header("Content-Type: application/json; charset=utf-8");

if ($_SESSION["user"]["role"] === "member") {
  echo json_encode(["ok"=>false,"error"=>"Yetkin yok"]);
  exit;
}

$taskId = (int)($_POST["task_id"] ?? 0);
if ($taskId <= 0) {
  echo json_encode(["ok"=>false,"error"=>"task_id yok"]);
  exit;
}

$data = [
  $_POST["title"] ?? "",
  $_POST["description"] ?? "",
  $_POST["due_date"] ?: null,
  $_POST["status"] ?? "todo",
  $_POST["priority"] ?? "medium",
  (int)($_POST["assigned_to"] ?? 0),
  $taskId
];

$pdo->prepare("
  UPDATE tasks SET
    title=?,
    description=?,
    due_date=?,
    status=?,
    priority=?,
    assigned_to=?,
    updated_at=NOW()
  WHERE id=?
")->execute($data);

echo json_encode(["ok"=>true]);
