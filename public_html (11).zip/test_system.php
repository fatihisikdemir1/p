<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require __DIR__ . "/auth.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Sistem Testi</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-5">
<div class="container">
<h1>🔍 Sistem Testi</h1>
<hr>

<h3>1. Veritabanı Bağlantısı</h3>
<?php
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM tasks");
    $taskCount = $stmt->fetchColumn();
    echo "<div class='alert alert-success'>✅ Veritabanı çalışıyor - Toplam $taskCount görev var</div>";
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>❌ Veritabanı hatası: " . $e->getMessage() . "</div>";
}
?>

<h3>2. task_files Tablosu</h3>
<?php
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM task_files");
    $fileCount = $stmt->fetchColumn();
    echo "<div class='alert alert-success'>✅ task_files tablosu var - Toplam $fileCount dosya var</div>";
    
    if ($fileCount > 0) {
        $stmt = $pdo->query("SELECT task_id, file_name, file_path FROM task_files LIMIT 5");
        $files = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "<table class='table table-sm'>";
        echo "<tr><th>Task ID</th><th>Dosya</th><th>Yol</th></tr>";
        foreach ($files as $f) {
            echo "<tr><td>{$f['task_id']}</td><td>{$f['file_name']}</td><td>{$f['file_path']}</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<div class='alert alert-warning'>⚠️ Hiç dosya yüklenmemiş!</div>";
    }
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>❌ task_files tablosu yok: " . $e->getMessage() . "</div>";
    echo "<pre>CREATE TABLE task_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    task_id INT NOT NULL,
    file_name VARCHAR(255),
    file_path VARCHAR(500),
    file_size INT,
    uploaded_by INT,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
);</pre>";
}
?>

<h3>3. task_detail.php Dosyası</h3>
<?php
if (file_exists(__DIR__ . '/task_detail.php')) {
    echo "<div class='alert alert-success'>✅ task_detail.php var</div>";
} else {
    echo "<div class='alert alert-danger'>❌ task_detail.php YOK! Bu yüzden çift tıklama çalışmıyor.</div>";
    echo "<p>Çözüm: Eski dosyalardan task_detail.php'yi bul ve yükle</p>";
}
?>

<h3>4. Görevler ve Dosyaları</h3>
<?php
try {
    $stmt = $pdo->query("
        SELECT t.id, t.title, COUNT(f.id) as file_count
        FROM tasks t
        LEFT JOIN task_files f ON t.id = f.task_id
        GROUP BY t.id
        LIMIT 10
    ");
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table class='table'>";
    echo "<tr><th>ID</th><th>Görev</th><th>Dosya Sayısı</th></tr>";
    foreach ($tasks as $t) {
        $badge = $t['file_count'] > 0 ? 'success' : 'secondary';
        echo "<tr><td>{$t['id']}</td><td>{$t['title']}</td><td><span class='badge bg-$badge'>{$t['file_count']} dosya</span></td></tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "<div class='alert alert-danger'>Hata: " . $e->getMessage() . "</div>";
}
?>

<h3>5. JavaScript Testi</h3>
<button class="btn btn-primary" onclick="testDoubleClick()">Çift Tıklama Test</button>
<div id="testResult"></div>

<script>
let clickCount = 0;
let clickTimer = null;

function testDoubleClick() {
    clickCount++;
    document.getElementById('testResult').innerHTML = '<div class="alert alert-info mt-3">Tıklama sayısı: ' + clickCount + '</div>';
    
    if (clickCount === 2) {
        document.getElementById('testResult').innerHTML = '<div class="alert alert-success mt-3">✅ Çift tıklama ÇALIŞIYOR!</div>';
        setTimeout(() => { clickCount = 0; }, 1000);
    }
    
    setTimeout(() => { clickCount = 0; }, 500);
}
</script>

<hr>
<h3>📋 Sonuç</h3>
<p>Bu sayfanın ekran görüntüsünü gönder, sorunları görelim!</p>

</div>
</body>
</html>