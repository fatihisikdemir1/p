<?php
require "auth.php";
require "config/db.php";

header("Content-Type: application/json; charset=utf-8");

$rows = $pdo->query("SELECT id, name FROM users ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
echo json_encode(["ok"=>true, "users"=>$rows]);
