<?php
require __DIR__ . "/auth.php";

$msg = "";
$err = "";

// Proje silme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete_project'])) {
    $projectId = (int)($_POST['project_id'] ?? 0);
    
    try {
        // Yetki kontrolü
        $stmt = $pdo->prepare("SELECT company_id FROM projects WHERE id = ?");
        $stmt->execute([$projectId]);
        $project = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$project) {
            throw new Exception("Proje bulunamadı");
        }
        
        if (!is_super_admin() && (int)$project['company_id'] !== $companyId) {
            throw new Exception("Bu projeyi silme yetkiniz yok");
        }
        
        // Görev kontrolü
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE project_id = ?");
        $stmt->execute([$projectId]);
        $taskCount = $stmt->fetchColumn();
        
        if ($taskCount > 0) {
            throw new Exception("Bu projede $taskCount görev var. Önce görevleri silin veya taşıyın.");
        }
        
        $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
        $stmt->execute([$projectId]);
        
        $msg = "✅ Proje silindi!";
        
    } catch (Exception $e) {
        $err = "❌ " . $e->getMessage();
    }
}

// Projeleri çek
if (is_super_admin()) {
    $projects = $pdo->query("
        SELECT p.*, c.name as company_name,
               (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count
        FROM projects p
        LEFT JOIN companies c ON p.company_id = c.id
        ORDER BY p.created_at DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("
        SELECT p.*, c.name as company_name,
               (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count
        FROM projects p
        LEFT JOIN companies c ON p.company_id = c.id
        WHERE p.company_id = ?
        ORDER BY p.created_at DESC
    ");
    $stmt->execute([$companyId]);
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<?php
$pageTitle = 'FinansConnect • Projeler';
$breadcrumbs = array(array('label' => 'FinansConnect', 'href' => '/dashboard.php'), array('label' => 'Projeler', 'href' => null));
$extraHead = '<style>
body { background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); min-height: 100vh; padding: 30px; }
.page-container { max-width: 1400px; margin: 0 auto; }
.header-card { background: white; border-radius: 15px; padding: 20px 30px; margin-bottom: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.content-card { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); }
.project-card { background: white; border-radius: 12px; padding: 20px; margin-bottom: 15px; transition: all 0.3s; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.project-card:hover { transform: translateY(-3px); box-shadow: 0 5px 20px rgba(0,0,0,0.15); }
</style>';
require __DIR__ . "/shared/layout_head.php";
require __DIR__ . "/menu.php";
?>
<main class="content">
  <div class="topbar">
    <div class="crumbs">
      <?php
        if (!empty($breadcrumbs)) {
          $last = count($breadcrumbs)-1;
          foreach($breadcrumbs as $i=>$c){
            $lab = $c['label'] ?? '';
            $href = $c['href'] ?? '';
            if ($href) {
              echo '<a href="'.e($href).'">'.e($lab).'</a>';
            } else {
              echo '<span style="font-weight:950">'.e($lab).'</span>';
            }
            if ($i !== $last) echo '<span class="sep">/</span>';
          }
        }
      ?>
    </div>
    <div style="display:flex;gap:10px;align-items:center;flex:1;justify-content:flex-end">
      <form class="search" method="get" action="/task.php" style="max-width:680px">
        <i class="bi bi-search"></i>
        <input name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="Arama: görev, proje, kullanıcı…">
      </form>
      <span class="pill"><i class="bi bi-person-circle"></i> <?= e($_SESSION['user']['name'] ?? 'Kullanıcı') ?></span>
    </div>
  </div>

  <div style="height:14px"></div>

  <div class="page-container">
    
    <!-- Header -->
    <div class="header-card">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h2 class="mb-0"><i class="bi bi-folder-fill"></i> Projeler</h2>
                <small class="text-muted"><?= count($projects) ?> proje</small>
            </div>
            <div class="col-md-4 text-center">
                <h5 class="mb-0 text-muted">Proje Yönetimi</h5>
            </div>
            <div class="col-md-4 text-end">
                <a href="project_create.php" class="btn btn-success">
                    <i class="bi bi-plus-circle"></i> Yeni Proje
                </a>
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="bi bi-house"></i> Dashboard
                </a>
            </div>
        </div>
    </div>

    <!-- Messages -->
    <?php if ($msg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $msg ?>
        </div>
    <?php endif; ?>
    
    <?php if ($err): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= $err ?>
        </div>
    <?php endif; ?>

    <!-- Projects Grid -->
    <div class="row">
        <?php if (empty($projects)): ?>
            <div class="col-12">
                <div class="content-card text-center py-5">
                    <i class="bi bi-folder-x" style="font-size: 64px; color: #cbd5e1;"></i>
                    <h4 class="mt-3 text-muted">Henüz proje yok</h4>
                    <p class="text-muted">Yeni bir proje oluşturarak başlayın</p>
                    <a href="project_create.php" class="btn btn-primary btn-lg mt-3">
                        <i class="bi bi-plus-circle"></i> İlk Projeyi Oluştur
                    </a>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($projects as $project): ?>
            <div class="col-md-4">
                <div class="project-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <h5 class="mb-0" style="color: #1e3a8a;">
                            <i class="bi bi-folder-fill"></i> <?= htmlspecialchars($project['name']) ?>
                        </h5>
                        <?php if (is_super_admin()): ?>
                            <span class="badge bg-info"><?= htmlspecialchars($project['company_name'] ?? 'N/A') ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if (!empty($project['description'])): ?>
                    <p class="text-muted small mb-3" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                        <?= htmlspecialchars($project['description']) ?>
                    </p>
                    <?php endif; ?>
                    
                    <div class="mb-3">
                        <small class="text-muted">
                            <i class="bi bi-check-square"></i> <?= (int)$project['task_count'] ?> görev
                        </small>
                    </div>
                    
                    <div class="d-flex gap-2">
                        <a href="project_detail.php?id=<?= $project['id'] ?>" class="btn btn-sm btn-primary flex-fill">
                            <i class="bi bi-eye"></i> Görüntüle
                        </a>
                        <a href="project_edit.php?id=<?= $project['id'] ?>" class="btn btn-sm btn-warning">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <?php if ((int)$project['task_count'] === 0): ?>
                        <button class="btn btn-sm btn-danger" onclick="confirmDelete(<?= $project['id'] ?>, '<?= htmlspecialchars($project['name'], ENT_QUOTES) ?>')">
                            <i class="bi bi-trash"></i>
                        </button>
                        <?php else: ?>
                        <button class="btn btn-sm btn-secondary" disabled title="Görevleri önce silin">
                            <i class="bi bi-trash"></i>
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="bi bi-exclamation-triangle"></i> Projeyi Sil</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p><strong id="projectNameToDelete"></strong> projesini silmek istediğinize emin misiniz?</p>
                <p class="text-danger mb-0"><i class="bi bi-exclamation-triangle"></i> Bu işlem geri alınamaz!</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                <form method="post" id="deleteForm" style="display:inline;">
                    <input type="hidden" name="project_id" id="projectIdToDelete">
                    <button type="submit" name="delete_project" class="btn btn-danger">
                        <i class="bi bi-trash"></i> Evet, Sil
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function confirmDelete(projectId, projectName) {
    document.getElementById('projectIdToDelete').value = projectId;
    document.getElementById('projectNameToDelete').textContent = projectName;
    
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));
    modal.show();
}
</script>
</main>
<?php require __DIR__ . "/shared/layout_foot.php"; ?>

