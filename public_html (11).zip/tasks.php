<?php
declare(strict_types=1);

require __DIR__ . "/auth.php";
require __DIR__ . "/config/db.php";

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$msg = "";
$err = "";

// Görev silme
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "delete_task") {
    $taskId = (int)($_POST["task_id"] ?? 0);
    
    try {
        if (can_delete_task($taskId)) {
            $stmt = $pdo->prepare("DELETE FROM tasks WHERE id = ?");
            $stmt->execute([$taskId]);
            $msg = "Görev silindi!";
        } else {
            throw new Exception("Bu görevi silme yetkiniz yok!");
        }
    } catch (Exception $e) {
        $err = "Hata: " . $e->getMessage();
    }
}

// Görevleri listele - COMPANY ADMIN SADECE KENDİ ŞİRKETİNİ GÖRÜR
if (is_super_admin()) {
    // Super admin tüm görevleri görür
    $stmt = $pdo->query("
        SELECT t.*, 
               p.name as project_name,
               p.company_id,
               c.name as company_name,
               assigned.name as assigned_name,
               creator.name as creator_name
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        LEFT JOIN companies c ON p.company_id = c.id
        LEFT JOIN users assigned ON t.assigned_to = assigned.id
        LEFT JOIN users creator ON t.created_by = creator.id
        ORDER BY t.created_at DESC
    ");
} else {
    // Company admin ve user sadece kendi şirketinin görevlerini görür
    $stmt = $pdo->prepare("
        SELECT t.*, 
               p.name as project_name,
               p.company_id,
               c.name as company_name,
               assigned.name as assigned_name,
               creator.name as creator_name
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        LEFT JOIN companies c ON p.company_id = c.id
        LEFT JOIN users assigned ON t.assigned_to = assigned.id
        LEFT JOIN users creator ON t.created_by = creator.id
        WHERE p.company_id = ?
        ORDER BY t.created_at DESC
    ");
    $stmt->execute([$companyId]);
}

$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Görevler</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>

<div class="container-fluid p-4">
    <div class="row mb-4">
        <div class="col">
            <h2><i class="bi bi-check-square"></i> Görevler</h2>
            <p class="text-muted">Tüm görevleri görüntüleyin ve yönetin</p>
        </div>
        <div class="col-auto">
            <?php if (has_permission('manage_tasks')): ?>
            <a href="task_create.php" class="btn btn-success">
                <i class="bi bi-plus-circle"></i> Yeni Görev
            </a>
            <?php endif; ?>
            <a href="dashboard.php" class="btn btn-secondary">
                <i class="bi bi-house"></i> Dashboard
            </a>
        </div>
    </div>

    <?php if($msg): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= e($msg) ?>
        </div>
    <?php endif; ?>
    
    <?php if($err): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            <?= e($err) ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Görevler <span class="badge bg-primary"><?= count($tasks) ?></span></h5>
        </div>
        <div class="card-body">
            <?php if (empty($tasks)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-check-square" style="font-size: 64px; color: #ddd;"></i>
                    <p class="text-muted mt-3">Henüz görev yok</p>
                </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Görev</th>
                            <th>Proje</th>
                            <?php if (is_super_admin()): ?>
                            <th>Firma</th>
                            <?php endif; ?>
                            <th>Atanan</th>
                            <th>Durum</th>
                            <th>Öncelik</th>
                            <th>Bitiş</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tasks as $task): ?>
                        <tr>
                            <td><strong><?= e($task['title']) ?></strong></td>
                            <td><?= e($task['project_name']) ?></td>
                            <?php if (is_super_admin()): ?>
                            <td>
                                <span class="badge bg-secondary">
                                    <?= e($task['company_name'] ?? '-') ?>
                                </span>
                            </td>
                            <?php endif; ?>
                            <td><?= e($task['assigned_name'] ?? '-') ?></td>
                            <td>
                                <?php
                                $statusBadge = 'secondary';
                                $statusText = 'Bekliyor';
                                if ($task['status'] === 'in_progress') {
                                    $statusBadge = 'primary';
                                    $statusText = 'Devam Ediyor';
                                } elseif ($task['status'] === 'completed') {
                                    $statusBadge = 'success';
                                    $statusText = 'Tamamlandı';
                                }
                                ?>
                                <span class="badge bg-<?= $statusBadge ?>"><?= $statusText ?></span>
                            </td>
                            <td>
                                <?php
                                $priorityBadge = 'info';
                                $priorityText = 'Düşük';
                                if ($task['priority'] === 'high') {
                                    $priorityBadge = 'danger';
                                    $priorityText = 'Yüksek';
                                } elseif ($task['priority'] === 'medium') {
                                    $priorityBadge = 'warning';
                                    $priorityText = 'Orta';
                                }
                                ?>
                                <span class="badge bg-<?= $priorityBadge ?>"><?= $priorityText ?></span>
                            </td>
                            <td>
                                <?= $task['due_date'] ? date('d.m.Y', strtotime($task['due_date'])) : '-' ?>
                            </td>
                            <td>
                                <a href="task_edit.php?id=<?= (int)$task['id'] ?>" 
                                   class="btn btn-sm btn-primary">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                
                                <?php if (can_delete_task((int)$task['id'])): ?>
                                <form method="post" style="display:inline"
                                      onsubmit="return confirm('Bu görevi silmek istediğinize emin misiniz?')">
                                    <input type="hidden" name="action" value="delete_task">
                                    <input type="hidden" name="task_id" value="<?= (int)$task['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>