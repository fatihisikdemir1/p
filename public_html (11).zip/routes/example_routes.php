<?php
// Example routes (adapt to your Router class / bootstrap):
// Router::get('/admin/billing', [BillingAdminController::class, 'index']);
// Router::post('/admin/billing/save-subscription', [BillingAdminController::class, 'saveSubscription']);
// Router::post('/admin/billing/toggle-module', [BillingAdminController::class, 'toggleModule']);

// Example module gate usage inside controllers:
// RequireModule::check('finance');
// RequireModule::check('treasury');
